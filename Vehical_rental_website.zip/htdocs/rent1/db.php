<?php
require_once __DIR__ . '/config.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function ensureColumn(mysqli $conn, string $table, string $column, string $definition): void {
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $safeColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $stmt = $conn->prepare(
        'SELECT COUNT(*) AS c FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $stmt->bind_param('ss', $safeTable, $safeColumn);
    $stmt->execute();
    $exists = (int)$stmt->get_result()->fetch_assoc()['c'] > 0;
    $stmt->close();
    if (!$exists) {
        $conn->query("ALTER TABLE `$safeTable` ADD COLUMN `$safeColumn` $definition");
    }
}

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');

    // Keep customer identity data compatible with the admin Customers page.
    try {
        $conn->query("ALTER TABLE customers ADD COLUMN license_no VARCHAR(60) NULL AFTER nic");
    } catch (Throwable $e) { /* column already exists */ }

    // Create new tables when they do not exist.
    $conn->query("CREATE TABLE IF NOT EXISTS cart_items (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        customer_id INT UNSIGNED NOT NULL,
        vehicle_id VARCHAR(100) NOT NULL DEFAULT '',
        vehicle_name VARCHAR(150) NOT NULL DEFAULT '',
        total_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        currency VARCHAR(10) NOT NULL DEFAULT 'USD',
        pickup_date DATE NULL,
        dropoff_date DATE NULL,
        rental_days INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_cart_customer (customer_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS bookings (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        booking_ref VARCHAR(50) NOT NULL,
        customer_id INT UNSIGNED NOT NULL,
        vehicle_id VARCHAR(100) NOT NULL DEFAULT '',
        vehicle_name VARCHAR(150) NOT NULL DEFAULT '',
        vehicle_image TEXT NULL,
        vehicle_category VARCHAR(100) NULL,
        customer_name VARCHAR(150) NOT NULL DEFAULT '',
        customer_email VARCHAR(190) NOT NULL DEFAULT '',
        customer_phone VARCHAR(30) NULL,
        pickup_date DATE NULL,
        dropoff_date DATE NULL,
        pickup_location VARCHAR(150) NULL,
        dropoff_location VARCHAR(150) NULL,
        rental_days INT NOT NULL DEFAULT 1,
        price_usd DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        payment_method VARCHAR(100) NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'Confirmed',
        addons TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_booking_customer (customer_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Repair older versions of these tables automatically.
    $cartCols = [
        'customer_id'=>'INT UNSIGNED NOT NULL DEFAULT 0',
        'vehicle_id'=>"VARCHAR(100) NOT NULL DEFAULT ''",
        'vehicle_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",
        'total_price'=>'DECIMAL(10,2) NOT NULL DEFAULT 0.00',
        'currency'=>"VARCHAR(10) NOT NULL DEFAULT 'USD'",
        'pickup_date'=>'DATE NULL',
        'dropoff_date'=>'DATE NULL',
        'rental_days'=>'INT NOT NULL DEFAULT 1',
        'created_at'=>'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
    ];
    foreach ($cartCols as $c=>$d) ensureColumn($conn, 'cart_items', $c, $d);

    $bookingCols = [
        'booking_ref'=>"VARCHAR(50) NOT NULL DEFAULT ''",
        'customer_id'=>'INT UNSIGNED NOT NULL DEFAULT 0',
        'vehicle_id'=>"VARCHAR(100) NOT NULL DEFAULT ''",
        'vehicle_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",
        'vehicle_image'=>'TEXT NULL','vehicle_category'=>'VARCHAR(100) NULL',
        'customer_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",'customer_email'=>"VARCHAR(190) NOT NULL DEFAULT ''",
        'customer_phone'=>'VARCHAR(30) NULL','pickup_date'=>'DATE NULL','dropoff_date'=>'DATE NULL',
        'pickup_location'=>'VARCHAR(150) NULL','dropoff_location'=>'VARCHAR(150) NULL',
        'rental_days'=>'INT NOT NULL DEFAULT 1','price_usd'=>'DECIMAL(10,2) NOT NULL DEFAULT 0.00',
        'payment_method'=>'VARCHAR(100) NULL','status'=>"VARCHAR(30) NOT NULL DEFAULT 'Confirmed'",'addons'=>'TEXT NULL',
        'nic_front'=>'VARCHAR(255) NULL','nic_back'=>'VARCHAR(255) NULL',
        'created_at'=>'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP','updated_at'=>'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
    ];
    foreach ($bookingCols as $c=>$d) ensureColumn($conn, 'bookings', $c, $d);
    // PayHere payment tracking fields.
    $paymentCols = [
        'payment_status'=>"VARCHAR(30) NOT NULL DEFAULT 'UNPAID'",
        'payment_id'=>"VARCHAR(100) NULL",
        'payment_method_gateway'=>"VARCHAR(50) NULL",
        'paid_amount'=>"DECIMAL(10,2) NULL",
        'paid_currency'=>"VARCHAR(10) NULL",
        'payment_message'=>"VARCHAR(255) NULL",
        'payment_updated_at'=>"TIMESTAMP NULL DEFAULT NULL"
    ];
    foreach ($paymentCols as $c=>$d) ensureColumn($conn, 'bookings', $c, $d);

    // Allow the PayHere lifecycle states: Pending Payment / Confirmed / Cancelled.
    // Older installations may have an ENUM here.
    try {
        $conn->query("ALTER TABLE bookings MODIFY status VARCHAR(30) NOT NULL DEFAULT 'Confirmed'");
    } catch (Throwable $e) { /* already compatible */ }

    $uploadsDir = __DIR__ . '/uploads/nic';
    if (!is_dir($uploadsDir)) {
        @mkdir($uploadsDir, 0777, true);
    }


    // Shared vehicle inventory used by BOTH customer and standalone admin sites.
    // Create the table if it does not exist, then seed the original catalogue once.
    $conn->query("CREATE TABLE IF NOT EXISTS vehicles (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        vehicle_code VARCHAR(100) NOT NULL UNIQUE,
        name VARCHAR(150) NOT NULL,
        brand VARCHAR(100) NULL,
        location VARCHAR(100) NOT NULL DEFAULT 'Matara',
        category VARCHAR(100) NOT NULL DEFAULT 'Medium',
        plate VARCHAR(50) NULL,
        year INT NULL,
        seats INT NOT NULL DEFAULT 4,
        doors INT NOT NULL DEFAULT 4,
        transmission VARCHAR(50) DEFAULT 'Automatic',
        fuel VARCHAR(80) DEFAULT 'Petrol',
        ac TINYINT(1) DEFAULT 1,
        bags INT DEFAULT 2,
        price_usd DECIMAL(10,2) NOT NULL DEFAULT 0,
        service_type VARCHAR(50) DEFAULT 'Both',
        image TEXT NULL,
        status VARCHAR(30) DEFAULT 'Available',
        active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $vehicleCols = [
        'vehicle_code'=>"VARCHAR(100) NULL", 'name'=>"VARCHAR(150) NULL", 'brand'=>"VARCHAR(100) NULL",
        'location'=>"VARCHAR(100) NOT NULL DEFAULT 'Matara'", 'category'=>"VARCHAR(100) NOT NULL DEFAULT 'Medium'",
        'plate'=>"VARCHAR(50) NULL", 'year'=>"INT NULL", 'seats'=>"INT NOT NULL DEFAULT 4", 'doors'=>"INT NOT NULL DEFAULT 4",
        'transmission'=>"VARCHAR(50) DEFAULT 'Automatic'", 'fuel'=>"VARCHAR(80) DEFAULT 'Petrol'", 'ac'=>"TINYINT(1) DEFAULT 1",
        'bags'=>"INT DEFAULT 2", 'price_usd'=>"DECIMAL(10,2) NOT NULL DEFAULT 0", 'service_type'=>"VARCHAR(50) DEFAULT 'Both'",
        'image'=>"TEXT NULL", 'status'=>"VARCHAR(30) DEFAULT 'Available'", 'active'=>"TINYINT(1) DEFAULT 1",
        'last_service_date'=>"DATE NULL",
        'created_at'=>"TIMESTAMP DEFAULT CURRENT_TIMESTAMP", 'updated_at'=>"TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    foreach($vehicleCols as $col=>$def){
        $safeCol=$conn->real_escape_string($col);
        $ck=$conn->query("SHOW COLUMNS FROM vehicles LIKE '$safeCol'");
        if($ck->num_rows===0){ try{$conn->query("ALTER TABLE vehicles ADD COLUMN `$safeCol` $def");}catch(Throwable $e){} }
    }
    $conn->query("UPDATE vehicles SET vehicle_code=CONCAT('LEGACY-',id) WHERE vehicle_code IS NULL OR vehicle_code=''");
    $conn->query("UPDATE vehicles SET name='Vehicle' WHERE name IS NULL OR name=''");

    if ((int)$conn->query("SELECT COUNT(*) c FROM vehicles")->fetch_assoc()['c']===0) {
        $seed = [
            ['V001','Suzuki Alto','Suzuki','Small','',2024,16,'Petrol or diesel','Automatic',4,4,'Matara','Vehicle Only','images/Suzuki_Alto.jpg'],
            ['V002','Perodua Axia','Perodua','Small','',2024,18,'Petrol or diesel','Automatic',4,4,'Matara','Vehicle Only','images/Perodua_Axia.webp'],
            ['V003','Suzuki Wagon R','Suzuki','Medium','',2024,17,'Hybrid','Automatic',4,4,'Matara','Both','images/Suzuki_Wagon_R.jpg'],
            ['V004','Toyota C-HR','Toyota','SUVs','',2024,19,'Hybrid','Automatic',5,4,'Matara','Both','images/Toyota_C-HR_(CHR).jpg'],
            ['V005','BMW 3 Series','BMW','Premium','',2024,60,'Petrol or diesel','Automatic',5,4,'Matara','With Driver','https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=600&q=80'],
            ['V006','Toyota Prius','Toyota','Medium','',2024,16,'Hybrid','Automatic',5,4,'Galle','Both','images/Toyota_Prius.webp'],
            ['V007','Toyota Vitz','Toyota','Small','',2024,17,'Petrol or diesel','Automatic',5,4,'Galle','Vehicle Only','images/Toyota_Vitz.jpg'],
            ['V008','Audi A4','Audi','Large','',2024,55,'Petrol or diesel','Automatic',5,4,'Galle','With Driver','https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=600&q=80'],
            ['V009','Toyota Aqua','Toyota','Estate','',2024,19,'Hybrid','Automatic',5,4,'Galle','Both','images/Toyota_Aqua.jpg'],
            ['V010','Nissan GT-R','Nissan','Premium','',2024,70,'Petrol or diesel','Automatic',4,2,'Hambantota','With Driver','images/Nissan_GT-R.jpg'],
            ['V011','Nissan March','Nissan','Small','',2024,36,'Petrol or diesel','Manual',4,4,'Hambantota','Vehicle Only','images/Nissan_March.webp'],
            ['V012','Honda Civic','Honda','Large','',2024,30,'Petrol or diesel','Automatic',5,4,'Hambantota','Both','images/Honda_Civic.jpg'],
            ['V013','Toyota KDH Van','Toyota','People carriers','',2024,32,'Petrol or diesel','Manual',10,4,'Hambantota','With Driver','images/Toyota_KDH_Van.jpg']
        ];
        $st=$conn->prepare("INSERT INTO vehicles(vehicle_code,name,brand,category,plate,year,price_usd,fuel,transmission,seats,doors,location,service_type,image,status,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Available',1)");
        foreach($seed as $v){$st->bind_param('sssssidssiisss',$v[0],$v[1],$v[2],$v[3],$v[4],$v[5],$v[6],$v[7],$v[8],$v[9],$v[10],$v[11],$v[12],$v[13]);$st->execute();}
        $st->close();
    }

} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection/setup failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}

// Live GPS positions for customer-picked/rented vehicles.
// One latest row per booking is kept so the admin map always shows the newest position.
$conn->query("CREATE TABLE IF NOT EXISTS vehicle_gps_locations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_ref VARCHAR(50) NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  vehicle_id VARCHAR(100) NOT NULL,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL,
  accuracy DECIMAL(10,2) NULL,
  speed DECIMAL(10,2) NULL,
  heading DECIMAL(10,2) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_gps_booking (booking_ref),
  INDEX idx_gps_vehicle (vehicle_id),
  INDEX idx_gps_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

?>
