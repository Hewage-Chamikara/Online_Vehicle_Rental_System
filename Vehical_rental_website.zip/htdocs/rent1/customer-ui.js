(function () {
    'use strict';

    async function getCustomerState() {
        try {
            const response = await fetch('session-status.php?_=' + Date.now(), {
                credentials: 'same-origin',
                cache: 'no-store'
            });
            if (!response.ok) return { loggedIn: false, customer: null };
            return await response.json();
        } catch (e) {
            console.error('Session status error:', e);
            return { loggedIn: false, customer: null };
        }
    }

    async function getCount(action) {
        try {
            const response = await fetch('customer-api.php?action=' + action + '&_=' + Date.now(), {
                credentials: 'same-origin',
                cache: 'no-store'
            });
            if (response.status === 401) return 0;
            const data = await response.json();
            return data.success ? Number(data.count || 0) : 0;
        } catch (e) {
            console.error(action + ' count error:', e);
            return 0;
        }
    }

    async function refreshCustomerUI() {
        const state = await getCustomerState();
        const loggedIn = !!state.loggedIn && !!state.customer;
        const customer = state.customer || {};

        document.querySelectorAll('.customer-image').forEach(function (el) {
            if (loggedIn && (customer.image || customer.profile_image)) {
                el.src = (customer.image || customer.profile_image);
                el.style.display = '';
            } else {
                el.removeAttribute('src');
            }
        });

        document.querySelectorAll('#loginLogoutBtn').forEach(function (btn) {
            if (loggedIn) {
                btn.textContent = '👤 ' + customer.name + ' | Logout';
                btn.href = 'logout.php';
                btn.title = 'Logout ' + customer.name;
                btn.onclick = null;
            } else {
                btn.textContent = 'Login';
                btn.href = 'login.php';
                btn.title = 'Customer Login';
                btn.onclick = null;
            }
        });

        const cartCount = await getCount('cart');
        const bookingCount = await getCount('bookings');

        document.querySelectorAll('#cartCount, #liquidCartCount').forEach(function (badge) {
            badge.textContent = String(cartCount);
            badge.style.display = 'flex';
            badge.setAttribute('aria-label', 'Cart items: ' + cartCount);
        });

        document.querySelectorAll('#bookingCount, #liquidBookingCount').forEach(function (badge) {
            badge.textContent = String(bookingCount);
            badge.style.display = 'inline-flex';
            badge.setAttribute('aria-label', 'Bookings: ' + bookingCount);
        });

        window.currentCustomer = loggedIn ? customer : null;
        window.dispatchEvent(new CustomEvent('customerStateChanged', { detail: state }));
    }

    window.refreshCustomerUI = refreshCustomerUI;
    window.getCustomerState = getCustomerState;
    window.updateCustomerAuthButton = refreshCustomerUI;

    document.addEventListener('DOMContentLoaded', refreshCustomerUI);
    window.addEventListener('pageshow', refreshCustomerUI);
})();
