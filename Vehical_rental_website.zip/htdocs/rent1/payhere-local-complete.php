<?php
// LOCAL SANDBOX FALLBACK ONLY.
// PayHere cannot send server-to-server notify callbacks to localhost.
// This endpoint is intentionally disabled outside PayHere Sandbox.
session_start();
require_once __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

function respondLocal(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!PAYHERE_SANDBOX) {
    respondLocal(['success' => false, 'message' => 'Local Sandbox completion is disabled in production.'], 403);
}

$customerId = (int)($_SESSION['customer_id'] ?? 0);
if ($customerId <= 0) {
    respondLocal(['success' => false, 'message' => 'Please login first.'], 401);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '{}', true);
$bookingRef = trim((string)($input['booking_id'] ?? ''));
if ($bookingRef === '') {
    respondLocal(['success' => false, 'message' => 'Booking ID is required.'], 400);
}

$stmt = $conn->prepare(
    'SELECT booking_ref, customer_id, vehicle_id, vehicle_name, vehicle_image, vehicle_category,
            customer_name, customer_email, customer_phone, pickup_date, dropoff_date,
            pickup_location, dropoff_location, rental_days, price_usd, payment_method,
            status, payment_status, paid_amount, paid_currency, payment_method_gateway
     FROM bookings WHERE booking_ref = ? AND customer_id = ? LIMIT 1'
);
$stmt->bind_param('si', $bookingRef, $customerId);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    respondLocal(['success' => false, 'message' => 'Booking not found.'], 404);
}

// Idempotent: if the signed notify already confirmed it, simply return the booking.
if ($booking['payment_status'] !== 'PAID' || $booking['status'] !== 'Confirmed') {
    $amount = number_format((float)$booking['price_usd'], 2, '.', '');
    $paymentId = 'SANDBOX-' . $bookingRef;
    $gateway = 'PayHere Online Payment';

    $up = $conn->prepare(
        "UPDATE bookings
         SET status='Confirmed', payment_status='PAID', payment_id=?,
             payment_method_gateway=?, payment_method='PayHere Online Payment',
             paid_amount=?, paid_currency='USD', payment_message='PayHere Sandbox completed',
             payment_updated_at=NOW()
         WHERE booking_ref=? AND customer_id=? AND status='Pending Payment'"
    );
    $up->bind_param('ssdsi', $paymentId, $gateway, $amount, $bookingRef, $customerId);
    $up->execute();
    $up->close();

    $remove = $conn->prepare('DELETE FROM cart_items WHERE customer_id = ? AND vehicle_id = ?');
    $remove->bind_param('is', $customerId, $booking['vehicle_id']);
    $remove->execute();
    $remove->close();

    $booking['status'] = 'Confirmed';
    $booking['payment_status'] = 'PAID';
    $booking['payment_id'] = $paymentId;
    $booking['payment_method_gateway'] = $gateway;
    $booking['paid_amount'] = $amount;
    $booking['paid_currency'] = 'USD';
}

respondLocal(['success' => true, 'booking' => $booking]);
