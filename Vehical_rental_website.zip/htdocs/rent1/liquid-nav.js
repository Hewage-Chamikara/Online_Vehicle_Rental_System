
(function(){
 const nav = document.createElement('nav');
 nav.className='liquid-nav';
 nav.setAttribute('aria-label','Main navigation');
 nav.innerHTML=`
  <a href="1.html" data-page="1.html"><span class="nav-icon">⌂</span><span>Home</span></a>
  <a href="2.html" data-page="2.html"><span class="nav-icon">⌕</span><span>Vehicles</span></a>
  <a href="vehicallist.html" data-page="vehicallist.html"><span class="nav-icon">▥</span><span>Fleet</span></a>
  <a href="3.html" data-page="3.html"><span class="nav-icon">♧</span><span>Bookings</span><span class="nav-count" id="liquidBookingCount">0</span></a>
  <a href="cart.html" data-page="cart.html"><span class="nav-icon">🛒</span><span>Cart</span><span class="nav-count" id="liquidCartCount">0</span></a>
  <a href="login.php" id="liquidAccount"><span class="nav-icon">♙</span><span>Account</span></a>`;
 document.addEventListener('DOMContentLoaded',()=>{
   document.body.appendChild(nav);
   const current=(location.pathname.split('/').pop()||'1.html').toLowerCase();
   nav.querySelectorAll('a[data-page]').forEach(a=>{if(a.dataset.page.toLowerCase()===current)a.classList.add('active')});
   async function count(action,id){
     try{
       const r=await fetch('customer-api.php?action='+action+'&_='+Date.now(),{credentials:'same-origin',cache:'no-store'});
       if(!r.ok)return 0; const d=await r.json(); return Number(d.count||0);
     }catch(e){return 0}
   }
   async function refresh(){
     const [cart,bookings]=await Promise.all([count('cart'),count('bookings')]);
     document.getElementById('liquidCartCount').textContent=cart;
     document.getElementById('liquidBookingCount').textContent=bookings;
     const st=await fetch('session-status.php?_='+Date.now(),{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():null).catch(()=>null);
     const acc=document.getElementById('liquidAccount');
     if(st?.loggedIn && st.customer){acc.querySelector('span:last-child').textContent=st.customer.name||'Account';acc.href='logout.php';}
   }
   refresh(); window.addEventListener('pageshow',refresh);
 });
})();
