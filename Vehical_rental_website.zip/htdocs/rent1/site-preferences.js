(function(){
  'use strict';
  function prefTheme(){ return localStorage.getItem('siteTheme') || 'dark'; }
  function prefCurrency(){ return localStorage.getItem('siteCurrency') || 'USD'; }
  function applyTheme(){
    const light=prefTheme()==='light';
    document.body.classList.toggle('light-mode',light);
    document.documentElement.classList.toggle('light-mode',light);
    document.querySelectorAll('#themeToggle,#themeToggleBtn,#themeBtn').forEach(b=>{
      const icon=b.querySelector('svg');
      if(icon){
        icon.innerHTML=light ? '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>' : '<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="4.22"></line>';
      }else b.textContent=light?'🌙':'☀️';
    });
  }
  function applyCurrency(){
    const c=prefCurrency();
    if (typeof currentCurrency !== 'undefined') { currentCurrency = c; }
    document.querySelectorAll('#currencySymbol,#currencyLabel').forEach(e=>e.textContent=c);
    document.body.dataset.currency=c;
    window.dispatchEvent(new Event('currencyChange'));
  }
  document.addEventListener('click',function(e){
    const currency=e.target.closest('#currencyToggle,#currencyToggleBtn,#currencyBtn');
    if(currency){ e.preventDefault(); e.stopImmediatePropagation(); localStorage.setItem('siteCurrency',prefCurrency()==='USD'?'LKR':'USD'); applyCurrency(); return; }
    const theme=e.target.closest('#themeToggle,#themeToggleBtn,#themeBtn');
    if(theme){ e.preventDefault(); e.stopImmediatePropagation(); localStorage.setItem('siteTheme',prefTheme()==='light'?'dark':'light'); applyTheme(); return; }
  },true);
  document.addEventListener('DOMContentLoaded',function(){ applyTheme(); applyCurrency(); });
  window.addEventListener('pageshow',function(){ applyTheme(); applyCurrency(); });
  window.siteApplyTheme=applyTheme; window.siteApplyCurrency=applyCurrency;
})();
