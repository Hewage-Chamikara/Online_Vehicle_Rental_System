// --- Global Theme & Currency Initialization ---
const appCurrentTheme = localStorage.getItem('siteTheme') || 'dark';
const appThemeToggle = document.getElementById('appThemeToggle');

if (appCurrentTheme === 'light') {
    document.body.classList.add('light-mode');
    if (appThemeToggle) appThemeToggle.innerText = '🌙';
} else {
    if (appThemeToggle) appThemeToggle.innerText = '☀️';
}

const appCurrencySymbol = document.getElementById('appCurrencySymbol');
let appCurrentCurrency = localStorage.getItem('siteCurrency') || 'USD';
if (appCurrencySymbol) {
    appCurrencySymbol.innerText = appCurrentCurrency;
}

// --- Server-side customer cart / booking state ---
async function getCustomerState() {
    try {
        const response = await fetch('session-status.php', {
            credentials: 'same-origin',
            cache: 'no-store'
        });
        if (!response.ok) return { loggedIn: false, customer: null };
        return await response.json();
    } catch (error) {
        return { loggedIn: false, customer: null };
    }
}

async function updateCartBadge() {
    const badges = document.querySelectorAll('#cartCount, #liquidCartCount');
    if (!badges.length) return;

    try {
        const response = await fetch('customer-api.php?action=cart', {
            credentials: 'same-origin',
            cache: 'no-store'
        });
        let totalItems = 0;
        if (response.ok) {
            const data = await response.json();
            totalItems = Number(data.count || 0);
        }
        badges.forEach(badge => {
            badge.innerText = String(totalItems);
            badge.style.display = 'flex';
        });
    } catch (error) {
        badges.forEach(badge => {
            badge.innerText = '0';
            badge.style.display = 'flex';
        });
    }
}

async function updateBookingBadge() {
    const badge = document.getElementById('bookingCount');
    if (!badge) return;

    try {
        const response = await fetch('customer-api.php?action=bookings', {
            credentials: 'same-origin',
            cache: 'no-store'
        });
        if (response.status === 401) {
            badge.innerText = '0';
            return;
        }
        const data = await response.json();
        badge.innerText = Number(data.count || 0);
    } catch (error) {
        badge.innerText = '0';
    }
}

async function refreshCustomerUI() {
    if (window.refreshCustomerUI && window.refreshCustomerUI !== refreshCustomerUI) {
        return window.refreshCustomerUI();
    }
    return getCustomerState();
}

async function refreshUserDataUI() {
    await Promise.all([refreshCustomerUI(), updateCartBadge(), updateBookingBadge()]);
}

function addToCartAndSync(newItem) {
    // Compatibility helper: new code should call customer-api.php?action=add_cart.
    if (!newItem) return;
    fetch('customer-api.php?action=add_cart', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem)
    }).then(() => refreshUserDataUI()).catch(() => {});
}

document.addEventListener('DOMContentLoaded', refreshUserDataUI);
window.addEventListener('pageshow', refreshUserDataUI);
window.addEventListener('cartUpdated', updateCartBadge);
window.addEventListener('bookingUpdated', updateBookingBadge);

// Admin Session Check
const appIsAdmin = localStorage.getItem('isAdminLoggedIn') === 'true';
const appLoginLogoutBtn = document.getElementById('appLoginLogoutBtn');

if (appIsAdmin && appLoginLogoutBtn) {
    appLoginLogoutBtn.innerText = 'Logout';
    appLoginLogoutBtn.href = '#';
    appLoginLogoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('isAdminLoggedIn');
        window.location.reload();
    });
}

// Currency Toggle
const appCurrencyToggle = document.getElementById('appCurrencyToggle');
if (appCurrencyToggle) {
    appCurrencyToggle.addEventListener('click', () => {
        appCurrentCurrency = appCurrentCurrency === 'USD' ? 'LKR' : 'USD';
        if (appCurrencySymbol) appCurrencySymbol.innerText = appCurrentCurrency;
        localStorage.setItem('siteCurrency', appCurrentCurrency);
        window.dispatchEvent(new Event('currencyChange'));
    });
}

// Theme Toggle
if (appThemeToggle) {
    appThemeToggle.addEventListener('click', () => {
        document.body.classList.toggle('light-mode');
        const isLight = document.body.classList.contains('light-mode');
        appThemeToggle.innerText = isLight ? '🌙' : '☀️';
        localStorage.setItem('siteTheme', isLight ? 'light' : 'dark');

        if (typeof appParticlesArray !== 'undefined') {
            appParticlesArray.forEach(p => {
                p.color = getParticleColor();
            });
        }
    });
}

// Ride Type Tabs Selection
const tabButtons = document.querySelectorAll('.tab-btn');
let appSelectedRideType = "Both";

tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        tabButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        appSelectedRideType = btn.getAttribute('data-type');
    });
});

// --- Date Pickers Initialization & Validation ---
function getLocalTodayString() {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

function initDatePickers() {
    const todayStr = getLocalTodayString();

    const pickupInputs = [
        document.getElementById('pickupDate'),
        document.getElementById('pickupDateInput')
    ].filter(Boolean);

    const dropoffInputs = [
        document.getElementById('dropoffDate'),
        document.getElementById('returnDateInput')
    ].filter(Boolean);

    pickupInputs.forEach(pickup => {
        pickup.setAttribute('min', todayStr);

        pickup.addEventListener('change', () => {
            if (pickup.value && pickup.value < todayStr) {
                alert('Pick-up date cannot be prior to today.');
                pickup.value = '';
            }

            dropoffInputs.forEach(dropoff => {
                const minDrop = pickup.value || todayStr;
                dropoff.setAttribute('min', minDrop);
                if (dropoff.value && pickup.value && dropoff.value < pickup.value) {
                    dropoff.value = '';
                }
            });

            if (typeof recalculateTotals === 'function') {
                recalculateTotals();
            }
        });
    });

    dropoffInputs.forEach(dropoff => {
        const currentPickupVal = pickupInputs.length && pickupInputs[0].value ? pickupInputs[0].value : todayStr;
        dropoff.setAttribute('min', currentPickupVal);

        dropoff.addEventListener('change', () => {
            const minAllowed = pickupInputs.length && pickupInputs[0].value ? pickupInputs[0].value : todayStr;
            if (dropoff.value && dropoff.value < minAllowed) {
                alert('Drop-off date cannot be earlier than Pick-up date or today.');
                dropoff.value = '';
            }

            if (typeof recalculateTotals === 'function') {
                recalculateTotals();
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    initDatePickers();
});

// Search Button Redirect Fix
const appSearchBtn = document.getElementById('appSearchBtn');
if (appSearchBtn) {
    appSearchBtn.addEventListener('click', (e) => {
        const pickupEl = document.getElementById('pickupDate');
        const dropoffEl = document.getElementById('dropoffDate');
        const locationEl = document.getElementById('pickupLocation');

        if (pickupEl && dropoffEl) {
            const pickupDate = pickupEl.value;
            const dropoffDate = dropoffEl.value;
            const todayStr = getLocalTodayString();

            if (!pickupDate || !dropoffDate) {
                alert('Please select both Pick-up date and Drop-off date.');
                return;
            }

            if (pickupDate < todayStr) {
                alert('Pick-up date cannot be prior to today.');
                return;
            }

            if (dropoffDate < pickupDate) {
                alert('Drop-off date must be on or after the Pick-up date.');
                return;
            }

            const location = locationEl ? locationEl.value : '';
            const targetUrl = `2.html?location=${encodeURIComponent(location)}&pickup=${encodeURIComponent(pickupDate)}&dropoff=${encodeURIComponent(dropoffDate)}&type=${encodeURIComponent(typeof appSelectedRideType !== 'undefined' ? appSelectedRideType : 'Both')}`;
            window.location.href = targetUrl;
        }
    });
}

// Stats Counters Animation
const appCounters = document.querySelectorAll('.counter');
appCounters.forEach(counter => {
    const target = +counter.getAttribute('data-target');
    const suffix = counter.getAttribute('data-suffix') || "";
    const speed = +counter.getAttribute('data-speed') || 30;
    
    const updateCount = () => {
        const currentText = counter.innerText.replace('+', '').replace('/7', '');
        const count = +currentText || 0;
        
        if (count < target) {
            counter.innerText = (count + 1) + suffix;
            setTimeout(updateCount, speed);
        } else {
            counter.innerText = target + suffix;
        }
    };
    setTimeout(updateCount, 800);
});

// Canvas Highway Animation
const appCanvas = document.getElementById('rentalCanvas');
if (appCanvas) {
    const appCtx = appCanvas.getContext('2d');

    function resizeCanvas() {
        appCanvas.width = window.innerWidth;
        appCanvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    function getParticleColor() {
        return document.body.classList.contains('light-mode') 
            ? 'rgba(15, 23, 42, 0.45)' 
            : (Math.random() > 0.4 ? 'rgba(245, 158, 11, 0.4)' : 'rgba(56, 189, 248, 0.3)');
    }

    let appParticlesArray = [];
    for (let i = 0; i < 70; i++) {
        appParticlesArray.push({
            x: Math.random() * appCanvas.width,
            y: Math.random() * appCanvas.height,
            size: Math.random() * 2.5 + 0.5,
            speedY: Math.random() * 2 + 1,
            speedX: (Math.random() - 0.5) * 0.5,
            color: getParticleColor()
        });
    }

    function animate() {
        appCtx.clearRect(0, 0, appCanvas.width, appCanvas.height);

        appParticlesArray.forEach(p => {
            p.y += p.speedY;
            p.x += p.speedX;

            if (p.y > appCanvas.height) {
                p.y = 0;
                p.x = Math.random() * appCanvas.width;
            }

            appCtx.fillStyle = p.color;
            appCtx.beginPath();
            appCtx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            appCtx.fill();
        });

        requestAnimationFrame(animate);
    }
    animate();
}

// Google OAuth customer session UI is handled by refreshCustomerUI().


// --- Universal site preferences for pages without page-specific handlers ---
(function initUniversalPreferences() {
    const path = (window.location.pathname || '').split('/').pop().toLowerCase();
    const pageSpecific = ['1.html','2.html','book.html','vehicallist.html'];
    if (pageSpecific.includes(path)) return;

    const currencyButtons = document.querySelectorAll('#currencyToggle, #currencyToggleBtn, #currencyBtn');
    const themeButtons = document.querySelectorAll('#themeToggle, #themeToggleBtn, #themeBtn');

    function applyTheme() {
        const light = localStorage.getItem('siteTheme') === 'light';
        document.body.classList.toggle('light-mode', light);
        themeButtons.forEach(btn => {
            if (btn.id === 'themeToggle') btn.textContent = light ? '🌙' : '☀️';
        });
    }

    function applyCurrency() {
        const currency = localStorage.getItem('siteCurrency') || 'USD';
        document.querySelectorAll('#currencySymbol, #currencyLabel').forEach(el => el.textContent = currency);
    }

    applyTheme();
    applyCurrency();

    currencyButtons.forEach(btn => btn.addEventListener('click', function () {
        const next = (localStorage.getItem('siteCurrency') || 'USD') === 'USD' ? 'LKR' : 'USD';
        localStorage.setItem('siteCurrency', next);
        applyCurrency();
        window.dispatchEvent(new Event('currencyChange'));
    }));

    themeButtons.forEach(btn => btn.addEventListener('click', function () {
        const next = document.body.classList.contains('light-mode') ? 'dark' : 'light';
        localStorage.setItem('siteTheme', next);
        applyTheme();
    }));
})();

// --- Global Vehicle Info Modal Component ---
(function initVehicleModalSystem() {
    const modalStyle = document.createElement('style');
    modalStyle.textContent = `
        .vehicle-img-wrapper { position: relative; width: 100%; overflow: hidden; }
        .info-badge-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(9, 13, 22, 0.85);
            color: #f59e0b;
            border: 1px solid rgba(245, 158, 11, 0.6);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 0.78rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            z-index: 12;
            transition: all 0.25s ease;
            box-shadow: 0 4px 14px rgba(0,0,0,0.4);
        }
        .info-badge-btn:hover {
            background: #f59e0b;
            color: #000;
            border-color: #f59e0b;
            transform: translateY(-1px) scale(1.04);
            box-shadow: 0 6px 18px rgba(245, 158, 11, 0.4);
        }
        .vmodal-overlay {
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.82);
            backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
            z-index: 99999; display: none; align-items: center; justify-content: center;
            padding: 20px;
        }
        .vmodal-overlay.active { display: flex; }
        .vmodal-card {
            background: #0f172a; border: 1px solid rgba(245, 158, 11, 0.4);
            border-radius: 20px; max-width: 680px; width: 100%; max-height: 92vh;
            overflow-y: auto; color: #f8fafc; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
            position: relative; padding: 25px; font-family: 'Poppins', sans-serif;
            scrollbar-width: thin;
        }
        body.light-mode .vmodal-card { background: #ffffff; color: #0f172a; border-color: rgba(245, 158, 11, 0.4); }
        .vmodal-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 18px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 12px; }
        body.light-mode .vmodal-header { border-bottom-color: rgba(0,0,0,0.1); }
        .vmodal-title { font-family: 'Playfair Display', serif; font-size: 1.6rem; color: #f59e0b; margin: 0; }
        .vmodal-close { background: none; border: none; font-size: 1.8rem; color: #94a3b8; cursor: pointer; line-height: 1; transition: color 0.2s; }
        .vmodal-close:hover { color: #f59e0b; }
        .vmodal-banner {
            width: 100%; height: 220px; object-fit: cover; border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.1); margin-bottom: 18px;
        }
        .vmodal-service-badge {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(56, 189, 248, 0.15));
            border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 12px;
            padding: 14px 18px; margin-bottom: 20px; display: flex;
            justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;
        }
        .vmodal-service-item { display: flex; flex-direction: column; }
        .vmodal-service-label { font-size: 0.75rem; color: #94a3b8; font-weight: 500; }
        body.light-mode .vmodal-service-label { color: #64748b; }
        .vmodal-service-val { font-size: 0.95rem; font-weight: 700; color: #f59e0b; }
        .vmodal-specs-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
            gap: 12px; margin-bottom: 20px;
        }
        .vmodal-spec-box {
            background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08);
            border-radius: 10px; padding: 10px 14px; display: flex; flex-direction: column;
        }
        body.light-mode .vmodal-spec-box { background: rgba(0,0,0,0.04); border-color: rgba(0,0,0,0.08); }
        .vmodal-spec-name { font-size: 0.75rem; color: #94a3b8; }
        body.light-mode .vmodal-spec-name { color: #64748b; }
        .vmodal-spec-detail { font-size: 0.88rem; font-weight: 600; margin-top: 2px; }
        .vmodal-desc { font-size: 0.85rem; color: #cbd5e1; line-height: 1.6; margin-bottom: 20px; }
        body.light-mode .vmodal-desc { color: #475569; }

        /* --- Vehicle Booking Calendar Styles --- */
        .vm-calendar-wrapper {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 20px;
        }
        body.light-mode .vm-calendar-wrapper {
            background: rgba(241, 245, 249, 0.8);
            border-color: rgba(245, 158, 11, 0.4);
        }
        .vm-cal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .vm-cal-title {
            font-size: 0.95rem;
            font-weight: 700;
            color: #f59e0b;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .vm-cal-nav {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .vm-cal-nav-btn {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: var(--text-color, #fff);
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 700;
            font-size: 0.9rem;
            transition: all 0.2s;
        }
        body.light-mode .vm-cal-nav-btn {
            background: rgba(0, 0, 0, 0.06);
            border-color: rgba(0, 0, 0, 0.15);
            color: #0f172a;
        }
        .vm-cal-nav-btn:hover {
            background: #f59e0b;
            color: #000;
            border-color: #f59e0b;
        }
        .vm-cal-month-label {
            font-size: 0.88rem;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
        }
        .vm-cal-weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 4px;
            text-align: center;
            font-size: 0.72rem;
            font-weight: 700;
            color: #94a3b8;
            margin-bottom: 6px;
            text-transform: uppercase;
        }
        .vm-cal-days-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 4px;
        }
        .vm-cal-day {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.78rem;
            font-weight: 600;
            border-radius: 6px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: inherit;
            position: relative;
            user-select: none;
        }
        body.light-mode .vm-cal-day {
            background: rgba(255, 255, 255, 0.7);
            border-color: rgba(0, 0, 0, 0.06);
        }
        .vm-cal-day.empty {
            background: transparent;
            border: none;
        }
        .vm-cal-day.today {
            border-color: #38bdf8;
            font-weight: 800;
            box-shadow: 0 0 0 1px #38bdf8 inset;
        }
        .vm-cal-day.booked {
            background: rgba(239, 68, 68, 0.25) !important;
            border-color: rgba(239, 68, 68, 0.8) !important;
            color: #ef4444 !important;
            font-weight: 800;
            cursor: pointer;
        }
        .vm-cal-day.booked::after {
            content: '';
            position: absolute;
            bottom: 2px;
            width: 4px;
            height: 4px;
            border-radius: 50%;
            background: #ef4444;
        }
        .vm-booked-ranges-list {
            margin-top: 12px;
            padding-top: 10px;
            border-top: 1px dashed rgba(255, 255, 255, 0.12);
            font-size: 0.78rem;
        }
        body.light-mode .vm-booked-ranges-list {
            border-top-color: rgba(0, 0, 0, 0.12);
        }
        .vm-range-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 4px 8px;
            border-radius: 6px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.25);
            color: #ef4444;
            margin-top: 4px;
            font-weight: 600;
        }

        .vmodal-actions { display: flex; gap: 12px; justify-content: flex-end; }
        .vmodal-btn-book { background: #f59e0b; color: #000; font-weight: 700; padding: 10px 22px; border-radius: 10px; border: none; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }
        .vmodal-btn-book:hover { background: #d97706; color: #fff; }
        .vmodal-btn-close { background: transparent; border: 1px solid #94a3b8; color: inherit; padding: 10px 18px; border-radius: 10px; cursor: pointer; font-weight: 500; }
    `;
    document.head.appendChild(modalStyle);

    function buildModalDOM() {
        if (document.getElementById('vehicleDetailModal')) return;
        const modalWrap = document.createElement('div');
        modalWrap.className = 'vmodal-overlay';
        modalWrap.id = 'vehicleDetailModal';
        modalWrap.onclick = function(e) {
            if (e.target === modalWrap) closeVehicleDetailsModal();
        };
        modalWrap.innerHTML = `
            <div class="vmodal-card">
                <div class="vmodal-header">
                    <div>
                        <h3 class="vmodal-title" id="vmTitle">Vehicle Details</h3>
                        <span id="vmCategory" style="font-size:0.8rem; color:#94a3b8;">Category</span>
                    </div>
                    <button type="button" class="vmodal-close" onclick="closeVehicleDetailsModal()">&times;</button>
                </div>
                <img src="" alt="" class="vmodal-banner" id="vmImage">
                
                <div class="vmodal-service-badge">
                    <div class="vmodal-service-item">
                        <span class="vmodal-service-label">🛠️ Anthimata Service Karapu Date (Last Serviced)</span>
                        <span class="vmodal-service-val" id="vmLastService">2026-08-15</span>
                    </div>
                    <div class="vmodal-service-item">
                        <span class="vmodal-service-label">📋 Vehicle Code / Plate</span>
                        <span class="vmodal-service-val" id="vmCode" style="color:#38bdf8;">LEGACY-1</span>
                    </div>
                    <div class="vmodal-service-item">
                        <span class="vmodal-service-label">🟢 Status</span>
                        <span class="vmodal-service-val" id="vmStatus" style="color:#22c55e;">Available</span>
                    </div>
                </div>

                <div class="vmodal-specs-grid">
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">📍 Location</span><span class="vmodal-spec-detail" id="vmLocation">Matara</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">🗓️ Year</span><span class="vmodal-spec-detail" id="vmYear">2024</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">👥 Capacity</span><span class="vmodal-spec-detail" id="vmSeats">4 Seats</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">⚙️ Transmission</span><span class="vmodal-spec-detail" id="vmTransmission">Automatic</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">⛽ Fuel Type</span><span class="vmodal-spec-detail" id="vmFuel">Petrol</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">🚪 Doors / Bags</span><span class="vmodal-spec-detail" id="vmDoorsBags">4 Doors, 2 Bags</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">🚘 Service Type</span><span class="vmodal-spec-detail" id="vmServiceType">Both</span></div>
                    <div class="vmodal-spec-box"><span class="vmodal-spec-name">💰 Daily Rate</span><span class="vmodal-spec-detail" id="vmPrice" style="color:#f59e0b;">$35.00 / day</span></div>
                </div>

                <!-- Calendar View Container -->
                <div class="vm-calendar-wrapper" id="vmCalendarWrapper">
                    <div class="vm-cal-header">
                        <div class="vm-cal-title">
                            <span>📅 Booked Dates Calendar</span>
                        </div>
                        <div class="vm-cal-nav">
                            <button type="button" class="vm-cal-nav-btn" onclick="navVmCalendar(-1)">&lt;</button>
                            <span class="vm-cal-month-label" id="vmCalMonthLabel">Sep 2026</span>
                            <button type="button" class="vm-cal-nav-btn" onclick="navVmCalendar(1)">&gt;</button>
                        </div>
                    </div>

                    <div class="vm-cal-weekdays">
                        <span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span>
                    </div>

                    <div class="vm-cal-days-grid" id="vmCalDaysGrid">
                        <!-- Calendar Days dynamically injected -->
                    </div>

                    <div class="vm-booked-ranges-list" id="vmBookedRangesList">
                        <!-- List of active booking periods -->
                    </div>
                </div>

                <div class="vmodal-desc" id="vmDesc">
                    Comprehensive maintenance history verified. This vehicle is regularly serviced at authorized service centers, sanitized after every rental, and thoroughly inspected for brakes, tires, engine performance, and safety systems.
                </div>

                <div class="vmodal-actions">
                    <button type="button" class="vmodal-btn-close" onclick="closeVehicleDetailsModal()">Close</button>
                    <a href="book.html" class="vmodal-btn-book" id="vmBookBtn">Book Now</a>
                </div>
            </div>
        `;
        document.body.appendChild(modalWrap);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', buildModalDOM);
    } else {
        buildModalDOM();
    }
})();

let vmCalendarCurrentDate = new Date();
let vmCurrentCarObject = null;

function renderVehicleBookingCalendar(car, year, month) {
    const grid = document.getElementById('vmCalDaysGrid');
    const label = document.getElementById('vmCalMonthLabel');
    const list = document.getElementById('vmBookedRangesList');
    if (!grid || !label || !list) return;

    grid.innerHTML = '';
    list.innerHTML = '';

    const viewDate = new Date(year, month, 1);
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    label.innerText = `${monthNames[month]} ${year}`;

    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDaysInMonth = new Date(year, month + 1, 0).getDate();

    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

    const bookedRanges = (car && Array.isArray(car.bookedRanges)) ? car.bookedRanges : [];

    // Fill empty offset slots
    for (let i = 0; i < firstDayIndex; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'vm-cal-day empty';
        grid.appendChild(emptyCell);
    }

    // Fill days
    for (let day = 1; day <= totalDaysInMonth; day++) {
        const cell = document.createElement('div');
        cell.className = 'vm-cal-day';
        cell.innerText = day;

        const currentFormatted = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

        if (currentFormatted === todayStr) {
            cell.classList.add('today');
        }

        // Check if date falls in any booked range
        let matchingRange = null;
        for (const range of bookedRanges) {
            if (range.pickupDate && range.dropoffDate) {
                if (currentFormatted >= range.pickupDate && currentFormatted <= range.dropoffDate) {
                    matchingRange = range;
                    break;
                }
            }
        }

        if (matchingRange) {
            cell.classList.add('booked');
            cell.title = `🔒 Booked: ${matchingRange.pickupDate} to ${matchingRange.dropoffDate} (${matchingRange.bookingRef || 'Reserved'})`;
        }

        grid.appendChild(cell);
    }

    // Render summary list
    if (bookedRanges.length > 0) {
        let html = '<div style="font-weight:700; color:#ef4444; margin-bottom:6px;">🔒 Current / Upcoming Booked Periods:</div>';
        bookedRanges.forEach(r => {
            html += `<div class="vm-range-item">
                <span>📅 ${r.pickupDate} &rarr; ${r.dropoffDate}</span>
                <span style="font-size:0.72rem; background:rgba(239,68,68,0.2); padding:2px 6px; border-radius:4px;">Ref: ${r.bookingRef || 'N/A'}</span>
            </div>`;
        });
        list.innerHTML = html;
    } else {
        list.innerHTML = '<div style="color:#22c55e; font-weight:600;">✅ Vehicle is available for booking on all upcoming dates.</div>';
    }
}

window.navVmCalendar = function(direction) {
    vmCalendarCurrentDate.setMonth(vmCalendarCurrentDate.getMonth() + direction);
    if (vmCurrentCarObject) {
        renderVehicleBookingCalendar(vmCurrentCarObject, vmCalendarCurrentDate.getFullYear(), vmCalendarCurrentDate.getMonth());
    }
};

window.showVehicleDetailsModal = async function(car) {
    if (!car) return;
    vmCurrentCarObject = car;
    vmCalendarCurrentDate = new Date();

    // Close any public booked calendar popups when viewing Info modal
    const pubCal1 = document.getElementById('publicBookedCalendarModal');
    if (pubCal1) pubCal1.style.display = 'none';
    const pubCal2 = document.getElementById('publicBookingCalendarModal');
    if (pubCal2) pubCal2.style.setProperty('display', 'none', 'important');

    let modal = document.getElementById('vehicleDetailModal');
    if (!modal) {
        if (typeof buildModalDOM === 'function') buildModalDOM();
        modal = document.getElementById('vehicleDetailModal');
    }
    if (!modal) return;

    document.getElementById('vmTitle').innerText = car.name || 'Vehicle Details';
    document.getElementById('vmCategory').innerText = (car.brand ? (car.brand + ' • ') : '') + (car.category || car.type || 'Standard');
    document.getElementById('vmImage').src = car.image || 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80';
    
    // Service Date
    const lastService = car.lastServiceDate || car.last_service_date || '2026-08-15';
    document.getElementById('vmLastService').innerText = lastService;
    
    document.getElementById('vmCode').innerText = car.id || car.vehicle_code || car.plate || 'V001';
    const vehicleIsMaintenance = !!car.isUnderMaintenance || ['maintenance','service','repair','under maintenance','under service','in service','servicing','under repair'].includes(String(car.status || '').toLowerCase());
    document.getElementById('vmStatus').innerText = vehicleIsMaintenance ? '🔧 Under Maintenance — Booking Disabled' : (car.alreadyBooked ? '🔒 Already Booked for Selected Dates' : (car.status || 'Available'));
    document.getElementById('vmStatus').style.color = vehicleIsMaintenance || car.alreadyBooked ? '#ef4444' : '#22c55e';

    document.getElementById('vmLocation').innerText = car.location || 'Matara';
    document.getElementById('vmYear').innerText = car.year || 2024;
    document.getElementById('vmSeats').innerText = (car.seats || 4) + ' Seats';
    document.getElementById('vmTransmission').innerText = car.transmission || 'Automatic';
    document.getElementById('vmFuel').innerText = car.fuel || 'Petrol';
    document.getElementById('vmDoorsBags').innerText = (car.doors || 4) + ' Doors, ' + (car.bags || 2) + ' Bags';
    document.getElementById('vmServiceType').innerText = car.serviceType || car.service_type || 'Both';

    // Price calculation matching active currency
    const currency = localStorage.getItem('siteCurrency') || 'USD';
    const rateLKR = 337.3489;
    const priceUSD = Number(car.priceUSD || car.price) || 35;
    if (currency === 'LKR') {
        const lkrVal = priceUSD * rateLKR;
        document.getElementById('vmPrice').innerText = 'LKR ' + lkrVal.toLocaleString('en-US', {maximumFractionDigits:2}) + ' / day';
    } else {
        document.getElementById('vmPrice').innerText = 'US$ ' + priceUSD.toFixed(2) + ' / day';
    }

    const bookBtn = document.getElementById('vmBookBtn');
    if (vehicleIsMaintenance) {
        bookBtn.style.display = 'inline-flex';
        bookBtn.textContent = '🔧 Under Maintenance';
        bookBtn.href = '#';
        bookBtn.classList.add('disabled-booking');
        bookBtn.onclick = function(e){ e.preventDefault(); return false; };
    } else if (car.alreadyBooked) {
        bookBtn.style.display = 'inline-flex';
        bookBtn.textContent = '🔒 Already Booked';
        bookBtn.href = '#';
        bookBtn.classList.add('disabled-booking');
        bookBtn.onclick = function(e){ e.preventDefault(); return false; };
    } else {
        bookBtn.style.display = 'inline-flex';
        bookBtn.textContent = 'Book Now';
        bookBtn.classList.remove('disabled-booking');
        bookBtn.onclick = null;
        bookBtn.href = `book.html?id=${encodeURIComponent(car.id || '')}&name=${encodeURIComponent(car.name || '')}`;
    }

    // Fetch active bookings if not attached
    if (!Array.isArray(car.bookedRanges)) {
        try {
            const vParam = encodeURIComponent(car.id || car.name || '');
            const resp = await fetch(`customer-api.php?action=vehicle_bookings&vehicle_id=${vParam}`);
            if (resp.ok) {
                const data = await resp.json();
                if (data.success && Array.isArray(data.bookedRanges)) {
                    car.bookedRanges = data.bookedRanges;
                    if (!vehicleIsMaintenance) {
                        car.alreadyBooked = car.bookedRanges.length > 0;
                        document.getElementById('vmStatus').innerText = car.alreadyBooked
                            ? '🔒 Already Booked for Selected Dates'
                            : (car.status || 'Available');
                        document.getElementById('vmStatus').style.color = car.alreadyBooked ? '#ef4444' : '#22c55e';
                        if (car.alreadyBooked) {
                            bookBtn.textContent = '🔒 Already Booked';
                            bookBtn.href = '#';
                            bookBtn.classList.add('disabled-booking');
                            bookBtn.onclick = function(e){ e.preventDefault(); return false; };
                        }
                    }
                }
            }
        } catch (e) {
            console.warn('Could not fetch vehicle bookings for calendar', e);
        }
    }

    renderVehicleBookingCalendar(vmCurrentCarObject, vmCalendarCurrentDate.getFullYear(), vmCalendarCurrentDate.getMonth());

    modal.classList.add('active');
};

window.closeVehicleDetailsModal = function() {
    const modal = document.getElementById('vehicleDetailModal');
    if (modal) modal.classList.remove('active');
};

