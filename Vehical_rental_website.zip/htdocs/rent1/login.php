<?php
session_start();
if (isset($_SESSION['customer_id'])) {
    header('Location: 1.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Login | Chamikara Rent A Car</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Arial,sans-serif;background:linear-gradient(135deg,#07111f,#111827);display:flex;align-items:center;justify-content:center;color:#fff;padding:20px}.card{width:min(440px,100%);background:rgba(17,24,39,.95);border:1px solid rgba(255,255,255,.12);border-radius:22px;padding:36px;box-shadow:0 25px 70px rgba(0,0,0,.45);text-align:center}.logo{font-size:42px;margin-bottom:8px}.card h1{margin:0 0 8px;font-size:30px}.card p{color:#aab4c5;margin-bottom:28px}.google{display:flex;align-items:center;justify-content:center;gap:12px;width:100%;padding:14px 18px;border-radius:10px;border:1px solid #d1d5db;background:#fff;color:#1f2937;text-decoration:none;font-weight:700;font-size:16px;transition:.2s}.google:hover{transform:translateY(-1px);box-shadow:0 8px 25px rgba(0,0,0,.25)}.gicon{font-size:22px;font-weight:900}.back{display:inline-block;margin-top:22px;color:#f59e0b;text-decoration:none}.note{font-size:12px;color:#7f8ba0!important;margin-top:24px!important;margin-bottom:0!important}
</style>
<link rel="stylesheet" href="liquid-buttons.css">
<link rel="stylesheet" href="liquid-fullsite.css">
</head>
<body>
<div class="card">
    <div class="logo">🚗</div>
    <h1>Customer Login</h1>
    <p>Sign in to Chamikara Rent A Car using your Google account.</p>
    <a class="google" href="google-login.php"><span class="gicon">G</span> Continue with Google</a>
    <a class="back" href="1.html">← Back to Home</a>
    <p class="note">Your Google password is never stored by this website.</p>
</div>
<script src="liquid-click.js"></script>
</body>
</html>
