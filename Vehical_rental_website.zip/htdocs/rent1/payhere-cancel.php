<?php
$orderId = trim((string)($_GET['order_id'] ?? ''));
header('Location: book.html?payment_return=1&payment_cancelled=1&order_id=' . rawurlencode($orderId));
exit;
?>
