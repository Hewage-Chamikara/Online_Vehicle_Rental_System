<?php
session_start();
require_once __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function jsonResponse(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requireLogin(): int
{
    if (empty($_SESSION['customer_id'])) {
        jsonResponse([
            'success' => false,
            'loggedIn' => false,
            'message' => 'Please login first.'
        ], 401);
    }
    return (int) $_SESSION['customer_id'];
}


function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Customer-facing vehicle prices are reduced by 10%. The database keeps the
// original fleet price so Admin can continue managing the base rate.
const CUSTOMER_VEHICLE_DISCOUNT = 0.10;

function customerVehiclePrice(float $basePrice): float
{
    return round($basePrice * (1 - CUSTOMER_VEHICLE_DISCOUNT), 2);
}

function getCustomer(mysqli $conn, int $customerId): ?array
{
    $stmt = $conn->prepare(
        'SELECT id, name, email, profile_image, phone, nic, address, license_no
         FROM customers WHERE id = ? LIMIT 1'
    );
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $customer ?: null;
}

$action = $_GET['action'] ?? '';

// Public vehicle catalogue. This reads the exact same vehicles table used by
// the standalone admin site, so Admin Add/Edit/Delete changes appear here.
if ($action === 'vehicles') {
    try {
        $checkPickup = trim((string)($_GET['pickup'] ?? ''));
        $checkDropoff = trim((string)($_GET['dropoff'] ?? ''));
        $result = $conn->query("SELECT id, vehicle_code, name, brand, location, category, plate, year, seats, doors, transmission, fuel, ac, bags, price_usd, service_type, image, status, active, last_service_date FROM vehicles WHERE active=1 ORDER BY id ASC");
        $vehicles = [];
        while ($row = $result->fetch_assoc()) {
            $dbId = (int)$row['id'];
            $serviceDate = !empty($row['last_service_date']) 
                ? $row['last_service_date'] 
                : date('Y-m-d', strtotime('-' . (($dbId * 7) % 30 + 5) . ' days'));
            
            $vid = (string)$row['id'];
            $vcode = !empty($row['vehicle_code']) ? (string)$row['vehicle_code'] : '';
            $vname = trim((string)($row['name'] ?? ''));
            $vslug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $vname));

            // Fetch active / upcoming bookings. The normal booking flow stores the
            // numeric vehicles.id, while older data may contain a vehicle code/name.
            $bs = $conn->prepare("SELECT booking_ref, pickup_date, dropoff_date, status FROM bookings
                WHERE (vehicle_id = ? OR vehicle_id = ? OR LOWER(vehicle_id) = LOWER(?) OR LOWER(vehicle_name) = LOWER(?))
                  AND status NOT IN ('Cancelled','Completed')
                  AND pickup_date IS NOT NULL AND dropoff_date IS NOT NULL
                  AND dropoff_date >= CURDATE()
                ORDER BY pickup_date ASC");
            $bs->bind_param('ssss', $vid, $vcode, $vslug, $vname);
            $bs->execute();
            $bRes = $bs->get_result();
            $bookedRanges = [];
            while ($br = $bRes->fetch_assoc()) {
                $bookedRanges[] = [
                    'bookingRef' => $br['booking_ref'],
                    'pickupDate' => $br['pickup_date'],
                    'dropoffDate' => $br['dropoff_date'],
                    'status' => $br['status']
                ];
            }
            $bs->close();

            $isAlreadyBooked = false;
            $bookingRef = null;

            // Any current/upcoming confirmed booking makes the vehicle card
            // visibly unavailable to every user. The calendar below shows the
            // exact booked date range(s) publicly.
            $isAlreadyBooked = !empty($bookedRanges);
            $bookingRef = $isAlreadyBooked ? $bookedRanges[0]['bookingRef'] : null;

            $stRaw = strtolower(trim((string)($row['status'] ?? '')));
            $isUnderMaintenance = in_array($stRaw, ['maintenance', 'service', 'repair', 'under maintenance'], true);

            $vehicles[] = [
                'id' => $row['vehicle_code'] ?: (string)$row['id'],
                'dbId' => $dbId,
                'name' => $vname ?: 'Vehicle',
                'brand' => $row['brand'] ?: '',
                'location' => $row['location'] ?: 'Matara',
                'category' => $row['category'] ?: 'Medium',
                'seats' => (int)$row['seats'],
                'doors' => (int)$row['doors'],
                'transmission' => $row['transmission'] ?: 'Automatic',
                'fuel' => $row['fuel'] ?: 'Petrol',
                'ac' => (bool)$row['ac'],
                'bags' => (int)$row['bags'],
                'priceUSD' => customerVehiclePrice((float)$row['price_usd']),
                'originalPriceUSD' => (float)$row['price_usd'],
                'discountPercent' => (int)(CUSTOMER_VEHICLE_DISCOUNT * 100),
                'serviceType' => $row['service_type'] ?: 'Both',
                'image' => $row['image'] ?: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80',
                'status' => $isUnderMaintenance ? 'Maintenance' : ($row['status'] ?: 'Available'),
                'isUnderMaintenance' => $isUnderMaintenance,
                'lastServiceDate' => $serviceDate,
                'year' => !empty($row['year']) ? (int)$row['year'] : 2024,
                'plate' => !empty($row['plate']) ? $row['plate'] : ('CAB-' . (5000 + $dbId)),
                'alreadyBooked' => ($isAlreadyBooked || $isUnderMaintenance),
                'bookingRef' => $bookingRef,
                'bookedRanges' => $bookedRanges
            ];
        }
        jsonResponse(['success'=>true, 'vehicles'=>$vehicles]);
    } catch (Throwable $e) {
        jsonResponse(['success'=>false, 'message'=>'Could not load vehicle inventory: '.$e->getMessage()], 500);
    }
}

// Dedicated endpoint to fetch all active booked date ranges for a specific vehicle
if ($action === 'vehicle_bookings') {
    $vId = trim((string)($_GET['vehicle_id'] ?? ''));
    if ($vId === '') {
        jsonResponse(['success' => false, 'message' => 'Vehicle ID is required'], 400);
    }

    // Resolve the public vehicle id/code/name to the canonical DB vehicle id.
    // Bookings store the numeric vehicles.id, while the browser may send vehicle_code.
    $vehicleDbId = null;
    $vehicleName = '';
    $vehicleCode = '';

    if (ctype_digit($vId)) {
        $vs = $conn->prepare('SELECT id, name, vehicle_code FROM vehicles WHERE id = ? LIMIT 1');
        $tmpId = (int)$vId;
        $vs->bind_param('i', $tmpId);
    } else {
        $vs = $conn->prepare('SELECT id, name, vehicle_code FROM vehicles WHERE vehicle_code = ? OR LOWER(name) = LOWER(?) LIMIT 1');
        $vs->bind_param('ss', $vId, $vId);
    }
    $vs->execute();
    $vehicle = $vs->get_result()->fetch_assoc();
    $vs->close();

    if ($vehicle) {
        $vehicleDbId = (string)$vehicle['id'];
        $vehicleName = trim((string)$vehicle['name']);
        $vehicleCode = trim((string)($vehicle['vehicle_code'] ?? ''));
    }

    if ($vehicleDbId !== null) {
        $bs = $conn->prepare(
            "SELECT booking_ref, vehicle_name, pickup_date, dropoff_date, status
             FROM bookings
             WHERE vehicle_id = ?
               AND status NOT IN ('Cancelled','Completed')
               AND pickup_date IS NOT NULL AND dropoff_date IS NOT NULL
               AND dropoff_date >= CURDATE()
             ORDER BY pickup_date ASC"
        );
        $bs->bind_param('s', $vehicleDbId);
    } else {
        // Fallback for older bookings that may have stored a code/name.
        $searchName = '%' . strtolower($vId) . '%';
        $bs = $conn->prepare(
            "SELECT booking_ref, vehicle_name, pickup_date, dropoff_date, status
             FROM bookings
             WHERE (LOWER(vehicle_name) = LOWER(?) OR LOWER(vehicle_id) = LOWER(?) OR LOWER(vehicle_id) LIKE ?)
               AND status NOT IN ('Cancelled','Completed')
               AND pickup_date IS NOT NULL AND dropoff_date IS NOT NULL
               AND dropoff_date >= CURDATE()
             ORDER BY pickup_date ASC"
        );
        $bs->bind_param('sss', $vId, $vId, $searchName);
    }

    $bs->execute();
    $res = $bs->get_result();
    $ranges = [];
    while ($row = $res->fetch_assoc()) {
        $ranges[] = [
            'bookingRef' => $row['booking_ref'],
            'vehicleName' => $row['vehicle_name'],
            'pickupDate' => $row['pickup_date'],
            'dropoffDate' => $row['dropoff_date'],
            'status' => $row['status']
        ];
    }
    $bs->close();

    jsonResponse([
        'success' => true,
        'vehicle_id' => $vehicleDbId ?? $vId,
        'vehicle_code' => $vehicleCode,
        'vehicle_name' => $vehicleName,
        'bookedRanges' => $ranges
    ]);
}

// Current logged-in customer
if ($action === 'me') {
    $customerId = requireLogin();
    $customer = getCustomer($conn, $customerId);

    if (!$customer) {
        session_destroy();
        jsonResponse(['success' => false, 'loggedIn' => false], 401);
    }

    jsonResponse([
        'success' => true,
        'loggedIn' => true,
        'customer' => $customer
    ]);
}

$customerId = requireLogin();

// Cart list
if ($action === 'cart') {
    $stmt = $conn->prepare(
        'SELECT ci.id, ci.vehicle_id, ci.vehicle_name, ci.total_price, ci.currency,
                ci.pickup_date, ci.dropoff_date, ci.rental_days, ci.created_at,
                v.status AS vehicle_status
         FROM cart_items ci
         LEFT JOIN vehicles v ON (CAST(v.id AS CHAR) = ci.vehicle_id OR v.vehicle_code = ci.vehicle_id OR LOWER(v.name) = LOWER(ci.vehicle_name))
         WHERE ci.customer_id = ?
         ORDER BY ci.id DESC'
    );
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $result = $stmt->get_result();
    $cart = [];

    while ($row = $result->fetch_assoc()) {
        $row['id'] = (int) $row['id'];
        $row['total_price'] = (float) $row['total_price'];
        $row['rental_days'] = (int) $row['rental_days'];
        // Front-end compatible field names
        $row['total'] = $row['total_price'];
        $row['name'] = $row['vehicle_name'];
        $row['pickup'] = $row['pickup_date'];
        $row['dropoff'] = $row['dropoff_date'];
        $row['days'] = $row['rental_days'];
        $st = strtolower(trim((string)($row['vehicle_status'] ?? '')));
        $row['isUnderMaintenance'] = in_array($st, ['maintenance','service','repair','under maintenance','under service','in service','servicing','under repair'], true);
        $row['status'] = $row['isUnderMaintenance'] ? 'Maintenance' : ($row['vehicle_status'] ?: 'Available');
        $cart[] = $row;
    }
    $stmt->close();

    jsonResponse([
        'success' => true,
        'cart' => $cart,
        'count' => count($cart)
    ]);
}

// Add/remove one vehicle in this customer's cart
if ($action === 'add_cart') {
    $input = requestBody();

    $vehicleId = trim((string)($input['vehicle_id'] ?? ''));
    $vehicleName = trim((string)($input['vehicle_name'] ?? ''));
    $totalPrice = (float)($input['total_price'] ?? 0);
    $currency = trim((string)($input['currency'] ?? 'USD')) ?: 'USD';
    $pickupDate = !empty($input['pickup_date']) ? (string)$input['pickup_date'] : null;
    $dropoffDate = !empty($input['dropoff_date']) ? (string)$input['dropoff_date'] : null;
    $rentalDays = max(1, (int)($input['rental_days'] ?? 1));

    if ($vehicleId === '' || $vehicleName === '') {
        jsonResponse(['success' => false, 'message' => 'Vehicle information is missing.'], 400);
    }

    // Check if vehicle is under maintenance
    $vs = $conn->prepare('SELECT status, active FROM vehicles WHERE id = ? OR vehicle_code = ? OR name = ? LIMIT 1');
    $vs->bind_param('sss', $vehicleId, $vehicleId, $vehicleName);
    $vs->execute();
    $vRow = $vs->get_result()->fetch_assoc();
    $vs->close();
    if ($vRow) {
        $st = strtolower(trim((string)($vRow['status'] ?? '')));
        if (in_array($st, ['maintenance', 'service', 'repair', 'under maintenance'], true)) {
            jsonResponse(['success' => false, 'message' => 'This vehicle is currently under maintenance and cannot be added to cart.'], 409);
        }
        // Keep cart totals consistent with the same 10% customer discount.
        $priceStmt = $conn->prepare('SELECT price_usd FROM vehicles WHERE id = ? OR vehicle_code = ? OR name = ? LIMIT 1');
        $priceStmt->bind_param('sss', $vehicleId, $vehicleId, $vehicleName);
        $priceStmt->execute();
        $priceRow = $priceStmt->get_result()->fetch_assoc();
        $priceStmt->close();
        if ($priceRow) {
            $totalPrice = customerVehiclePrice((float)$priceRow['price_usd']) * $rentalDays;
        }
    }

    $stmt = $conn->prepare(
        'SELECT id FROM cart_items
         WHERE customer_id = ? AND vehicle_id = ? LIMIT 1'
    );
    $stmt->bind_param('is', $customerId, $vehicleId);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existing) {
        $cartId = (int)$existing['id'];
        $stmt = $conn->prepare(
            'DELETE FROM cart_items WHERE id = ? AND customer_id = ?'
        );
        $stmt->bind_param('ii', $cartId, $customerId);
        $stmt->execute();
        $stmt->close();

        jsonResponse([
            'success' => true,
            'action' => 'removed',
            'message' => 'Vehicle removed from cart.'
        ]);
    }

    $stmt = $conn->prepare(
        'INSERT INTO cart_items
         (customer_id, vehicle_id, vehicle_name, total_price, currency,
          pickup_date, dropoff_date, rental_days)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->bind_param(
        'issdsssi',
        $customerId,
        $vehicleId,
        $vehicleName,
        $totalPrice,
        $currency,
        $pickupDate,
        $dropoffDate,
        $rentalDays
    );
    $stmt->execute();
    $stmt->close();

    jsonResponse([
        'success' => true,
        'action' => 'added',
        'message' => 'Vehicle added to cart.'
    ]);
}

// Remove one cart row
if ($action === 'remove_cart') {
    $input = requestBody();
    $cartId = (int)($input['cart_id'] ?? 0);

    if ($cartId <= 0) {
        jsonResponse(['success' => false, 'message' => 'Invalid cart item.'], 400);
    }

    $stmt = $conn->prepare(
        'DELETE FROM cart_items WHERE id = ? AND customer_id = ?'
    );
    $stmt->bind_param('ii', $cartId, $customerId);
    $stmt->execute();
    $deleted = $stmt->affected_rows;
    $stmt->close();

    jsonResponse([
        'success' => true,
        'deleted' => $deleted > 0
    ]);
}

// Clear only this customer's cart
if ($action === 'clear_cart') {
    $stmt = $conn->prepare('DELETE FROM cart_items WHERE customer_id = ?');
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $stmt->close();

    jsonResponse(['success' => true, 'message' => 'Cart cleared.']);
}

function saveNicPhoto(?string $dataOrUrl, string $prefix, string $bookingRef): ?string
{
    if (empty($dataOrUrl)) return null;
    if (str_starts_with($dataOrUrl, 'uploads/')) return $dataOrUrl;
    if (preg_match('/^data:(image\/(\w+)|application\/pdf);base64,/', $dataOrUrl, $type)) {
        $data = substr($dataOrUrl, strpos($dataOrUrl, ',') + 1);
        $ext = !empty($type[2]) ? strtolower($type[2]) : 'jpg';
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf'])) $ext = 'jpg';
        $decoded = base64_decode($data);
        if ($decoded === false) return null;
        $dir = __DIR__ . '/uploads/nic';
        if (!is_dir($dir)) @mkdir($dir, 0777, true);
        $filename = $prefix . '_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $bookingRef) . '_' . time() . '.' . $ext;
        file_put_contents($dir . '/' . $filename, $decoded);
        return 'uploads/nic/' . $filename;
    }
    return null;
}

// Booking list
if ($action === 'bookings') {
    $stmt = $conn->prepare(
        'SELECT id, booking_ref, vehicle_id, vehicle_name, vehicle_image,
                vehicle_category, customer_name, customer_email, customer_phone,
                pickup_date, dropoff_date, pickup_location, dropoff_location,
                rental_days, price_usd, payment_method, status, addons, nic_front, nic_back, created_at
         FROM bookings
         WHERE customer_id = ?
         ORDER BY id DESC'
    );
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = [];

    while ($row = $result->fetch_assoc()) {
        $addons = json_decode((string)($row['addons'] ?? ''), true);
        if (!is_array($addons)) $addons = [];

        $bookings[] = [
            'id' => $row['booking_ref'],
            'databaseId' => (int)$row['id'],
            'vehicleId' => $row['vehicle_id'],
            'carName' => $row['vehicle_name'],
            'carImage' => $row['vehicle_image'],
            'category' => $row['vehicle_category'],
            'customerName' => $row['customer_name'],
            'email' => $row['customer_email'],
            'phone' => $row['customer_phone'],
            'pickupDate' => $row['pickup_date'],
            'dropoffDate' => $row['dropoff_date'],
            'pickupLocation' => $row['pickup_location'],
            'dropoffLocation' => $row['dropoff_location'],
            'days' => (int)$row['rental_days'],
            'priceUSD' => (float)$row['price_usd'],
            'paymentMethod' => $row['payment_method'],
            'status' => $row['status'],
            'addons' => $addons,
            'nicFront' => $row['nic_front'],
            'nicBack' => $row['nic_back'],
            'createdAt' => $row['created_at']
        ];
    }
    $stmt->close();

    jsonResponse([
        'success' => true,
        'bookings' => $bookings,
        'count' => count($bookings)
    ]);
}

// Get the payment/booking status for the logged-in customer's booking.
if ($action === 'booking_status') {
    $bookingRef = trim((string)($_GET['booking_id'] ?? ''));
    if ($bookingRef === '') {
        jsonResponse(['success' => false, 'message' => 'Booking ID is required.'], 400);
    }
    $stmt = $conn->prepare(
        'SELECT booking_ref, vehicle_name, vehicle_image, vehicle_category,
                customer_name, customer_email, customer_phone, pickup_date, dropoff_date,
                pickup_location, dropoff_location, rental_days, price_usd, payment_method,
                status, payment_status, payment_id, payment_method_gateway,
                paid_amount, paid_currency, payment_message
         FROM bookings WHERE booking_ref = ? AND customer_id = ? LIMIT 1'
    );
    $stmt->bind_param('si', $bookingRef, $customerId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) {
        jsonResponse(['success' => false, 'message' => 'Booking not found.'], 404);
    }
    jsonResponse(['success' => true, 'booking' => $row]);
}

// Create booking for current customer. Identity comes from PHP session,
// not from browser-submitted customer ID/name/email.
if ($action === 'create_booking') {
    $input = requestBody();
    $customer = getCustomer($conn, $customerId);

    if (!$customer) {
        jsonResponse(['success' => false, 'message' => 'Customer account was not found.'], 401);
    }

    // NEVER trust the vehicle name sent by the browser.
    // Resolve the selected vehicle from the SAME vehicles table used by Fleet.
    $vehicleId = trim((string)($input['vehicle_id'] ?? ''));
    $vehicleName = '';
    $vehicleImage = '';
    $vehicleCategory = 'Vehicle';

    if ($vehicleId === '') {
        jsonResponse(['success' => false, 'message' => 'Vehicle information is missing.'], 400);
    }

    $vehicleRow = null;
    if (ctype_digit($vehicleId)) {
        $vs = $conn->prepare('SELECT id, name, image, category, price_usd, status, active FROM vehicles WHERE id = ? LIMIT 1');
        $vidInt = (int)$vehicleId;
        $vs->bind_param('i', $vidInt);
    } else {
        $vs = $conn->prepare('SELECT id, name, image, category, price_usd, status, active FROM vehicles WHERE vehicle_code = ? LIMIT 1');
        $vs->bind_param('s', $vehicleId);
    }
    $vs->execute();
    $vehicleRow = $vs->get_result()->fetch_assoc();
    $vs->close();

    if (!$vehicleRow || (int)$vehicleRow['active'] !== 1) {
        jsonResponse(['success' => false, 'message' => 'This vehicle is not available.'], 409);
    }
    $vehicleStatus = strtolower(trim((string)$vehicleRow['status']));
    if (in_array($vehicleStatus, ['maintenance','service','repair','under maintenance','under service','in service','servicing','under repair'], true)) {
        jsonResponse(['success' => false, 'message' => 'This vehicle is currently under maintenance and cannot be booked.'], 409);
    }
    if ($vehicleStatus !== 'available') {
        jsonResponse(['success' => false, 'message' => 'This vehicle is not available.'], 409);
    }

    // Canonical vehicle data comes from DB. Example: exactly "Suzuki Alto".
    $vehicleId = (string)$vehicleRow['id'];
    $vehicleName = trim((string)$vehicleRow['name']);
    $vehicleImage = trim((string)($vehicleRow['image'] ?? ''));
    $vehicleCategory = trim((string)($vehicleRow['category'] ?? 'Vehicle'));

    // Use the current database price, not a browser-manipulated price.
    $originalBasePriceUSD = (float)$vehicleRow['price_usd'];
    $basePriceUSD = customerVehiclePrice($originalBasePriceUSD);
    $customerPhone = trim((string)($input['customer_phone'] ?? $customer['phone'] ?? ''));
    $customerNic = trim((string)($input['nic_number'] ?? $customer['nic'] ?? ''));
    $customerLicense = trim((string)($input['license_no'] ?? $customer['license_no'] ?? ''));
    $pickupDate = !empty($input['pickup_date']) ? (string)$input['pickup_date'] : null;
    $dropoffDate = !empty($input['dropoff_date']) ? (string)$input['dropoff_date'] : null;
    $pickupLocation = trim((string)($input['pickup_location'] ?? ''));
    $dropoffLocation = trim((string)($input['dropoff_location'] ?? ''));
    $rentalDays = max(1, (int)($input['rental_days'] ?? 1));
    $paymentMethod = trim((string)($input['payment_method'] ?? ''));
    $addonsArray = isset($input['addons']) && is_array($input['addons']) ? $input['addons'] : [];
    $addons = json_encode($addonsArray, JSON_UNESCAPED_UNICODE);

    // Calculate the payable total on the server so the PayHere amount cannot be
    // changed by editing the browser. These match the rates shown in book.html.
    $dailyAddonUSD = 0.0;
    if (in_array('Full Insurance', $addonsArray, true)) $dailyAddonUSD += 12.0;
    if (in_array('GPS Navigation', $addonsArray, true)) $dailyAddonUSD += 5.0;
    if (in_array('Child Seat', $addonsArray, true)) $dailyAddonUSD += 4.0;
    if (in_array('Driver Included', $addonsArray, true)) $dailyAddonUSD += 25.0;
    $priceUSD = ($basePriceUSD + $dailyAddonUSD) * $rentalDays;

    $isSelfDrive = isset($input['is_self_drive']) ? (bool)$input['is_self_drive'] : (!in_array('Driver Included', $addonsArray));
    $nicFrontRaw = trim((string)($input['nic_front'] ?? ''));
    $nicBackRaw = trim((string)($input['nic_back'] ?? ''));

    if ($isSelfDrive && (empty($nicFrontRaw) || empty($nicBackRaw))) {
        jsonResponse([
            'success' => false,
            'message' => 'Self-drive rental requires uploading both Front and Back photos of your NIC.'
        ], 400);
    }

    if ($vehicleId === '' || $vehicleName === '') {
        jsonResponse(['success' => false, 'message' => 'Vehicle information is missing.'], 400);
    }

    // Server-side booking availability check.
    // Same vehicle + overlapping dates = cannot book.
    $availability = $conn->prepare(
        "SELECT booking_ref FROM bookings
         WHERE vehicle_id = ?
           AND (
               status NOT IN ('Cancelled','Completed','Pending Payment')
               OR (status = 'Pending Payment' AND created_at >= (NOW() - INTERVAL 30 MINUTE))
           )
           AND pickup_date IS NOT NULL AND dropoff_date IS NOT NULL
           AND pickup_date <= ? AND dropoff_date >= ?
         LIMIT 1"
    );
    $availability->bind_param('sss', $vehicleId, $dropoffDate, $pickupDate);
    $availability->execute();
    $alreadyBooked = $availability->get_result()->fetch_assoc();
    $availability->close();

    if ($alreadyBooked) {
        jsonResponse([
            'success' => false,
            'message' => 'This vehicle is already booked for the selected dates.',
            'bookingRef' => $alreadyBooked['booking_ref']
        ], 409);
    }

    $bookingRef = 'BK-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
    $isPayHerePending = !empty($input['payhere_pending']);
    $status = $isPayHerePending ? 'Pending Payment' : 'Confirmed';
    $paymentStatus = $isPayHerePending ? 'PENDING' : 'UNPAID';

    $nicFrontPath = saveNicPhoto($nicFrontRaw, 'nic_front', $bookingRef);
    $nicBackPath = saveNicPhoto($nicBackRaw, 'nic_back', $bookingRef);

    if ($customerPhone !== '' || $customerNic !== '' || $customerLicense !== '') {
        $updateCustomer = $conn->prepare('UPDATE customers SET phone = ?, nic = ?, license_no = ? WHERE id = ?');
        $updateCustomer->bind_param('sssi', $customerPhone, $customerNic, $customerLicense, $customerId);
        $updateCustomer->execute();
        $updateCustomer->close();
    }

    $stmt = $conn->prepare(
        'INSERT INTO bookings
        (booking_ref, customer_id, vehicle_id, vehicle_name, vehicle_image,
         vehicle_category, customer_name, customer_email, customer_phone,
         pickup_date, dropoff_date, pickup_location, dropoff_location,
         rental_days, price_usd, payment_method, status, addons, nic_front, nic_back)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );

    $stmt->bind_param(
        'sisssssssssssidsssss',
        $bookingRef,
        $customerId,
        $vehicleId,
        $vehicleName,
        $vehicleImage,
        $vehicleCategory,
        $customer['name'],
        $customer['email'],
        $customerPhone,
        $pickupDate,
        $dropoffDate,
        $pickupLocation,
        $dropoffLocation,
        $rentalDays,
        $priceUSD,
        $paymentMethod,
        $status,
        $addons,
        $nicFrontPath,
        $nicBackPath
    );

    // Remove the booked vehicle from this customer's cart only.
    $conn->begin_transaction();
    try {
        $stmt->execute();
        $stmt->close();

        $paymentUpdate = $conn->prepare(
            'UPDATE bookings SET payment_status = ? WHERE booking_ref = ?'
        );
        $paymentUpdate->bind_param('ss', $paymentStatus, $bookingRef);
        $paymentUpdate->execute();
        $paymentUpdate->close();

        // Cash bookings are immediately confirmed, so remove from cart now.
        // PayHere bookings remain in the cart until PayHere confirms payment.
        if (!$isPayHerePending) {
            $remove = $conn->prepare(
                'DELETE FROM cart_items WHERE customer_id = ? AND vehicle_id = ?'
            );
            $remove->bind_param('is', $customerId, $vehicleId);
            $remove->execute();
            $remove->close();
        }

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        if (isset($stmt) && $stmt instanceof mysqli_stmt) $stmt->close();
        jsonResponse(['success' => false, 'message' => 'Booking could not be saved.'], 500);
    }

    jsonResponse([
        'success' => true,
        'bookingId' => $bookingRef,
        'message' => 'Booking saved successfully.'
    ]);
}


// Update the live location of a vehicle picked up by the logged-in customer.
// The booking must belong to this customer and be active today.
if ($action === 'gps_update') {
    $input = requestBody();
    $bookingRef = trim((string)($input['booking_id'] ?? ''));
    $lat = filter_var($input['latitude'] ?? null, FILTER_VALIDATE_FLOAT);
    $lng = filter_var($input['longitude'] ?? null, FILTER_VALIDATE_FLOAT);
    $accuracy = filter_var($input['accuracy'] ?? null, FILTER_VALIDATE_FLOAT);
    $speed = filter_var($input['speed'] ?? null, FILTER_VALIDATE_FLOAT);
    $heading = filter_var($input['heading'] ?? null, FILTER_VALIDATE_FLOAT);

    if ($bookingRef === '' || $lat === false || $lng === false || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        jsonResponse(['success'=>false,'message'=>'Invalid GPS coordinates.'],400);
    }

    $stmt=$conn->prepare("SELECT booking_ref, customer_id, vehicle_id, vehicle_name, pickup_date, dropoff_date, status
                          FROM bookings WHERE booking_ref=? AND customer_id=? LIMIT 1");
    $stmt->bind_param('si',$bookingRef,$customerId);
    $stmt->execute();
    $booking=$stmt->get_result()->fetch_assoc();
    $stmt->close();

    if(!$booking) jsonResponse(['success'=>false,'message'=>'Booking not found.'],404);
    $status=strtolower(trim((string)$booking['status']));
    $today=date('Y-m-d');
    if(in_array($status,['cancelled','completed'],true) ||
       (!empty($booking['pickup_date']) && $today < $booking['pickup_date']) ||
       (!empty($booking['dropoff_date']) && $today > $booking['dropoff_date'])) {
        jsonResponse(['success'=>false,'message'=>'Live tracking is only available while this rental is active.'],403);
    }

    $stmt=$conn->prepare("INSERT INTO vehicle_gps_locations
        (booking_ref,customer_id,vehicle_id,latitude,longitude,accuracy,speed,heading)
        VALUES (?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
          customer_id=VALUES(customer_id),vehicle_id=VALUES(vehicle_id),
          latitude=VALUES(latitude),longitude=VALUES(longitude),accuracy=VALUES(accuracy),
          speed=VALUES(speed),heading=VALUES(heading),updated_at=CURRENT_TIMESTAMP");
    $acc = ($accuracy===false ? null : $accuracy);
    $spd = ($speed===false ? null : $speed);
    $hdg = ($heading===false ? null : $heading);
    $stmt->bind_param('sisddddd',$bookingRef,$customerId,$booking['vehicle_id'],$lat,$lng,$acc,$spd,$hdg);
    $stmt->execute();
    $stmt->close();
    jsonResponse(['success'=>true,'updatedAt'=>date('c'),'vehicle'=>$booking['vehicle_name']]);
}

// Return the logged-in customer's active bookings so the tracking page can choose the picked vehicle.
if ($action === 'gps_bookings') {
    $stmt=$conn->prepare("SELECT booking_ref,vehicle_id,vehicle_name,pickup_date,dropoff_date,pickup_location,dropoff_location,status
                          FROM bookings
                          WHERE customer_id=? AND LOWER(TRIM(status)) NOT IN ('cancelled','completed')
                          ORDER BY id DESC");
    $stmt->bind_param('i',$customerId);
    $stmt->execute();
    $r=$stmt->get_result();
    $items=[];
    while($row=$r->fetch_assoc()) $items[]=$row;
    $stmt->close();
    jsonResponse(['success'=>true,'bookings'=>$items]);
}

// Cancel one booking belonging to current customer
if ($action === 'cancel_booking') {
    $input = requestBody();
    $bookingRef = trim((string)($input['booking_id'] ?? ''));

    if ($bookingRef === '') {
        jsonResponse(['success' => false, 'message' => 'Invalid booking.'], 400);
    }

    $stmt = $conn->prepare(
        "UPDATE bookings SET status = 'Cancelled'
         WHERE booking_ref = ? AND customer_id = ? AND status <> 'Cancelled'"
    );
    $stmt->bind_param('si', $bookingRef, $customerId);
    $stmt->execute();
    $updated = $stmt->affected_rows;
    $stmt->close();

    jsonResponse([
        'success' => true,
        'updated' => $updated > 0,
        'message' => $updated > 0 ? 'Booking cancelled. The vehicle is available again.' : 'Booking was not found or already cancelled.'
    ]);
}

// Clear booking history for current customer
if ($action === 'clear_bookings') {
    $stmt = $conn->prepare('DELETE FROM bookings WHERE customer_id = ?');
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $stmt->close();

    jsonResponse(['success' => true, 'message' => 'Booking history cleared.']);
}

jsonResponse(['success' => false, 'message' => 'Invalid API action.'], 400);
?>
