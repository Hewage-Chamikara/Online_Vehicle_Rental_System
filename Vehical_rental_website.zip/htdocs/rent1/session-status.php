<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'loggedIn' => isset($_SESSION['customer_id']),
    'customer' => isset($_SESSION['customer_id']) ? [
        'id' => (int)$_SESSION['customer_id'],
        'name' => $_SESSION['customer_name'] ?? '',
        'email' => $_SESSION['customer_email'] ?? '',
        'image' => $_SESSION['customer_image'] ?? ''
    ] : null
]);
?>
