CREATE DATABASE IF NOT EXISTS vehicle_rental
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE vehicle_rental;

CREATE TABLE IF NOT EXISTS customers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    google_id VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    profile_image TEXT NULL,
    phone VARCHAR(30) NULL,
    nic VARCHAR(30) NULL,
    address VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cart_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL,
    vehicle_id VARCHAR(100) NOT NULL,
    vehicle_name VARCHAR(150) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
    pickup_date DATE NULL,
    dropoff_date DATE NULL,
    rental_days INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cart_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_cart_customer (customer_id),
    UNIQUE KEY uq_customer_vehicle (customer_id, vehicle_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bookings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_ref VARCHAR(50) NOT NULL UNIQUE,
    customer_id INT UNSIGNED NOT NULL,
    vehicle_id VARCHAR(100) NOT NULL,
    vehicle_name VARCHAR(150) NOT NULL,
    vehicle_image TEXT NULL,
    vehicle_category VARCHAR(100) NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_email VARCHAR(190) NOT NULL,
    customer_phone VARCHAR(30) NULL,
    pickup_date DATE NULL,
    dropoff_date DATE NULL,
    pickup_location VARCHAR(150) NULL,
    dropoff_location VARCHAR(150) NULL,
    rental_days INT NOT NULL DEFAULT 1,
    price_usd DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Confirmed',
    addons TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    payment_status VARCHAR(30) NOT NULL DEFAULT 'UNPAID',
    payment_id VARCHAR(100) NULL,
    payment_method_gateway VARCHAR(50) NULL,
    paid_amount DECIMAL(10,2) NULL,
    paid_currency VARCHAR(10) NULL,
    payment_message VARCHAR(255) NULL,
    payment_updated_at TIMESTAMP NULL DEFAULT NULL,
    CONSTRAINT fk_booking_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_booking_customer (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS vehicle_gps_locations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_ref VARCHAR(50) NOT NULL,
    customer_id INT UNSIGNED NOT NULL,
    vehicle_id VARCHAR(100) NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    accuracy DECIMAL(10,2) NULL,
    speed DECIMAL(10,2) NULL,
    heading DECIMAL(10,2) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_gps_booking (booking_ref),
    INDEX idx_gps_vehicle (vehicle_id),
    INDEX idx_gps_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
