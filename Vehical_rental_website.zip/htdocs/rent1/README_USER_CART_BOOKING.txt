CHAMIKARA RENT A CAR - Google User Cart & Booking Update

1. Put the rent1 folder directly inside C:\xampp\htdocs\

2. Import database.sql into phpMyAdmin. It creates/keeps:
   - customers
   - cart_items
   - bookings

3. Open config.php and replace:
   PASTE_YOUR_NEW_GOOGLE_CLIENT_SECRET_HERE
   with the NEW Client Secret from Google Cloud Console.
   Do not share the secret.

4. Google Cloud Console OAuth client settings:
   Authorized JavaScript origin:
   http://localhost

   Authorized redirect URI:
   http://localhost/rent1/google-callback.php

5. Open the site only through XAMPP/PHP:
   http://localhost/rent1/1.html

6. User-specific behaviour:
   - Google user name is shown in the Login/Logout button.
   - Cart belongs to the logged-in customer_id.
   - Bookings belong to the logged-in customer_id.
   - Logout does NOT delete database data.
   - When logged out, Cart and My Bookings show 0/empty.
   - When the same Google user logs in again, their previous cart/bookings are loaded from MySQL.
   - A different Google user sees only their own cart/bookings.
   - A booked vehicle is removed from that same user's cart.
   - localStorage is still used only for site theme/currency/admin demo settings, not customer cart/bookings.

7. If Google says "The provided client secret is invalid", the secret in config.php is wrong/old. Create a new secret and replace it.
