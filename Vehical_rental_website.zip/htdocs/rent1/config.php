<?php
// ============================================================
// Chamikara Rent A Car - Google OAuth + MySQL Configuration
// ============================================================

const GOOGLE_CLIENT_ID = '549406339301-c8q79u0e4cs5namlmqmi2ek7i6g5kqrp.apps.googleusercontent.com';

// IMPORTANT: Google no longer lets you view/download a lost secret.
// Create a NEW client secret in Google Cloud Console and paste it here.
// Do NOT share the secret publicly.
const GOOGLE_CLIENT_SECRET = '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';

// This must exactly match Google Cloud Console -> Authorized redirect URIs.
const GOOGLE_REDIRECT_URI = 'http://localhost/rent1/google-callback.php';

const GOOGLE_SUCCESS_REDIRECT = '1.html';

const DB_HOST = 'localhost';
const DB_NAME = 'vehicle_rental';
const DB_USER = 'root';
const DB_PASS = '';

// ============================================================
// PayHere Sandbox Configuration
// Keep the Merchant Secret server-side only. Never put it in JS.
// ============================================================
const PAYHERE_MERCHANT_ID = '1238401';
const PAYHERE_MERCHANT_SECRET = 'MzEzNTQ1Njc5MDI4ODUwNDMwNjczMjgyMzQ2MzM1NDk1MTc4NDMx';
const PAYHERE_SANDBOX = true;

// For localhost development PayHere cannot call the notify URL.
// Set this to a public HTTPS URL (for example an ngrok tunnel) when
// testing payment callbacks from PayHere Sandbox.
const PAYHERE_NOTIFY_URL = 'http://localhost/rent1/payhere-notify.php';

?>
