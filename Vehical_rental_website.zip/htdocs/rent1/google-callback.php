<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function failAuth(string $message): never
{
    http_response_code(400);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Google Login Error</title><link rel="stylesheet" href="liquid-buttons.css">
<link rel="stylesheet" href="liquid-fullsite.css">
</head><body style="font-family:Arial,sans-serif;background:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh"><div style="background:#fff;max-width:560px;width:90%;padding:30px;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.12)"><h2 style="color:#d32f2f">Google Login Error</h2><p style="line-height:1.6;color:#555">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><p><a href="login.php" style="display:inline-block;padding:10px 18px;background:#f59e0b;color:#111;text-decoration:none;border-radius:8px">Back to Login</a></p></div><script src="liquid-click.js"></script>
</body></html>';
    exit;
}

if (isset($_GET['error'])) {
    $error = (string)$_GET['error'];
    $description = (string)($_GET['error_description'] ?? 'Google login was cancelled or denied.');
    failAuth($error === 'access_denied' ? 'You cancelled the Google login.' : $description);
}

if (empty($_GET['state']) || empty($_SESSION['oauth_state'])) {
    failAuth('OAuth session information is missing. Please start Google Login again.');
}

if (!hash_equals((string)$_SESSION['oauth_state'], (string)$_GET['state'])) {
    unset($_SESSION['oauth_state']);
    failAuth('Invalid OAuth state. Please start Google Login again.');
}
unset($_SESSION['oauth_state']);

if (empty($_GET['code'])) {
    failAuth('Authorization code was not received from Google.');
}

if (GOOGLE_CLIENT_SECRET === 'PASTE_YOUR_NEW_GOOGLE_CLIENT_SECRET_HERE') {
    failAuth('Google Client Secret is not configured. Open config.php and paste the NEW Client Secret from Google Cloud Console.');
}

$tokenData = [
    'code' => (string)$_GET['code'],
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'grant_type' => 'authorization_code'
];

$ch = curl_init('https://oauth2.googleapis.com/token');
if ($ch === false) failAuth('Could not initialize the Google token request.');

curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query($tokenData, '', '&', PHP_QUERY_RFC3986),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
]);

$tokenResponse = curl_exec($ch);
$curlError = curl_error($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($tokenResponse === false) {
    failAuth('Could not connect to Google: ' . ($curlError ?: 'unknown connection error'));
}

$tokens = json_decode($tokenResponse, true);
if (!is_array($tokens) || empty($tokens['access_token'])) {
    $googleMessage = is_array($tokens)
        ? (string)($tokens['error_description'] ?? $tokens['error'] ?? '')
        : '';

    if ($httpCode === 401 || ($tokens['error'] ?? '') === 'invalid_client') {
        failAuth('The Google Client Secret is invalid. Create a NEW Client Secret in Google Cloud Console and replace GOOGLE_CLIENT_SECRET in config.php.');
    }

    failAuth('Google token request failed.' . ($googleMessage ? ' ' . $googleMessage : ''));
}

$ch = curl_init('https://openidconnect.googleapis.com/v1/userinfo');
if ($ch === false) failAuth('Could not initialize the Google profile request.');

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $tokens['access_token']]
]);

$userResponse = curl_exec($ch);
$curlError = curl_error($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($userResponse === false) {
    failAuth('Could not retrieve your Google profile: ' . ($curlError ?: 'unknown connection error'));
}

$user = json_decode($userResponse, true);
if ($httpCode < 200 || $httpCode >= 300 || !is_array($user) || empty($user['sub']) || empty($user['email'])) {
    failAuth('Google profile information is incomplete or could not be verified.');
}

if (isset($user['email_verified']) && $user['email_verified'] !== true) {
    failAuth('Your Google email address is not verified.');
}

$googleId = (string)$user['sub'];
$name = trim((string)($user['name'] ?? 'Google User')) ?: 'Google User';
$email = strtolower(trim((string)$user['email']));
$profileImage = trim((string)($user['picture'] ?? ''));

// Find the existing account by Google ID.
$stmt = $conn->prepare('SELECT id, name, email, profile_image, phone, nic, address FROM customers WHERE google_id = ? LIMIT 1');
$stmt->bind_param('s', $googleId);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$customer) {
    // If the email already belongs to an account, link that account to Google.
    $stmt = $conn->prepare('SELECT id, name, email, profile_image, phone, nic, address FROM customers WHERE email = ? LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($customer) {
        $stmt = $conn->prepare('UPDATE customers SET google_id = ?, name = ?, profile_image = ? WHERE id = ?');
        $customerId = (int)$customer['id'];
        $stmt->bind_param('sssi', $googleId, $name, $profileImage, $customerId);
        $stmt->execute();
        $stmt->close();
        $customer['name'] = $name;
        $customer['email'] = $email;
        $customer['profile_image'] = $profileImage;
    } else {
        $stmt = $conn->prepare('INSERT INTO customers (google_id, name, email, profile_image) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('ssss', $googleId, $name, $email, $profileImage);
        $stmt->execute();
        $newId = (int)$stmt->insert_id;
        $stmt->close();

        $customer = [
            'id' => $newId,
            'name' => $name,
            'email' => $email,
            'profile_image' => $profileImage,
            'phone' => null,
            'nic' => null,
            'address' => null
        ];
    }
} else {
    $customerId = (int)$customer['id'];
    $stmt = $conn->prepare('UPDATE customers SET name = ?, email = ?, profile_image = ? WHERE id = ?');
    $stmt->bind_param('sssi', $name, $email, $profileImage, $customerId);
    $stmt->execute();
    $stmt->close();
    $customer['name'] = $name;
    $customer['email'] = $email;
    $customer['profile_image'] = $profileImage;
}

session_regenerate_id(true);
$_SESSION['customer_id'] = (int)$customer['id'];
$_SESSION['customer_name'] = $customer['name'];
$_SESSION['customer_email'] = $customer['email'];
$_SESSION['customer_image'] = $customer['profile_image'];

header('Location: ' . GOOGLE_SUCCESS_REDIRECT);
exit;
?>
