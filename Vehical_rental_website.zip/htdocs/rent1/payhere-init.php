<?php
session_start();
require_once __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function respond(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (empty($_SESSION['customer_id'])) {
    respond(['success' => false, 'message' => 'Please login first.'], 401);
}

$customerId = (int)$_SESSION['customer_id'];
$bookingRef = trim((string)($_GET['booking_id'] ?? $_POST['booking_id'] ?? ''));

if ($bookingRef === '') {
    respond(['success' => false, 'message' => 'Booking ID is required.'], 400);
}

$stmt = $conn->prepare(
    'SELECT b.booking_ref, b.vehicle_name, b.price_usd, b.status, b.payment_status,
            c.name, c.email, c.phone, c.address
     FROM bookings b
     INNER JOIN customers c ON c.id = b.customer_id
     WHERE b.booking_ref = ? AND b.customer_id = ? LIMIT 1'
);
$stmt->bind_param('si', $bookingRef, $customerId);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    respond(['success' => false, 'message' => 'Booking not found.'], 404);
}
if ($booking['status'] !== 'Pending Payment' || $booking['payment_status'] !== 'PENDING') {
    respond(['success' => false, 'message' => 'This booking is not awaiting PayHere payment.'], 409);
}

$amount = number_format((float)$booking['price_usd'], 2, '.', '');
$currency = 'USD';
$orderId = $booking['booking_ref'];

$hash = strtoupper(md5(
    PAYHERE_MERCHANT_ID .
    $orderId .
    $amount .
    $currency .
    strtoupper(md5(PAYHERE_MERCHANT_SECRET))
));

$nameParts = preg_split('/\s+/', trim((string)$booking['name']), -1, PREG_SPLIT_NO_EMPTY);
$firstName = $nameParts[0] ?? 'Customer';
$lastName = count($nameParts) > 1 ? implode(' ', array_slice($nameParts, 1)) : 'Customer';
$phone = trim((string)$booking['phone']);
if ($phone === '') {
    respond(['success' => false, 'message' => 'Please add a phone number to your customer profile before paying.'], 400);
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base = $scheme . '://' . $host . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$returnUrl = $base . '/payhere-return.php?order_id=' . rawurlencode($orderId);
$cancelUrl = $base . '/payhere-cancel.php?order_id=' . rawurlencode($orderId);
$notifyUrl = PAYHERE_NOTIFY_URL;

respond([
    'success' => true,
    'action' => PAYHERE_SANDBOX ? 'https://sandbox.payhere.lk/pay/checkout' : 'https://www.payhere.lk/pay/checkout',
    'fields' => [
        'merchant_id' => PAYHERE_MERCHANT_ID,
        'return_url' => $returnUrl,
        'cancel_url' => $cancelUrl,
        'notify_url' => $notifyUrl,
        'first_name' => $firstName,
        'last_name' => $lastName,
        'email' => (string)$booking['email'],
        'phone' => $phone,
        'address' => trim((string)($booking['address'] ?: 'Sri Lanka')),
        'city' => 'Colombo',
        'country' => 'Sri Lanka',
        'order_id' => $orderId,
        'items' => $booking['vehicle_name'] . ' Rental',
        'currency' => $currency,
        'amount' => $amount,
        'hash' => $hash
    ]
]);
