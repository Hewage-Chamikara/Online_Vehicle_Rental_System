<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/db.php';
$conn->query("CREATE TABLE IF NOT EXISTS chat_messages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, customer_id INT UNSIGNED NOT NULL, sender ENUM('customer','admin') NOT NULL, message TEXT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_chat_customer (customer_id), INDEX idx_chat_created (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
if(empty($_SESSION['customer_id'])){ http_response_code(401); echo json_encode(['success'=>false,'message'=>'Please login to use Live Chat.']); exit; }
$cid=(int)$_SESSION['customer_id']; $jsonInput=json_decode(file_get_contents('php://input'), true); if(!is_array($jsonInput)) $jsonInput=[]; $action=$_GET['action'] ?? $_POST['action'] ?? ($jsonInput['action'] ?? 'list');
if($action==='list'){
  $stmt=$conn->prepare("SELECT id,sender,message,DATE_FORMAT(created_at,'%H:%i') time,created_at FROM chat_messages WHERE customer_id=? ORDER BY id ASC");
  $stmt->bind_param('i',$cid); $stmt->execute(); echo json_encode(['success'=>true,'messages'=>$stmt->get_result()->fetch_all(MYSQLI_ASSOC)]); exit;
}
if($action==='send'){
  $msg=trim((string)($_POST['message'] ?? $jsonInput['message'] ?? '')); if($msg===''){http_response_code(400);echo json_encode(['success'=>false,'message'=>'Message is required.']);exit;}
  $stmt=$conn->prepare("INSERT INTO chat_messages(customer_id,sender,message) VALUES(?,'customer',?)"); $stmt->bind_param('is',$cid,$msg); $stmt->execute(); echo json_encode(['success'=>true,'id'=>$stmt->insert_id]); exit;
}
echo json_encode(['success'=>false,'message'=>'Invalid action.']);
?>