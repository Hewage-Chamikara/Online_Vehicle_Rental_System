GOOGLE OAUTH SETUP - CHAMIKARA RENT A CAR
==========================================

YOUR CURRENT LOCAL WEBSITE URL:
http://localhost/rent1googleloauth/rent1/1.html

1. Put this rent1 folder inside:
   C:\xampp\htdocs\rent1googleloauth\rent1

2. Start Apache and MySQL in XAMPP.

3. Open phpMyAdmin and import:
   database.sql

4. The supplied config.php already contains the Client ID and Client Secret you provided.

5. In Google Cloud Console, create/use a Web application OAuth client.

6. Authorized JavaScript origins:
   http://localhost

7. Authorized redirect URI (EXACT):
   http://localhost/rent1googleloauth/rent1/google-callback.php

8. Open the website through Apache, NOT by double-clicking HTML files:
   http://localhost/rent1googleloauth/rent1/1.html

9. Click Login -> Continue with Google.

10. After successful Google login, the customer is inserted into:
    vehicle_rental.customers

11. Existing customers are matched by Google ID or email.

12. Customer phone, NIC and address can be added later to the same record.

IMPORTANT SECURITY NOTE:
The Client Secret was shared in chat and has therefore been exposed. After confirming that the OAuth setup works, create/regenerate a new Client Secret in Google Cloud Console and replace the old one in config.php. Never publish the secret to GitHub or other public files.
