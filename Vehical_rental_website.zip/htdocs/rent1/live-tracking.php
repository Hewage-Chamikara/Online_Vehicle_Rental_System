<?php
session_start();
require_once __DIR__ . '/db.php';
if (empty($_SESSION['customer_id'])) {
    header('Location: login.php');
    exit;
}
$bookingRef = trim((string)($_GET['booking'] ?? ''));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Live Vehicle GPS • Chamikara Rent A Car</title>
<link rel="stylesheet" href="liquid-fullsite.css">
<link rel="stylesheet" href="liquid-nav.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
body{margin:0;background:#0b1220;color:#e5e7eb;font-family:Arial,sans-serif}
.wrap{max-width:1000px;margin:90px auto 40px;padding:20px}
.card{background:#121a2a;border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:22px;box-shadow:0 15px 45px rgba(0,0,0,.3)}
h1{margin:0 0 8px}.muted{color:#94a3b8}.row{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:18px 0}
select,button{border:1px solid #334155;border-radius:10px;padding:11px 14px;background:#172033;color:#fff}
button{background:#f59e0b;color:#111827;font-weight:700;cursor:pointer}.status{padding:10px 12px;border-radius:10px;background:#0f172a;color:#94a3b8}
#trackerMap{height:520px;border-radius:14px;overflow:hidden;margin-top:16px}
.notice{margin-top:14px;padding:12px;border-radius:10px;background:rgba(56,189,248,.08);color:#bae6fd;font-size:13px}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>📍 Live Vehicle GPS</h1>
    <p class="muted">Share this phone's location while you have the rented vehicle. The rental admin can see the vehicle on the Live GPS Tracker.</p>
    <div class="row">
      <label for="bookingSelect">Active booking:</label>
      <select id="bookingSelect"><option>Loading bookings...</option></select>
      <button id="startBtn">Start Live GPS</button>
      <button id="stopBtn" style="display:none;background:#334155;color:#fff">Stop</button>
      <span id="status" class="status">Not sharing</span>
    </div>
    <div id="trackerMap"></div>
    <div class="notice">Your browser will ask for location permission. For continuous tracking, keep this page open and keep location services enabled. This implementation uses the phone/browser GPS; it does not replace a dedicated vehicle GPS device.</div>
  </div>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
let bookings=[], watchId=null, map=L.map('trackerMap').setView([6.9271,79.8612],11), marker=null, selected='<?= htmlspecialchars($bookingRef, ENT_QUOTES) ?>';
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);

const statusEl=document.getElementById('status');
function setStatus(t){statusEl.textContent=t;}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}

async function loadBookings(){
  const r=await fetch('customer-api.php?action=gps_bookings&_='+Date.now(),{credentials:'same-origin',cache:'no-store'});
  const d=await r.json(); bookings=d.success?d.bookings:[];
  const sel=document.getElementById('bookingSelect');
  if(!bookings.length){sel.innerHTML='<option value="">No active bookings</option>'; return;}
  sel.innerHTML=bookings.map(b=>`<option value="${escapeHtml(b.booking_ref)}">${escapeHtml(b.vehicle_name)} — #${escapeHtml(b.booking_ref)}</option>`).join('');
  if(selected && bookings.some(b=>b.booking_ref===selected)) sel.value=selected;
  selected=sel.value;
}
document.getElementById('bookingSelect').onchange=e=>selected=e.target.value;

async function sendPosition(pos){
  const b=bookings.find(x=>x.booking_ref===selected);
  if(!b) return;
  const c=pos.coords;
  const body={booking_id:selected,latitude:c.latitude,longitude:c.longitude,accuracy:c.accuracy,speed:c.speed,heading:c.heading};
  try{
    const r=await fetch('customer-api.php?action=gps_update',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const d=await r.json();
    if(!d.success){setStatus(d.message||'GPS update rejected'); return;}
    setStatus('Live • '+new Date().toLocaleTimeString());
    if(marker) marker.setLatLng([c.latitude,c.longitude]);
    else marker=L.marker([c.latitude,c.longitude]).addTo(map);
    marker.bindPopup('<strong>'+escapeHtml(b.vehicle_name)+'</strong><br>Booking #'+escapeHtml(b.booking_ref)).openPopup();
    map.setView([c.latitude,c.longitude],16);
  }catch(e){setStatus('Network error — retrying...');}
}
document.getElementById('startBtn').onclick=()=>{
  if(!selected){setStatus('Select an active booking first');return;}
  if(!navigator.geolocation){setStatus('GPS is not supported by this browser');return;}
  watchId=navigator.geolocation.watchPosition(sendPosition,err=>{
    setStatus(err.code===1?'Location permission denied': 'GPS signal unavailable');
  },{enableHighAccuracy:true,maximumAge:5000,timeout:15000});
  document.getElementById('startBtn').style.display='none';
  document.getElementById('stopBtn').style.display='';
  setStatus('Requesting GPS permission...');
};
document.getElementById('stopBtn').onclick=()=>{
  if(watchId!==null) navigator.geolocation.clearWatch(watchId);
  watchId=null;
  document.getElementById('startBtn').style.display='';
  document.getElementById('stopBtn').style.display='none';
  setStatus('Not sharing');
};
loadBookings().catch(()=>setStatus('Could not load bookings'));
</script>
</body>
</html>
