<?php
require_once __DIR__ . '/db.php';

// PayHere calls this endpoint server-to-server.
// Do not echo a browser page here; only update the database.
$merchantId = (string)($_POST['merchant_id'] ?? '');
$orderId = trim((string)($_POST['order_id'] ?? ''));
$paymentId = trim((string)($_POST['payment_id'] ?? ''));
$payhereAmount = (string)($_POST['payhere_amount'] ?? '');
$payhereCurrency = (string)($_POST['payhere_currency'] ?? '');
$statusCode = (string)($_POST['status_code'] ?? '');
$md5sig = strtoupper(trim((string)($_POST['md5sig'] ?? '')));
$method = trim((string)($_POST['method'] ?? ''));
$statusMessage = trim((string)($_POST['status_message'] ?? ''));

if ($merchantId !== PAYHERE_MERCHANT_ID || $orderId === '' || $md5sig === '') {
    http_response_code(400);
    exit('INVALID');
}

$localMd5 = strtoupper(md5(
    $merchantId .
    $orderId .
    $payhereAmount .
    $payhereCurrency .
    $statusCode .
    strtoupper(md5(PAYHERE_MERCHANT_SECRET))
));

if (!hash_equals($localMd5, $md5sig)) {
    http_response_code(403);
    exit('INVALID SIGNATURE');
}

$stmt = $conn->prepare(
    'SELECT id, customer_id, vehicle_id, price_usd, status, payment_status
     FROM bookings WHERE booking_ref = ? LIMIT 1'
);
$stmt->bind_param('s', $orderId);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    http_response_code(404);
    exit('ORDER NOT FOUND');
}

$expectedAmount = number_format((float)$booking['price_usd'], 2, '.', '');
$receivedAmount = number_format((float)$payhereAmount, 2, '.', '');

if ($payhereCurrency !== 'USD' || $expectedAmount !== $receivedAmount) {
    $msg = 'Payment amount/currency mismatch';
    $up = $conn->prepare(
        "UPDATE bookings SET payment_status='FAILED', payment_id=?, payment_method_gateway=?,
         paid_amount=?, paid_currency=?, payment_message=?, payment_updated_at=NOW()
         WHERE booking_ref=?"
    );
    $up->bind_param('ssdsss', $paymentId, $method, $payhereAmount, $payhereCurrency, $msg, $orderId);
    $up->execute();
    $up->close();
    http_response_code(400);
    exit('AMOUNT MISMATCH');
}

if ($statusCode === '2') {
    // Idempotent success update.
    $conn->begin_transaction();
    try {
        $newStatus = 'Confirmed';
        $newPaymentStatus = 'PAID';
        $up = $conn->prepare(
            "UPDATE bookings SET status=?, payment_status=?, payment_id=?, payment_method_gateway=?,
             payment_method=?, paid_amount=?, paid_currency=?, payment_message=?, payment_updated_at=NOW()
             WHERE booking_ref=?"
        );
        $up->bind_param(
            'sssssdsss',
            $newStatus, $newPaymentStatus, $paymentId, $method,
            $method, $payhereAmount, $payhereCurrency, $statusMessage, $orderId
        );
        $up->execute();
        $up->close();

        $remove = $conn->prepare('DELETE FROM cart_items WHERE customer_id = ? AND vehicle_id = ?');
        $remove->bind_param('is', $booking['customer_id'], $booking['vehicle_id']);
        $remove->execute();
        $remove->close();

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        http_response_code(500);
        exit('DATABASE ERROR');
    }
} elseif ($statusCode === '0') {
    $paymentStatus = 'PENDING';
    $up = $conn->prepare(
        "UPDATE bookings SET payment_status=?, payment_id=?, payment_method_gateway=?,
         paid_amount=?, paid_currency=?, payment_message=?, payment_updated_at=NOW()
         WHERE booking_ref=?"
    );
    $up->bind_param('sssdsss', $paymentStatus, $paymentId, $method, $payhereAmount, $payhereCurrency, $statusMessage, $orderId);
    $up->execute();
    $up->close();
} else {
    $paymentStatus = 'FAILED';
    $newStatus = 'Cancelled';
    $up = $conn->prepare(
        "UPDATE bookings SET status=?, payment_status=?, payment_id=?, payment_method_gateway=?,
         paid_amount=?, paid_currency=?, payment_message=?, payment_updated_at=NOW()
         WHERE booking_ref=?"
    );
    $up->bind_param('sssssdss', $newStatus, $paymentStatus, $paymentId, $method, $payhereAmount, $payhereCurrency, $statusMessage, $orderId);
    $up->execute();
    $up->close();
}

http_response_code(200);
echo 'OK';
