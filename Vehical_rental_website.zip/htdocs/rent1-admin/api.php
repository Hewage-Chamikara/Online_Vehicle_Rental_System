<?php
session_start();
if(empty($_SESSION['admin_id'])){http_response_code(401);header('Content-Type: application/json');echo json_encode(['success'=>false,'message'=>'Unauthorized']);exit;}
require_once __DIR__.'/db.php';
header('Content-Type: application/json; charset=utf-8');
function body(){ $x=json_decode(file_get_contents('php://input'),true); return is_array($x)?$x:$_POST; }
function out($x,$code=200){http_response_code($code);echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
try{
 $a=$_GET['action']??'';
 if($a==='all'){
  $v=[];$r=$conn->query("SELECT id,vehicle_code,name,brand,category,plate,year,seats,doors,transmission,fuel,ac,bags,price_usd,service_type,image,status,active FROM vehicles ORDER BY id DESC");
  while($x=$r->fetch_assoc()){$x['db_id']=(int)$x['id'];$x['id']=$x['vehicle_code'];$x['rate']=(float)$x['price_usd'];$x['hourlyRate']=round($x['rate']/8);$x['seats']=(int)$x['seats'];$x['doors']=(int)$x['doors'];$x['bags']=(int)$x['bags'];$x['ac']=(bool)$x['ac'];$x['active']=(bool)$x['active'];$x['status']=$x['status']?:($x['active']?'Available':'Inactive');$x['features']=['GPS','Airbags','Bluetooth'];$v[]=$x;}
  $b=[];$r=$conn->query("SELECT id,booking_ref,customer_id,customer_name,customer_email,customer_phone,vehicle_id,vehicle_name,pickup_date,dropoff_date,pickup_location,dropoff_location,rental_days,price_usd,status,payment_method,payment_status,created_at FROM bookings ORDER BY id DESC");
  if($r)while($x=$r->fetch_assoc()){$x['id']=$x['booking_ref'];$x['pickupDate']=$x['pickup_date'];$x['returnDate']=$x['dropoff_date'];$x['customerName']=$x['customer_name'];$x['customerEmail']=$x['customer_email'];$x['customerPhone']=$x['customer_phone'];$x['vehicleName']=$x['vehicle_name'];$x['dailyRate']=$x['rental_days']?(float)$x['price_usd']/$x['rental_days']:0;$x['days']=(int)$x['rental_days'];$x['totalAmount']=(float)$x['price_usd'];$x['paymentStatus']=strtoupper((string)($x['payment_status']??''))==='PAID'?'Paid':(strtoupper((string)($x['payment_status']??''))==='PARTIAL'?'Partial':'Unpaid');$x['driverRequested']=false;$b[]=$x;}

  // Live GPS positions for currently active customer rentals.
  if($a==='gps_locations'){
    $rows=[];
    $sql="SELECT g.booking_ref,g.vehicle_id,g.latitude,g.longitude,g.accuracy,g.speed,g.heading,g.updated_at,
                 b.vehicle_name,b.customer_name,b.customer_phone,b.pickup_location,b.dropoff_location,
                 b.pickup_date,b.dropoff_date,b.status,
                 v.vehicle_code,v.plate,v.brand,v.name AS db_vehicle_name
          FROM vehicle_gps_locations g
          INNER JOIN bookings b ON b.booking_ref=g.booking_ref
          LEFT JOIN vehicles v ON (CAST(v.id AS CHAR)=b.vehicle_id OR v.vehicle_code=b.vehicle_id)
          WHERE LOWER(TRIM(b.status)) NOT IN ('cancelled','completed')
          ORDER BY g.updated_at DESC";
    $r=$conn->query($sql);
    if($r) while($x=$r->fetch_assoc()){
      $x['latitude']=(float)$x['latitude'];
      $x['longitude']=(float)$x['longitude'];
      $x['accuracy']=$x['accuracy']!==null?(float)$x['accuracy']:null;
      $x['speed']=$x['speed']!==null?(float)$x['speed']:null;
      $x['heading']=$x['heading']!==null?(float)$x['heading']:null;
      $rows[]=$x;
    }
    out(['success'=>true,'locations'=>$rows,'serverTime'=>date('c')]);
  }

  // Customers + live booking aggregates.
  // Cancelled bookings do not count as rentals or spending.
  $c=[];
  $customerSql="SELECT c.id,c.name,c.email,c.phone,c.nic," .
                "COALESCE(c.license_no,'') AS license_no,c.address,c.profile_image,c.created_at," .
                "COALESCE(agg.total_rentals,0) AS total_rentals," .
                "COALESCE(agg.spent_total,0) AS spent_total," .
                "CASE WHEN COALESCE(agg.total_rentals,0)>0 THEN 'Active Renter' ELSE 'Regular' END AS customer_status" .
                " FROM customers c" .
                " LEFT JOIN (" .
                "SELECT customer_id, COUNT(*) AS total_rentals, COALESCE(SUM(price_usd),0) AS spent_total" .
                " FROM bookings WHERE LOWER(TRIM(status)) NOT IN ('cancelled','canceled') GROUP BY customer_id" .
                ") agg ON agg.customer_id=c.id ORDER BY c.id DESC";
  $r=$conn->query($customerSql);
  if($r) while($x=$r->fetch_assoc()){
    $nic=trim((string)($x['nic']??''));
    $license=trim((string)($x['license_no']??''));
    $x['nicLicense']=$nic!=='' && $license!=='' ? ($nic.' / '.$license) : ($nic!=='' ? $nic : ($license!=='' ? $license : 'Not provided'));
    $x['verified']=($nic!=='' || $license!=='');
    $x['totalRentals']=(int)($x['total_rentals']??0);
    $x['spentTotal']=round((float)($x['spent_total']??0),2);
    $x['rating']=0;
    $x['status']=$x['customer_status']?:'Regular';
    $c[]=$x;
  }
  $cart=[];$r=$conn->query("SELECT ci.id,ci.customer_id,cu.name AS customer_name,cu.email AS customer_email,ci.vehicle_id,ci.vehicle_name,ci.total_price,ci.currency,ci.pickup_date,ci.dropoff_date,ci.rental_days,ci.created_at FROM cart_items ci LEFT JOIN customers cu ON cu.id=ci.customer_id ORDER BY id DESC");if($r)while($x=$r->fetch_assoc()){$x['total_price']=(float)$x['total_price'];$x['total']=$x['total_price'];$x['name']=$x['vehicle_name'];$x['days']=(int)$x['rental_days'];$cart[]=$x;}
  // Dashboard metrics: use both vehicle DB id and vehicle_code so bookings
  // always match the correct vehicle. Cancelled/completed bookings release it.
  $today=date('Y-m-d');
  $activeBookingVehicles=[];
  $blockedBookingVehicles=[];
  $revenue=0.0;
  foreach($b as $bk){
    $status=strtolower(trim((string)($bk['status']??'')));
    $pickup=substr((string)($bk['pickupDate']??''),0,10);
    $dropoff=substr((string)($bk['returnDate']??''),0,10);
    $isCancelled=in_array($status,['cancelled','canceled'],true);
    $isCompleted=($status==='completed');

    if(!$isCancelled){
      $revenue += (float)($bk['totalAmount']??0);
    }

    // Every non-cancelled/non-completed reservation blocks that vehicle,
    // regardless of whether its pickup date is today or in the future.
    if(!$isCancelled && !$isCompleted){
      $dbKey=(string)($bk['vehicle_id']??'');
      $nameKey=(string)($bk['vehicleName']??'');
      if($dbKey!=='') $blockedBookingVehicles['db:'.$dbKey]=true;
      if($nameKey!=='') $blockedBookingVehicles['name:'.strtolower(trim($nameKey))]=true;

      // Active rental means the rental period includes today.
      if($pickup && $dropoff && $pickup <= $today && $dropoff >= $today){
        if($dbKey!=='') $activeBookingVehicles['db:'.$dbKey]=true;
        if($nameKey!=='') $activeBookingVehicles['name:'.strtolower(trim($nameKey))]=true;
      }
    }
  }

  $maintenanceStatuses=['maintenance','service','repair','under service','in service','servicing','under repair'];
  $activeFleet=0;
  $maintenanceAlerts=0;
  $availableVehicles=0;
  $cleanServiced=0;
  foreach($v as $vehicle){
    if(!(bool)$vehicle['active']) continue;
    $activeFleet++;
    $status=strtolower(trim((string)($vehicle['status']??'')));
    if(in_array($status,$maintenanceStatuses,true)){
      $maintenanceAlerts++;
      continue;
    }

    $dbId=(string)($vehicle['db_id']??'');
    $code=(string)($vehicle['id']??$vehicle['vehicle_code']??'');
    $name=strtolower(trim((string)($vehicle['name']??'')));
    $isBlocked=($dbId!=='' && isset($blockedBookingVehicles['db:'.$dbId]))
             || ($code!=='' && isset($blockedBookingVehicles['db:'.$code]))
             || ($name!=='' && isset($blockedBookingVehicles['name:'.$name]));

    if($isBlocked) continue;
    $availableVehicles++;
    $cleanServiced++;
  }

  // Active Rentals = vehicles currently reserved/booked by customers.
  // Count each vehicle only once. A booking is considered active unless
  // it has been cancelled or completed. Match by DB id, vehicle code,
  // or vehicle name so existing bookings are recognised reliably.
  $activeRentalsSet=[];
  foreach($b as $bk){
    $status=strtolower(trim((string)($bk['status']??'')));
    if(in_array($status,['cancelled','canceled','completed'],true)) continue;
    $dbKey=trim((string)($bk['vehicle_id']??''));
    $nameKey=strtolower(trim((string)($bk['vehicleName']??'')));
    if($dbKey!=='') {
      $activeRentalsSet['id:'.$dbKey]=true;
      $activeRentalsSet['code:'.$dbKey]=true;
    }
    if($nameKey!=='') $activeRentalsSet['name:'.$nameKey]=true;
  }

  $activeRentals=0;
  foreach($v as $vehicle){
    if(!(bool)$vehicle['active']) continue;
    $dbId=trim((string)($vehicle['db_id']??''));
    $code=trim((string)($vehicle['id']??$vehicle['vehicle_code']??''));
    $name=strtolower(trim((string)($vehicle['name']??'')));
    $isBooked=($dbId!=='' && isset($activeRentalsSet['id:'.$dbId]))
           || ($code!=='' && isset($activeRentalsSet['code:'.$code]))
           || ($name!=='' && isset($activeRentalsSet['name:'.$name]));
    if($isBooked) $activeRentals++;
  }

  // Fleet utilization is based on customer-booked vehicles against the
  // total active fleet, not only rentals whose dates happen to include today.
  $utilization=$activeFleet>0?round(($activeRentals/$activeFleet)*100,1):0;
   // Build the payment items list, merging customer bookings from the database with invoices
   $inv=[];
   $collected=0.0;
   $pending=0.0;
   $refunded=0.0;
   $seenInvNos=[];

   // 1. Customer bookings from the database (Customer booked vehicles)
   foreach($b as $bk){
     $ref=trim((string)($bk['booking_ref']??$bk['id']??''));
     $invNo='INV-'.strtoupper(substr(preg_replace('/[^A-Za-z0-9]/','',$ref),-4));
     if(isset($seenInvNos[$invNo])) continue;
     $seenInvNos[$invNo]=true;

     $amt=(float)($bk['totalAmount']??$bk['price_usd']??0);
     $stRaw=strtolower(trim((string)($bk['status']??'')));
     $status=($stRaw==='cancelled'||$stRaw==='canceled')?'Refunded':(($stRaw==='completed'||(!empty($bk['payment_method'])&&strtolower($bk['payment_method'])!=='unpaid'))?'Paid':'Pending');

     if($status==='Paid') $collected += $amt;
     elseif($status==='Pending') $pending += $amt;
     elseif($status==='Refunded') $refunded += $amt;

     $ts=strtotime($bk['pickupDate']??$bk['created_at']??'now');
     $formattedDate=$ts?date('M j',$ts):date('M j');
     $vName=$bk['vehicleName']?:'Vehicle';
     $days=(int)($bk['days']?:$bk['rental_days']?:1);
     $desc="{$vName} · {$days} ".($days===1?'day':'days');

     $inv[]=[
       'id'=>'bk_'.$bk['id'],
       'invoice_no'=>$invNo,
       'customer_name'=>$bk['customerName']?:'Customer',
       'customer_email'=>$bk['customerEmail']?:'',
       'description'=>$desc,
       'invoice_date'=>substr($bk['pickupDate']??date('Y-m-d'),0,10),
       'amount'=>$amt,
       'status'=>$status,
       'payment_method'=>$bk['payment_method']?:'Credit Card',
       'formattedDate'=>$formattedDate,
       'amountFormatted'=>'$'.number_format($amt, 0),
       'is_booking'=>true,
       'booking_ref'=>$ref
     ];
   }

   // 2. Recorded invoices from the invoices table (Image 2 rows)
   $r=$conn->query("SELECT id,invoice_no,customer_name,customer_email,description,invoice_date,amount,status,payment_method,created_at FROM invoices ORDER BY id DESC");
   if($r) while($x=$r->fetch_assoc()){
     if(isset($seenInvNos[$x['invoice_no']])) continue;
     $seenInvNos[$x['invoice_no']]=true;
     $amt=(float)$x['amount'];
     $st=$x['status'];
     if($st==='Paid') $collected += $amt;
     elseif($st==='Pending') $pending += $amt;
     elseif($st==='Refunded') $refunded += $amt;
     $ts=strtotime($x['invoice_date']);
     $x['formattedDate']=$ts?date('M j',$ts):$x['invoice_date'];
     $x['amountFormatted']='$'.number_format($amt, 0);
     $x['is_booking']=false;
     $inv[]=$x;
   }

   $pendingBookings=count(array_filter($b,fn($x)=>strtolower(trim((string)($x['status']??'')))==='pending'));
  $maintenanceExpenses = 0.0;
  $activeMaintenanceCost = 0.0;
  $mCostRes = $conn->query("SELECT COALESCE(SUM(estimated_cost),0) AS total_cost, COALESCE(SUM(CASE WHEN LOWER(status) IN ('in progress','maintenance','service','repair','under service','in service','servicing','under repair') THEN estimated_cost ELSE 0 END),0) AS active_cost FROM maintenance");
  if ($mCostRes) {
    $mc = $mCostRes->fetch_assoc();
    $maintenanceExpenses = (float)($mc['total_cost'] ?? 0);
    $activeMaintenanceCost = (float)($mc['active_cost'] ?? 0);
  }
   $metrics=[
     'totalVehicles'=>count($v),
     'activeFleet'=>$activeFleet,
     'activeRentals'=>$activeRentals,
     'availableVehicles'=>$availableVehicles,
     'maintenanceAlerts'=>$maintenanceAlerts,
     'maintenanceExpenses'=>round($maintenanceExpenses,2),
     'activeMaintenanceCost'=>round($activeMaintenanceCost,2),
     'cleanServiced'=>$cleanServiced,
     'fleetUtilization'=>$utilization,
     'totalRevenue'=>round($revenue,2),
     'pendingBookings'=>$pendingBookings,
     'totalCustomers'=>count($c),
     'totalBookings'=>count($b),
     'cartItems'=>count($cart),
     'averageDailyRate'=>$activeFleet?round(array_sum(array_map(fn($x)=>(float)$x['rate'],$v))/max(1,count($v)),2):0,
     'today'=>$today
   ];
   $paymentsSummary=[
     'collected'=>round($collected,2),
     'pending'=>round($pending,2),
     'refunded'=>round($refunded,2),
     'collectedFormatted'=>'$'.number_format($collected, 0),
     'pendingFormatted'=>'$'.number_format($pending, 0),
     'refundedFormatted'=>'$'.number_format($refunded, 0),
     'countAll'=>count($inv),
     'countPaid'=>count(array_filter($inv, fn($i)=>$i['status']==='Paid')),
     'countPending'=>count(array_filter($inv, fn($i)=>$i['status']==='Pending')),
     'countRefunded'=>count(array_filter($inv, fn($i)=>$i['status']==='Refunded'))
   ];
   // Maintenance logs from MySQL
   $mLogs = [];
   $mr = $conn->query("SELECT id, ticket_id, vehicle_id, vehicle_name, issue_description, service_center, estimated_cost, start_date, estimated_return, status, created_at FROM maintenance ORDER BY id DESC");
   if ($mr) {
     while ($mx = $mr->fetch_assoc()) {
       $mLogs[] = [
         'id' => $mx['ticket_id'] ?: ('TKT-' . $mx['id']),
         'db_id' => (int)$mx['id'],
         'vehicleId' => $mx['vehicle_id'],
         'vehicleName' => $mx['vehicle_name'],
         'issue' => $mx['issue_description'],
         'issueDescription' => $mx['issue_description'],
         'serviceCenter' => $mx['service_center'],
         'cost' => (float)$mx['estimated_cost'],
         'startDate' => $mx['start_date'],
         'estimatedReturn' => $mx['estimated_return'],
         'status' => $mx['status']
       ];
     }
   }

   // Chart Data for Revenue & Rental Volume (Last 7 Days)
   $chartLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
   $chartRevenue = [];
   $chartBookings = [];
   for ($i = 6; $i >= 0; $i--) {
     $d = date('Y-m-d', strtotime("-$i days"));
     $dayRev = 0.0;
     $dayBkCount = 0;
     foreach ($b as $bk) {
       $bkDate = substr($bk['created_at'] ?? $bk['pickupDate'] ?? '', 0, 10);
       if ($bkDate === $d) {
         $dayRev += (float)($bk['totalAmount'] ?? $bk['price_usd'] ?? 0);
         $dayBkCount++;
       }
     }
     $chartRevenue[] = round($dayRev, 2);
     $chartBookings[] = $dayBkCount;
   }
   $chartData = [
     'labels' => $chartLabels,
     'revenue' => $chartRevenue,
     'bookings' => $chartBookings,
     'totalRevenue' => $revenue,
     'totalBookings' => count($b)
   ];

   // Chauffeur roster
   $drivers=[];
   $dr=$conn->query("SELECT id,driver_code,name,phone,email,nic,license_no,license_expiry,address,emergency_contact,status,shift_start,shift_end,work_days,next_shift,assigned_vehicle_id,assigned_vehicle_name,daily_rate,trips_completed,rating,notes,active,created_at,updated_at FROM chauffeurs ORDER BY active DESC, name ASC");
   if($dr) while($dx=$dr->fetch_assoc()){
     $dx['db_id']=(int)$dx['id'];
     $dx['id']=$dx['driver_code'];
     $dx['dailyRate']=(float)$dx['daily_rate'];
     $dx['tripsCompleted']=(int)$dx['trips_completed'];
     $dx['rating']=(float)$dx['rating'];
     $dx['active']=(bool)$dx['active'];
     $dx['assignedVehicle']=$dx['assigned_vehicle_name'] ?: 'Unassigned';
     $dx['shiftStart']=$dx['shift_start'] ? substr($dx['shift_start'],0,5) : '';
     $dx['shiftEnd']=$dx['shift_end'] ? substr($dx['shift_end'],0,5) : '';
     $drivers[]=$dx;
   }
   $returns=[];
  $rr=$conn->query("SELECT booking_ref,damage_notes,condition_status,fuel_level,odometer_km,extra_charges,payment_status,payment_notes,returned_at FROM vehicle_returns ORDER BY returned_at DESC");
  if($rr) while($rx=$rr->fetch_assoc()) $returns[$rx['booking_ref']]=$rx;
  out(['success'=>true,'vehicles'=>$v,'bookings'=>$b,'returns'=>$returns,'customers'=>$c,'cart'=>$cart,'invoices'=>$inv,'paymentsSummary'=>$paymentsSummary,'drivers'=>$drivers,'maintenance'=>$mLogs,'chartData'=>$chartData,'settings'=>['companyName'=>'Veloce Car Rental','currency'=>'USD ($)','taxRate'=>8],'metrics'=>$metrics]);
  }
  if($a==='maintenance_add'){
    $d=body();
    $vId=trim((string)($d['vehicleId']??$d['vehicle_id']??''));
    $vName=trim((string)($d['vehicleName']??$d['vehicle_name']??''));
    $issue=trim((string)($d['issue']??$d['issue_description']??'Routine Inspection & Servicing'));
    $center=trim((string)($d['serviceCenter']??$d['service_center']??'AutoBavaria Workshop'));
    $cost=max(0,(float)($d['cost']??$d['estimated_cost']??0));
    $startDate=trim((string)($d['startDate']??$d['start_date']??date('Y-m-d')));
    $estReturn=trim((string)($d['estimatedReturn']??$d['estimated_return']??'In 3 Days'));
    $st='In Progress';

    if($vId==='') out(['success'=>false,'message'=>'Please select a vehicle.'],400);
    $vs=$conn->prepare("SELECT id, vehicle_code, name, status, active FROM vehicles WHERE id=? OR vehicle_code=? OR name=? LIMIT 1");
    $vs->bind_param('sss',$vId,$vId,$vName);
    $vs->execute();
    $vehicle=$vs->get_result()->fetch_assoc();
    $vs->close();
    if(!$vehicle || !(int)$vehicle['active']) out(['success'=>false,'message'=>'Selected vehicle was not found or is inactive.'],404);

    $canonicalId=(string)$vehicle['id'];
    $canonicalName=trim((string)$vehicle['name']);
    $check=$conn->prepare("SELECT id FROM maintenance WHERE vehicle_id IN (?,?) AND LOWER(status) IN ('in progress','maintenance','service','repair','under service','in service','servicing','under repair') LIMIT 1");
    $check->bind_param('ss',$canonicalId,$vId);
    $check->execute();
    $existing=$check->get_result()->fetch_assoc();
    $check->close();
    if($existing) out(['success'=>false,'message'=>'This vehicle is already under maintenance.'],409);

    $ticketId='TKT-'.date('ymdHis').'-'.strtoupper(bin2hex(random_bytes(2)));
    $s=$conn->prepare("INSERT INTO maintenance (ticket_id, vehicle_id, vehicle_name, issue_description, service_center, estimated_cost, start_date, estimated_return, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $s->bind_param('sssssdsss',$ticketId,$canonicalId,$canonicalName,$issue,$center,$cost,$startDate,$estReturn,$st);
    $s->execute();
    $s->close();

    $u=$conn->prepare("UPDATE vehicles SET status='Maintenance' WHERE id=?");
    $u->bind_param('i',$vehicle['id']);
    $u->execute();
    $u->close();

    out(['success'=>true,'ticket_id'=>$ticketId]);
  }
  if($a==='maintenance_status'){
    $d=body();
    $tId=trim((string)($d['ticket_id']??$d['id']??''));
    $st=trim((string)($d['status']??'Completed'));
    $allowed=['In Progress','Completed','Cancelled'];
    if(!in_array($st,$allowed,true)) out(['success'=>false,'message'=>'Invalid maintenance status.'],400);

    $s=$conn->prepare("SELECT id, vehicle_id FROM maintenance WHERE ticket_id=? OR id=? LIMIT 1");
    $s->bind_param('ss',$tId,$tId);$s->execute();$ticket=$s->get_result()->fetch_assoc();$s->close();
    if(!$ticket) out(['success'=>false,'message'=>'Maintenance ticket not found.'],404);

    $u=$conn->prepare("UPDATE maintenance SET status=? WHERE id=?");
    $u->bind_param('si',$st,$ticket['id']);$u->execute();$u->close();

    if(in_array($st,['Completed','Cancelled'],true)){
      $vehicleId=(int)$ticket['vehicle_id'];
      $q=$conn->prepare("SELECT COUNT(*) AS c FROM maintenance WHERE vehicle_id=? AND id<>? AND LOWER(status) IN ('in progress','maintenance','service','repair','under service','in service','servicing','under repair')");
      $q->bind_param('ii',$vehicleId,$ticket['id']);$q->execute();$activeOther=(int)$q->get_result()->fetch_assoc()['c'];$q->close();
      if($activeOther===0){
        $rv=$conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE vehicle_id=? AND status NOT IN ('Cancelled','Completed') AND (dropoff_date IS NULL OR dropoff_date>=CURDATE())");
        $vid=(string)$vehicleId;$rv->bind_param('s',$vid);$rv->execute();$hasBooking=(int)$rv->get_result()->fetch_assoc()['c'];$rv->close();
        $newStatus=$hasBooking>0?'Reserved':'Available';
        $uv=$conn->prepare("UPDATE vehicles SET status=?, last_service_date=CURDATE() WHERE id=?");
        $uv->bind_param('si',$newStatus,$vehicleId);$uv->execute();$uv->close();
      }
    } else {
      $uv=$conn->prepare("UPDATE vehicles SET status='Maintenance' WHERE id=?");
      $uv->bind_param('i',$ticket['vehicle_id']);$uv->execute();$uv->close();
    }
    out(['success'=>true]);
  }
  if($a==='maintenance_delete'){
    $d=body();
    $tId=trim((string)($d['ticket_id']??$d['id']??''));
    $s=$conn->prepare("SELECT id, vehicle_id FROM maintenance WHERE ticket_id=? OR id=? LIMIT 1");
    $s->bind_param('ss',$tId,$tId);$s->execute();$ticket=$s->get_result()->fetch_assoc();$s->close();
    if(!$ticket) out(['success'=>false,'message'=>'Maintenance ticket not found.'],404);
    $del=$conn->prepare("DELETE FROM maintenance WHERE id=?");$del->bind_param('i',$ticket['id']);$del->execute();$del->close();

    $q=$conn->prepare("SELECT COUNT(*) AS c FROM maintenance WHERE vehicle_id=? AND LOWER(status) IN ('in progress','maintenance','service','repair','under service','in service','servicing','under repair')");
    $q->bind_param('i',$ticket['vehicle_id']);$q->execute();$activeOther=(int)$q->get_result()->fetch_assoc()['c'];$q->close();
    if($activeOther===0){
      $rv=$conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE vehicle_id=? AND status NOT IN ('Cancelled','Completed') AND (dropoff_date IS NULL OR dropoff_date>=CURDATE())");
      $vid=(string)$ticket['vehicle_id'];$rv->bind_param('s',$vid);$rv->execute();$hasBooking=(int)$rv->get_result()->fetch_assoc()['c'];$rv->close();
      $newStatus=$hasBooking>0?'Reserved':'Available';
      $uv=$conn->prepare("UPDATE vehicles SET status=? WHERE id=?");$uv->bind_param('si',$newStatus,$ticket['vehicle_id']);$uv->execute();$uv->close();
    }
    out(['success'=>true]);
  }
  if($a==='chauffeur_add'||$a==='chauffeur_update'){
    $d=body(); $name=trim((string)($d['name']??''));
    if($name==='') out(['success'=>false,'message'=>'Chauffeur name is required.'],400);
    $code=trim((string)($d['driver_code']??$d['driverCode']??''));
    if($code==='') $code='CH-'.str_pad((string)((int)($conn->query("SELECT COALESCE(MAX(id),0)+1 n FROM chauffeurs")->fetch_assoc()['n']??1)),4,'0',STR_PAD_LEFT);
    $code=preg_replace('/[^A-Za-z0-9_-]/','',$code);
    $phone=trim((string)($d['phone']??'')); $email=trim((string)($d['email']??'')); $nic=trim((string)($d['nic']??''));
    $license=trim((string)($d['license_no']??$d['license']??''));
    $expiry=trim((string)($d['license_expiry']??'')); $expiry=$expiry!==''?$expiry:null;
    $address=trim((string)($d['address']??'')); $emergency=trim((string)($d['emergency_contact']??''));
    $status=trim((string)($d['status']??'Available')); $allowed=['Available','On Shift','On Leave','Off Duty','Suspended'];
    if(!in_array($status,$allowed,true)) $status='Available';
    $shiftStart=trim((string)($d['shift_start']??$d['shiftStart']??'')); $shiftStart=$shiftStart!==''?$shiftStart:null;
    $shiftEnd=trim((string)($d['shift_end']??$d['shiftEnd']??'')); $shiftEnd=$shiftEnd!==''?$shiftEnd:null;
    $workDays=trim((string)($d['work_days']??$d['workDays']??'Mon,Tue,Wed,Thu,Fri,Sat'));
    $nextShift=trim((string)($d['next_shift']??$d['nextShift']??'')); $nextShift=$nextShift!==''?$nextShift:null;
    $assignedId=trim((string)($d['assigned_vehicle_id']??$d['assignedVehicleId']??'')); $assignedId=$assignedId!==''?$assignedId:null;
    $assignedName=trim((string)($d['assigned_vehicle_name']??$d['assignedVehicle']??'')); $assignedName=$assignedName!==''?$assignedName:null;
    if($assignedId!==null){
      $vs=$conn->prepare("SELECT vehicle_code,name,status,active FROM vehicles WHERE id=? OR vehicle_code=? LIMIT 1"); $vs->bind_param('ss',$assignedId,$assignedId); $vs->execute(); $vv=$vs->get_result()->fetch_assoc(); $vs->close();
      if(!$vv || !(int)$vv['active']) out(['success'=>false,'message'=>'Assigned vehicle was not found or is inactive.'],404);
      if(in_array(strtolower((string)$vv['status']),['maintenance','service','repair','under service','in service','servicing','under repair'],true)) out(['success'=>false,'message'=>'A vehicle under maintenance cannot be assigned to a chauffeur.'],409);
      $assignedId=(string)$vv['vehicle_code']; $assignedName=(string)$vv['name'];
      $ignoreId=(int)($d['db_id']??0);
      $aq=$conn->prepare("SELECT id,name FROM chauffeurs WHERE active=1 AND assigned_vehicle_id=? AND id<>? LIMIT 1");
      $aq->bind_param('si',$assignedId,$ignoreId);$aq->execute();$assignedDriver=$aq->get_result()->fetch_assoc();$aq->close();
      if($assignedDriver) out(['success'=>false,'message'=>'This vehicle is already assigned to chauffeur '.$assignedDriver['name'].'.'],409);
    }
    $rate=max(0,(float)($d['daily_rate']??$d['dailyRate']??0)); $trips=max(0,(int)($d['trips_completed']??$d['tripsCompleted']??0)); $rating=min(5,max(0,(float)($d['rating']??0))); $notes=trim((string)($d['notes']??'')); $active=isset($d['active'])?(int)(bool)$d['active']:1;
    if($a==='chauffeur_add'){
      $chk=$conn->prepare("SELECT id FROM chauffeurs WHERE driver_code=? LIMIT 1"); $chk->bind_param('s',$code); $chk->execute(); if($chk->get_result()->num_rows){$chk->close();out(['success'=>false,'message'=>'Driver code already exists.'],409);} $chk->close();
      $q=$conn->prepare("INSERT INTO chauffeurs(driver_code,name,phone,email,nic,license_no,license_expiry,address,emergency_contact,status,shift_start,shift_end,work_days,next_shift,assigned_vehicle_id,assigned_vehicle_name,daily_rate,trips_completed,rating,notes,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
      $q->bind_param('ssssssssssssssssdidsi',$code,$name,$phone,$email,$nic,$license,$expiry,$address,$emergency,$status,$shiftStart,$shiftEnd,$workDays,$nextShift,$assignedId,$assignedName,$rate,$trips,$rating,$notes,$active); $q->execute(); $newId=$q->insert_id; $q->close(); out(['success'=>true,'db_id'=>$newId,'driver_code'=>$code]);
    }
    $id=(int)($d['db_id']??0); if(!$id){$lookup=$conn->prepare("SELECT id FROM chauffeurs WHERE driver_code=? LIMIT 1");$lookup->bind_param('s',$code);$lookup->execute();$id=(int)($lookup->get_result()->fetch_assoc()['id']??0);$lookup->close();}
    if(!$id) out(['success'=>false,'message'=>'Chauffeur not found.'],404);
    $q=$conn->prepare("UPDATE chauffeurs SET driver_code=?,name=?,phone=?,email=?,nic=?,license_no=?,license_expiry=?,address=?,emergency_contact=?,status=?,shift_start=?,shift_end=?,work_days=?,next_shift=?,assigned_vehicle_id=?,assigned_vehicle_name=?,daily_rate=?,trips_completed=?,rating=?,notes=?,active=? WHERE id=?");
    $q->bind_param('ssssssssssssssssdidsii',$code,$name,$phone,$email,$nic,$license,$expiry,$address,$emergency,$status,$shiftStart,$shiftEnd,$workDays,$nextShift,$assignedId,$assignedName,$rate,$trips,$rating,$notes,$active,$id); $q->execute(); $q->close(); out(['success'=>true,'db_id'=>$id,'driver_code'=>$code]);
  }
  if($a==='chauffeur_status'){
    $d=body(); $id=(int)($d['db_id']??0); $code=trim((string)($d['driver_code']??$d['id']??'')); $status=trim((string)($d['status']??'Available')); $allowed=['Available','On Shift','On Leave','Off Duty','Suspended'];
    if(!in_array($status,$allowed,true)) out(['success'=>false,'message'=>'Invalid chauffeur status.'],400);
    if(!$id&&$code!==''){ $q=$conn->prepare("SELECT id FROM chauffeurs WHERE driver_code=? LIMIT 1");$q->bind_param('s',$code);$q->execute();$id=(int)($q->get_result()->fetch_assoc()['id']??0);$q->close(); }
    if(!$id) out(['success'=>false,'message'=>'Chauffeur not found.'],404); $q=$conn->prepare("UPDATE chauffeurs SET status=? WHERE id=?");$q->bind_param('si',$status,$id);$q->execute();$q->close();out(['success'=>true]);
  }
  if($a==='chauffeur_delete'||$a==='chauffeur_restore'){
    $d=body(); $id=(int)($d['db_id']??0); $code=trim((string)($d['driver_code']??$d['id']??''));
    if(!$id&&$code!==''){ $q=$conn->prepare("SELECT id FROM chauffeurs WHERE driver_code=? LIMIT 1");$q->bind_param('s',$code);$q->execute();$id=(int)($q->get_result()->fetch_assoc()['id']??0);$q->close(); }
    if(!$id) out(['success'=>false,'message'=>'Chauffeur not found.'],404);
    if($a==='chauffeur_delete') $q=$conn->prepare("UPDATE chauffeurs SET active=0,status='Off Duty',assigned_vehicle_id=NULL,assigned_vehicle_name=NULL WHERE id=?");
    else $q=$conn->prepare("UPDATE chauffeurs SET active=1,status='Available' WHERE id=?");
    $q->bind_param('i',$id);$q->execute();$q->close();out(['success'=>true]);
  }
  if($a==='invoice_add'){
    $d=body();
    $cust=trim($d['customer_name']??'');
    if(!$cust) out(['success'=>false,'message'=>'Customer name is required'],400);
    $invNo=trim($d['invoice_no']??'');
    if(!$invNo) $invNo='INV-'.rand(2409, 2999);
    $email=trim($d['customer_email']??'');
    $desc=trim($d['description']??'Vehicle Rental');
    $date=trim($d['invoice_date']??date('Y-m-d'));
    $amt=(float)($d['amount']??0);
    $status=in_array($d['status']??'',['Paid','Pending','Refunded'])?$d['status']:'Paid';
    $method=trim($d['payment_method']??'Credit Card');
    $s=$conn->prepare("INSERT INTO invoices(invoice_no,customer_name,customer_email,description,invoice_date,amount,status,payment_method) VALUES(?,?,?,?,?,?,?,?)");
    $s->bind_param('sssssdss',$invNo,$cust,$email,$desc,$date,$amt,$status,$method);
    $s->execute();$s->close();
    out(['success'=>true,'invoice_no'=>$invNo]);
  }
  if($a==='invoice_status'){
    $d=body();
    $id=trim((string)($d['invoice_no']??$d['id']??''));
    $st=trim((string)($d['status']??'Paid'));
    if(!in_array($st,['Paid','Pending','Refunded'])) out(['success'=>false,'message'=>'Invalid status'],400);

    // 1. Update invoices table if present
    $s=$conn->prepare("UPDATE invoices SET status=? WHERE invoice_no=? OR id=?");
    $s->bind_param('sss',$st,$id,$id);$s->execute();$s->close();

    // 2. Also update bookings table if this invoice corresponds to a booking
    $bStatus = ($st === 'Paid') ? 'Confirmed' : (($st === 'Pending') ? 'Pending' : 'Cancelled');
    $bPayMethod = ($st === 'Paid') ? 'Cash on Pickup' : (($st === 'Pending') ? 'Unpaid' : 'Refunded');
    $suffix = substr($id, -4);
    $likePattern = "%".$suffix;
    $s2=$conn->prepare("UPDATE bookings SET status=?, payment_method=? WHERE booking_ref LIKE ? OR booking_ref=?");
    $s2->bind_param('ssss', $bStatus, $bPayMethod, $likePattern, $id);
    $s2->execute();$s2->close();

    out(['success'=>true]);
  }
  if($a==='invoice_delete'){
    $d=body();
    $id=trim((string)($d['invoice_no']??$d['id']??''));
    // 1. Delete from invoices table
    $s=$conn->prepare("DELETE FROM invoices WHERE invoice_no=? OR id=?");
    $s->bind_param('ss',$id,$id);$s->execute();$s->close();

    // 2. Also delete from bookings table if it is a customer booking
    $suffix = substr($id, -4);
    $likePattern = "%".$suffix;
    $s2=$conn->prepare("DELETE FROM bookings WHERE booking_ref LIKE ? OR booking_ref=?");
    $s2->bind_param('ss',$likePattern,$id);$s2->execute();$s2->close();

    out(['success'=>true]);
  }
  if($a==='vehicle_add'||$a==='vehicle_update'){
    $d=body();$name=trim($d['name']??'');if(!$name)out(['success'=>false,'message'=>'Vehicle name is required'],400);
    $code=trim($d['vehicle_code']??$d['id']??'V'.date('ymdHis'));$code=preg_replace('/[^A-Za-z0-9_-]/','',$code);
    $brand=$d['brand']??'';$cat=$d['category']??'Medium';$plate=$d['plate']??'';$loc=$d['location']??'Matara';$year=(int)($d['year']??date('Y'));$seats=(int)($d['seats']??4);$doors=(int)($d['doors']??4);$trans=$d['transmission']??'Automatic';$fuel=$d['fuel']??'Petrol';$ac=!empty($d['ac'])?1:0;$bags=(int)($d['bags']??2);$price=(float)($d['price_usd']??$d['rate']??0);$service=$d['service_type']??$d['serviceType']??'Both';$image=$d['image']??'';$status=$d['status']??'Available';$active=isset($d['active'])?(int)(bool)$d['active']:1;
    if($a==='vehicle_add'){ $s=$conn->prepare("INSERT INTO vehicles(vehicle_code,name,brand,category,plate,year,location,seats,doors,transmission,fuel,ac,bags,price_usd,service_type,image,status,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");$s->bind_param('sssssiisiissidsssi',$code,$name,$brand,$cat,$plate,$year,$loc,$seats,$doors,$trans,$fuel,$ac,$bags,$price,$service,$image,$status,$active);$s->execute();$s->close();}
    else { $id=(int)($d['db_id']??0); if(!$id){$s=$conn->prepare("SELECT id FROM vehicles WHERE vehicle_code=?");$s->bind_param('s',$code);$s->execute();$id=(int)($s->get_result()->fetch_assoc()['id']??0);$s->close();} if(!$id)out(['success'=>false,'message'=>'Vehicle not found'],404);$s=$conn->prepare("UPDATE vehicles SET vehicle_code=?,name=?,brand=?,category=?,plate=?,year=?,location=?,seats=?,doors=?,transmission=?,fuel=?,ac=?,bags=?,price_usd=?,service_type=?,image=?,status=?,active=? WHERE id=?");$s->bind_param('sssssiisiissidsssii',$code,$name,$brand,$cat,$plate,$year,$loc,$seats,$doors,$trans,$fuel,$ac,$bags,$price,$service,$image,$status,$active,$id);$s->execute();$s->close();}
    out(['success'=>true]);
  }
  if($a==='vehicle_delete'){ $d=body();$id=(int)($d['db_id']??0);if(!$id){$code=$d['id']??'';$s=$conn->prepare("SELECT id FROM vehicles WHERE vehicle_code=?");$s->bind_param('s',$code);$s->execute();$id=(int)($s->get_result()->fetch_assoc()['id']??0);$s->close();}if($id){$s=$conn->prepare("DELETE FROM vehicles WHERE id=?");$s->bind_param('i',$id);$s->execute();$s->close();}out(['success'=>true]);}
  if($a==='vehicle_return'){
    $d=body();
    $ref=trim((string)($d['booking_ref']??''));
    $damage=trim((string)($d['damage_notes']??''));
    $condition=trim((string)($d['condition_status']??'Good'));
    $fuel=trim((string)($d['fuel_level']??''));
    $odo=($d['odometer_km']??'')!==''?(int)$d['odometer_km']:null;
    $extra=max(0,(float)($d['extra_charges']??0));
    $pay=strtoupper(trim((string)($d['payment_status']??'UNPAID')));
    $payNotes=trim((string)($d['payment_notes']??''));
    if(!$ref) out(['success'=>false,'message'=>'Booking reference is required.'],400);
    if(!in_array($condition,['Good','Minor Damage','Major Damage','Needs Cleaning'],true)) out(['success'=>false,'message'=>'Invalid vehicle condition.'],400);
    if(!in_array($pay,['PAID','UNPAID','PARTIAL'],true)) out(['success'=>false,'message'=>'Invalid payment status.'],400);
    $q=$conn->prepare("SELECT vehicle_id FROM bookings WHERE booking_ref=? LIMIT 1");$q->bind_param('s',$ref);$q->execute();$booking=$q->get_result()->fetch_assoc();$q->close();
    if(!$booking) out(['success'=>false,'message'=>'Booking was not found.'],404);
    $adminId=(int)($_SESSION['admin_id']??0);
    $sql="INSERT INTO vehicle_returns(booking_ref,damage_notes,condition_status,fuel_level,odometer_km,extra_charges,payment_status,payment_notes,returned_at,admin_id) VALUES(?,?,?,?,?,?,?,?,NOW(),?) ON DUPLICATE KEY UPDATE damage_notes=VALUES(damage_notes),condition_status=VALUES(condition_status),fuel_level=VALUES(fuel_level),odometer_km=VALUES(odometer_km),extra_charges=VALUES(extra_charges),payment_status=VALUES(payment_status),payment_notes=VALUES(payment_notes),returned_at=NOW(),admin_id=VALUES(admin_id)";
    // Bind booking details, odometer, extra charges, payment and admin ID.
    $st=$conn->prepare($sql);$types='ssssidssi';$st->bind_param($types,$ref,$damage,$condition,$fuel,$odo,$extra,$pay,$payNotes,$adminId);$st->execute();$st->close();
    $completed='Completed';$u=$conn->prepare("UPDATE bookings SET status=? WHERE booking_ref=?");$u->bind_param('ss',$completed,$ref);$u->execute();$u->close();
    $vehicleId=(string)$booking['vehicle_id'];
    $active=$conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE vehicle_id=? AND status NOT IN ('Cancelled','Completed') AND (dropoff_date IS NULL OR dropoff_date>=CURDATE())");$active->bind_param('s',$vehicleId);$active->execute();$activeCount=(int)($active->get_result()->fetch_assoc()['c']??0);$active->close();
    if($activeCount===0){$vs=$conn->prepare("UPDATE vehicles SET status='Available' WHERE vehicle_code=? OR CAST(id AS CHAR)=?");$vs->bind_param('ss',$vehicleId,$vehicleId);$vs->execute();$vs->close();}
    out(['success'=>true,'message'=>'Vehicle return saved. Booking marked completed.']);
  }
  if($a==='booking_status'){ $d=body();$status=$d['status']??'Pending';$id=$d['id']??'';$s=$conn->prepare("UPDATE bookings SET status=? WHERE booking_ref=?");$s->bind_param('ss',$status,$id);$s->execute();$s->close();out(['success'=>true]);}
  if($a==='booking_delete'){ $d=body();$id=trim((string)($d['id']??$d['booking_ref']??'')); if(!$id) out(['success'=>false,'message'=>'Booking ID is required'],400); $s=$conn->prepare("DELETE FROM bookings WHERE booking_ref=?"); $s->bind_param('s',$id); $s->execute(); $deleted=$s->affected_rows; $s->close(); out(['success'=>true,'deleted'=>$deleted>0]);}
  out(['success'=>false,'message'=>'Unknown action'],404);
}catch(Throwable $e){out(['success'=>false,'message'=>$e->getMessage()],500);}
?>