<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
function fail($message, $status=400) { http_response_code($status); echo json_encode(['success'=>false,'message'=>$message]); exit; }
if (empty($_SESSION['admin_id'])) fail('Please sign in again.', 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Invalid request method.', 405);
if (empty($_FILES['avatar']) || !is_uploaded_file($_FILES['avatar']['tmp_name'])) fail('Choose a photo to upload.');
$file=$_FILES['avatar'];
if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) fail('Upload failed. Please try again.');
if (($file['size'] ?? 0) > 2*1024*1024) fail('Image must be 2 MB or smaller.');
$finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']);
$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
if (!isset($allowed[$mime])) fail('Only JPG, PNG, and WEBP images are allowed.');
if (@getimagesize($file['tmp_name']) === false) fail('The uploaded file is not a valid image.');
require_once __DIR__.'/db.php';
$dir=__DIR__.'/uploads/admin-avatars';
if (!is_dir($dir) && !mkdir($dir,0755,true)) fail('Could not create upload folder.',500);
$filename='admin_'.(int)$_SESSION['admin_id'].'_'.bin2hex(random_bytes(8)).'.'.$allowed[$mime];
$target=$dir.'/'.$filename;
if (!move_uploaded_file($file['tmp_name'],$target)) fail('Could not save the photo. Check folder permissions.',500);
$relative='uploads/admin-avatars/'.$filename;
try {
 $stmt=$conn->prepare('UPDATE admin_users SET avatar_path=? WHERE id=?');
 $id=(int)$_SESSION['admin_id']; $stmt->bind_param('si',$relative,$id); $stmt->execute(); $stmt->close();
 $_SESSION['admin_avatar']=$relative;
 echo json_encode(['success'=>true,'path'=>$relative]);
} catch (Throwable $e) { @unlink($target); fail('Could not save profile photo to the database.',500); }
