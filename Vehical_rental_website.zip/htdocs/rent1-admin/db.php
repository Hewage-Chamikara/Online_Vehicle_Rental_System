<?php
require_once __DIR__.'/config.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn=new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$conn->set_charset('utf8mb4');

// Customer identity fields used by the admin Customers module.
try {
  $chkCustomerTable = $conn->query("SHOW TABLES LIKE 'customers'");
  if ($chkCustomerTable && $chkCustomerTable->num_rows > 0) {
    $chkLicense = $conn->query("SHOW COLUMNS FROM customers LIKE 'license_no'");
    if ($chkLicense && $chkLicense->num_rows === 0) {
      $conn->query("ALTER TABLE customers ADD COLUMN license_no VARCHAR(60) NULL AFTER nic");
    }
  }
} catch (Throwable $e) {}
$conn->query("CREATE TABLE IF NOT EXISTS vehicles (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 vehicle_code VARCHAR(100) NOT NULL UNIQUE,
 name VARCHAR(150) NOT NULL,
 brand VARCHAR(100) NULL,
 location VARCHAR(100) NOT NULL DEFAULT 'Matara',
 category VARCHAR(100) NOT NULL DEFAULT 'Medium',
 plate VARCHAR(50) NULL,
 year INT NULL,
 seats INT NOT NULL DEFAULT 4,
 doors INT NOT NULL DEFAULT 4,
 transmission VARCHAR(50) DEFAULT 'Automatic',
 fuel VARCHAR(80) DEFAULT 'Petrol',
 ac TINYINT(1) DEFAULT 1,
 bags INT DEFAULT 2,
 price_usd DECIMAL(10,2) NOT NULL DEFAULT 0,
 service_type VARCHAR(50) DEFAULT 'Both',
 image TEXT NULL,
 status VARCHAR(30) DEFAULT 'Available',
 active TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Migrate an existing vehicles table created by the customer site.
// CREATE TABLE IF NOT EXISTS does not alter an existing table, so add any
// columns required by the standalone admin portal when they are missing.
$vehicleColumns = [
 'vehicle_code' => "ALTER TABLE vehicles ADD COLUMN vehicle_code VARCHAR(100) NULL",
 'name' => "ALTER TABLE vehicles ADD COLUMN name VARCHAR(150) NULL",
 'brand' => "ALTER TABLE vehicles ADD COLUMN brand VARCHAR(100) NULL",
 'location' => "ALTER TABLE vehicles ADD COLUMN location VARCHAR(100) NOT NULL DEFAULT 'Matara'",
 'category' => "ALTER TABLE vehicles ADD COLUMN category VARCHAR(100) NOT NULL DEFAULT 'Medium'",
 'plate' => "ALTER TABLE vehicles ADD COLUMN plate VARCHAR(50) NULL",
 'year' => "ALTER TABLE vehicles ADD COLUMN year INT NULL",
 'seats' => "ALTER TABLE vehicles ADD COLUMN seats INT NOT NULL DEFAULT 4",
 'doors' => "ALTER TABLE vehicles ADD COLUMN doors INT NOT NULL DEFAULT 4",
 'transmission' => "ALTER TABLE vehicles ADD COLUMN transmission VARCHAR(50) DEFAULT 'Automatic'",
 'fuel' => "ALTER TABLE vehicles ADD COLUMN fuel VARCHAR(80) DEFAULT 'Petrol'",
 'ac' => "ALTER TABLE vehicles ADD COLUMN ac TINYINT(1) DEFAULT 1",
 'bags' => "ALTER TABLE vehicles ADD COLUMN bags INT DEFAULT 2",
 'price_usd' => "ALTER TABLE vehicles ADD COLUMN price_usd DECIMAL(10,2) NOT NULL DEFAULT 0",
 'service_type' => "ALTER TABLE vehicles ADD COLUMN service_type VARCHAR(50) DEFAULT 'Both'",
 'image' => "ALTER TABLE vehicles ADD COLUMN image TEXT NULL",
 'status' => "ALTER TABLE vehicles ADD COLUMN status VARCHAR(30) DEFAULT 'Available'",
 'active' => "ALTER TABLE vehicles ADD COLUMN active TINYINT(1) DEFAULT 1",
 'last_service_date' => "ALTER TABLE vehicles ADD COLUMN last_service_date DATE NULL",
 'created_at' => "ALTER TABLE vehicles ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
 'updated_at' => "ALTER TABLE vehicles ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
];
foreach ($vehicleColumns as $column => $sql) {
    $check = $conn->query("SHOW COLUMNS FROM vehicles LIKE '" . $conn->real_escape_string($column) . "'");
    if ($check->num_rows === 0) {
        try { $conn->query($sql); } catch (Throwable $e) { /* continue; later code will report real DB errors */ }
    }
}
// Fill required identifiers for old rows before enforcing uniqueness.
$conn->query("UPDATE vehicles SET vehicle_code=CONCAT('LEGACY-',id) WHERE vehicle_code IS NULL OR vehicle_code=''");
$conn->query("UPDATE vehicles SET name=COALESCE(NULLIF(name,''),'Vehicle') WHERE name IS NULL OR name=''");
// Add a unique index only if one does not already exist.
$idx=$conn->query("SHOW INDEX FROM vehicles WHERE Key_name='uq_vehicle_code'");
if ($idx->num_rows===0) { try { $conn->query("ALTER TABLE vehicles ADD UNIQUE KEY uq_vehicle_code (vehicle_code)"); } catch(Throwable $e) {} }

$conn->query("CREATE TABLE IF NOT EXISTS admin_users(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(100) UNIQUE NOT NULL,
 email VARCHAR(190) NULL,
 full_name VARCHAR(150) NULL,
 role VARCHAR(100) DEFAULT 'Fleet Manager',
 avatar_path VARCHAR(255) NULL,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Add missing columns if admin_users already existed
$adminCols = [
  'email' => "ALTER TABLE admin_users ADD COLUMN email VARCHAR(190) NULL",
  'full_name' => "ALTER TABLE admin_users ADD COLUMN full_name VARCHAR(150) NULL",
  'role' => "ALTER TABLE admin_users ADD COLUMN role VARCHAR(100) DEFAULT 'Fleet Manager'",
  'avatar_path' => "ALTER TABLE admin_users ADD COLUMN avatar_path VARCHAR(255) NULL"
];
foreach ($adminCols as $col => $sql) {
  $chk = $conn->query("SHOW COLUMNS FROM admin_users LIKE '" . $conn->real_escape_string($col) . "'");
  if ($chk && $chk->num_rows === 0) {
    try { $conn->query($sql); } catch (Throwable $e) {}
  }
}

if(($r=$conn->query("SELECT id FROM admin_users LIMIT 1"))->num_rows===0){
 $h=password_hash('admin123',PASSWORD_DEFAULT);
 $s=$conn->prepare("INSERT INTO admin_users(username,email,full_name,role,password_hash) VALUES('admin','manager@veloce.rent','Dominic Reyes','Fleet Manager',?)");
 $s->bind_param('s',$h);$s->execute();$s->close();
} else {
  // Update admin record to have Dominic Reyes and manager@veloce.rent if empty
  $conn->query("UPDATE admin_users SET email=COALESCE(NULLIF(email,''),'manager@veloce.rent'), full_name=COALESCE(NULLIF(full_name,''),'Dominic Reyes'), role=COALESCE(NULLIF(role,''),'Fleet Manager') WHERE username='admin'");
}

// Invoices & Payments table for the Payments tab
$conn->query("CREATE TABLE IF NOT EXISTS invoices(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 invoice_no VARCHAR(50) NOT NULL UNIQUE,
 customer_name VARCHAR(150) NOT NULL,
 customer_email VARCHAR(190) NULL,
 description VARCHAR(255) NOT NULL,
 invoice_date DATE NOT NULL,
 amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
 status ENUM('Paid','Pending','Refunded') NOT NULL DEFAULT 'Paid',
 payment_method VARCHAR(50) DEFAULT 'Credit Card',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Vehicle return inspections: records condition, damage, payment and extra charges.
$conn->query("CREATE TABLE IF NOT EXISTS vehicle_returns (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 booking_ref VARCHAR(50) NOT NULL UNIQUE,
 damage_notes TEXT NULL,
 condition_status VARCHAR(40) NOT NULL DEFAULT 'Good',
 fuel_level VARCHAR(30) NULL,
 odometer_km INT NULL,
 extra_charges DECIMAL(10,2) NOT NULL DEFAULT 0.00,
 payment_status VARCHAR(30) NOT NULL DEFAULT 'UNPAID',
 payment_notes TEXT NULL,
 returned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 admin_id INT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_vehicle_returns_date (returned_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Maintenance & Service Tickets table
$conn->query("CREATE TABLE IF NOT EXISTS maintenance (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ticket_id VARCHAR(50) NOT NULL UNIQUE,
 vehicle_id VARCHAR(50) NOT NULL,
 vehicle_name VARCHAR(150) NOT NULL,
 issue_description TEXT NOT NULL,
 service_center VARCHAR(150) NOT NULL,
 estimated_cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
 start_date DATE NOT NULL,
 estimated_return VARCHAR(50) DEFAULT 'In 3 Days',
 status VARCHAR(50) DEFAULT 'In Progress',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");


// Chauffeur / Driver Roster
$conn->query("CREATE TABLE IF NOT EXISTS chauffeurs (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 driver_code VARCHAR(30) NOT NULL UNIQUE,
 name VARCHAR(150) NOT NULL,
 phone VARCHAR(40) NULL,
 email VARCHAR(190) NULL,
 nic VARCHAR(40) NULL,
 license_no VARCHAR(60) NULL,
 license_expiry DATE NULL,
 address VARCHAR(255) NULL,
 emergency_contact VARCHAR(150) NULL,
 status VARCHAR(40) NOT NULL DEFAULT 'Available',
 shift_start TIME NULL,
 shift_end TIME NULL,
 work_days VARCHAR(120) NULL DEFAULT 'Mon,Tue,Wed,Thu,Fri,Sat',
 next_shift DATE NULL,
 assigned_vehicle_id VARCHAR(100) NULL,
 assigned_vehicle_name VARCHAR(150) NULL,
 daily_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
 trips_completed INT NOT NULL DEFAULT 0,
 rating DECIMAL(3,2) NOT NULL DEFAULT 0.00,
 notes TEXT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_chauffeur_status(status),
 INDEX idx_chauffeur_active(active),
 INDEX idx_chauffeur_vehicle(assigned_vehicle_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Seed the shared vehicle catalog once if it is empty.
// These are the same vehicles used by the customer website.
if ((int)$conn->query("SELECT COUNT(*) c FROM vehicles")->fetch_assoc()['c']===0) {
 $seed=[
 ['V001','Suzuki Alto','Suzuki','Small','',2024,106.21,'Petrol or diesel','Automatic',4,4,'Matara','Vehicle Only','images/Suzuki_Alto.jpg'],
 ['V002','Perodua Axia','Perodua','Small','',2024,110,'Petrol or diesel','Automatic',4,4,'Matara','Vehicle Only','images/Perodua_Axia.webp'],
 ['V003','Suzuki Wagon R','Suzuki','Medium','',2024,115.50,'Hybrid','Automatic',4,4,'Matara','Both','images/Suzuki_Wagon_R.jpg'],
 ['V004','Toyota C-HR','Toyota','SUVs','',2024,150,'Hybrid','Automatic',5,4,'Matara','Both','images/Toyota_C-HR_(CHR).jpg'],
 ['V005','BMW 3 Series','BMW','Premium','',2024,350,'Petrol or diesel','Automatic',5,4,'Matara','With Driver','https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=600&q=80'],
 ['V006','Toyota Prius','Toyota','Medium','',2024,145,'Hybrid','Automatic',5,4,'Galle','Both','images/Toyota_Prius.webp'],
 ['V007','Toyota Vitz','Toyota','Small','',2024,128.78,'Petrol or diesel','Automatic',5,4,'Galle','Vehicle Only','images/Toyota_Vitz.jpg'],
 ['V008','Audi A4','Audi','Large','',2024,195,'Petrol or diesel','Automatic',5,4,'Galle','With Driver','https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=600&q=80'],
 ['V009','Toyota Aqua','Toyota','Estate','',2024,135,'Hybrid','Automatic',5,4,'Galle','Both','images/Toyota_Aqua.jpg'],
 ['V010','Nissan GT-R','Nissan','Premium','',2024,420,'Petrol or diesel','Automatic',4,2,'Hambantota','With Driver','images/Nissan_GT-R.jpg'],
 ['V011','Nissan March','Nissan','Small','',2024,130.48,'Petrol or diesel','Manual',4,4,'Hambantota','Vehicle Only','images/Nissan_March.webp'],
 ['V012','Honda Civic','Honda','Large','',2024,180,'Petrol or diesel','Automatic',5,4,'Hambantota','Both','images/Honda_Civic.jpg'],
 ['V013','Toyota KDH Van','Toyota','People carriers','',2024,220,'Petrol or diesel','Manual',10,4,'Hambantota','With Driver','images/Toyota_KDH_Van.jpg']
 ];
 $s=$conn->prepare("INSERT INTO vehicles(vehicle_code,name,brand,category,plate,year,price_usd,fuel,transmission,seats,doors,location,service_type,image,status,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Available',1)");
 foreach($seed as $x){$s->bind_param('sssssidssiisss',$x[0],$x[1],$x[2],$x[3],$x[4],$x[5],$x[6],$x[7],$x[8],$x[9],$x[10],$x[11],$x[12],$x[13]);$s->execute();}
 $s->close();
}

// Live GPS positions for customer-picked/rented vehicles.
// One latest row per booking is kept so the admin map always shows the newest position.
$conn->query("CREATE TABLE IF NOT EXISTS vehicle_gps_locations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_ref VARCHAR(50) NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  vehicle_id VARCHAR(100) NOT NULL,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL,
  accuracy DECIMAL(10,2) NULL,
  speed DECIMAL(10,2) NULL,
  heading DECIMAL(10,2) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_gps_booking (booking_ref),
  INDEX idx_gps_vehicle (vehicle_id),
  INDEX idx_gps_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

?>