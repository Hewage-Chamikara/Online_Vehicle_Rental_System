<?php
session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}
require_once __DIR__ . '/db.php';

// Fetch live payments list from MySQL: customer bookings + invoices table
$paymentsList = [];
$seenInvNos = [];
$collected = 0.0;
$pending = 0.0;
$refunded = 0.0;

// 1. Customer bookings from database (Customer booked vehicles)
$bRes = $conn->query("SELECT id, booking_ref, customer_name, customer_email, customer_phone, vehicle_id, vehicle_name, pickup_date, dropoff_date, rental_days, price_usd, status, payment_method, created_at FROM bookings ORDER BY id DESC");
if ($bRes) {
    while ($bk = $bRes->fetch_assoc()) {
        $ref = trim((string)($bk['booking_ref'] ?: $bk['id']));
        $invNo = 'INV-' . strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $ref), -4));
        if (isset($seenInvNos[$invNo])) continue;
        $seenInvNos[$invNo] = true;

        $amt = (float)($bk['price_usd'] ?: 0);
        $stRaw = strtolower(trim((string)($bk['status'] ?: '')));
        $status = ($stRaw === 'cancelled' || $stRaw === 'canceled') ? 'Refunded' : (($stRaw === 'completed' || (!empty($bk['payment_method']) && strtolower($bk['payment_method']) !== 'unpaid')) ? 'Paid' : 'Pending');

        if ($status === 'Paid') $collected += $amt;
        elseif ($status === 'Pending') $pending += $amt;
        elseif ($status === 'Refunded') $refunded += $amt;

        $ts = strtotime($bk['pickup_date'] ?: $bk['created_at'] ?: 'now');
        $formattedDate = $ts ? date('M j', $ts) : date('M j');
        $vName = $bk['vehicle_name'] ?: 'Vehicle';
        $days = (int)($bk['rental_days'] ?: 1);
        $desc = "{$vName} · {$days} " . ($days === 1 ? 'day' : 'days');

        $paymentsList[] = [
            'id' => 'bk_' . $bk['id'],
            'invoice_no' => $invNo,
            'customer_name' => $bk['customer_name'] ?: 'Customer',
            'customer_email' => $bk['customer_email'] ?: '',
            'description' => $desc,
            'invoice_date' => substr($bk['pickup_date'] ?: date('Y-m-d'), 0, 10),
            'amount' => $amt,
            'status' => $status,
            'payment_method' => $bk['payment_method'] ?: 'Cash on Pickup',
            'formattedDate' => $formattedDate,
            'amountFormatted' => '$' . number_format($amt, 0),
            'is_booking' => true,
            'booking_ref' => $ref
        ];
    }
}

// 2. Recorded invoices from the invoices table (Image 2 rows)
$invRes = $conn->query("SELECT id, invoice_no, customer_name, customer_email, description, invoice_date, amount, status, payment_method, created_at FROM invoices ORDER BY id DESC");
if ($invRes) {
    while ($inv = $invRes->fetch_assoc()) {
        if (isset($seenInvNos[$inv['invoice_no']])) continue;
        $seenInvNos[$inv['invoice_no']] = true;
        $amt = (float)$inv['amount'];
        $st = $inv['status'];
        if ($st === 'Paid') $collected += $amt;
        elseif ($st === 'Pending') $pending += $amt;
        elseif ($st === 'Refunded') $refunded += $amt;

        $ts = strtotime($inv['invoice_date']);
        $inv['formattedDate'] = $ts ? date('M j', $ts) : $inv['invoice_date'];
        $inv['amountFormatted'] = '$' . number_format($amt, 0);
        $inv['is_booking'] = false;
        $paymentsList[] = $inv;
    }
}

$summary = [
    'collectedFormatted' => '$' . number_format($collected, 0),
    'pendingFormatted' => '$' . number_format($pending, 0),
    'refundedFormatted' => '$' . number_format($refunded, 0),
    'countAll' => count($paymentsList),
    'countPaid' => count(array_filter($paymentsList, fn($x) => $x['status'] === 'Paid')),
    'countPending' => count(array_filter($paymentsList, fn($x) => $x['status'] === 'Pending')),
    'countRefunded' => count(array_filter($paymentsList, fn($x) => $x['status'] === 'Refunded')),
];

$currentDateFormatted = date('D, M j');
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chamikara Rent A Car Admin • Chamikara Rent A Car - Vehicle Rental Administration Portal</title>
  
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- FontAwesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <!-- Chart.js CDN -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- Main Stylesheet with cache buster -->
  <link rel="stylesheet" href="css/style.css?v=<?= time() ?>">
  <link rel="stylesheet" href="liquid-buttons.css">
  <link rel="stylesheet" href="liquid-fullsite.css">

  <!-- Dedicated Payments & Invoices CSS (Matches Image 2 exactly & overrides liquid buttons) -->
  <style id="payments-custom-css">
    /* Header Bar */
    .payments-header-bar {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      gap: 16px !important;
      margin-bottom: 24px !important;
      flex-wrap: wrap !important;
    }
    .payments-title-wrap {
      display: flex !important;
      align-items: center !important;
      gap: 14px !important;
    }
    .payments-title {
      font-family: 'Outfit', sans-serif !important;
      font-size: 26px !important;
      font-weight: 800 !important;
      color: #ffffff !important;
      margin: 0 !important;
      letter-spacing: -0.3px !important;
    }
    .payments-date-badge {
      display: inline-flex !important;
      align-items: center !important;
      gap: 8px !important;
      padding: 6px 14px !important;
      border-radius: 10px !important;
      background: rgba(255, 255, 255, 0.05) !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      color: #94a3b8 !important;
      font-size: 13px !important;
      font-weight: 500 !important;
    }
    .payments-top-search {
      flex: 1 !important;
      max-width: 440px !important;
      position: relative !important;
      display: flex !important;
      align-items: center !important;
    }
    .payments-top-search i {
      position: absolute !important;
      left: 14px !important;
      color: #64748b !important;
      font-size: 14px !important;
      pointer-events: none !important;
    }
    .payments-top-search input {
      width: 100% !important;
      padding: 10px 42px 10px 38px !important;
      border-radius: 12px !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      background: rgba(255, 255, 255, 0.04) !important;
      color: #ffffff !important;
      font-size: 13.5px !important;
      outline: none !important;
      box-shadow: none !important;
    }
    .payments-top-search input:focus {
      border-color: #ff5722 !important;
      background: rgba(255, 255, 255, 0.07) !important;
      box-shadow: 0 0 0 3px rgba(255, 87, 34, 0.18) !important;
    }
    .search-kbd-hint {
      position: absolute !important;
      right: 12px !important;
      padding: 2px 7px !important;
      border-radius: 6px !important;
      background: rgba(255, 255, 255, 0.08) !important;
      color: #94a3b8 !important;
      font-size: 11px !important;
      font-weight: 600 !important;
    }

    /* Stat Cards Row (Image 2) */
    .payments-stats-grid {
      display: grid !important;
      grid-template-columns: repeat(3, 1fr) !important;
      gap: 20px !important;
      margin-bottom: 24px !important;
    }
    @media (max-width: 900px) {
      .payments-stats-grid { grid-template-columns: 1fr !important; }
    }
    .pay-stat-card {
      background: #141824 !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      border-radius: 16px !important;
      padding: 22px 24px !important;
      display: flex !important;
      align-items: center !important;
      gap: 18px !important;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25) !important;
      transition: transform 0.2s ease, box-shadow 0.2s ease !important;
    }
    .pay-stat-card:hover {
      transform: translateY(-2px) !important;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.35) !important;
    }
    .pay-stat-icon-box {
      width: 52px !important;
      height: 52px !important;
      border-radius: 14px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      font-size: 22px !important;
      flex-shrink: 0 !important;
    }
    .pay-stat-icon-box.green {
      background: #22c55e !important;
      color: #ffffff !important;
      box-shadow: 0 4px 14px rgba(34, 197, 94, 0.35) !important;
    }
    .pay-stat-icon-box.amber {
      background: #f59e0b !important;
      color: #ffffff !important;
      box-shadow: 0 4px 14px rgba(245, 158, 11, 0.35) !important;
    }
    .pay-stat-icon-box.cyan {
      background: #3b82f6 !important;
      color: #ffffff !important;
      box-shadow: 0 4px 14px rgba(59, 130, 246, 0.35) !important;
    }
    .pay-stat-amount {
      font-family: 'Outfit', sans-serif !important;
      font-size: 28px !important;
      font-weight: 800 !important;
      color: #ffffff !important;
      line-height: 1.1 !important;
      letter-spacing: -0.3px !important;
    }
    .pay-stat-label {
      font-size: 13.5px !important;
      font-weight: 500 !important;
      color: #94a3b8 !important;
      margin-top: 4px !important;
    }

    /* Filter Pills & Record Button Row (Image 2) */
    .payments-toolbar {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      gap: 16px !important;
      margin-bottom: 22px !important;
      flex-wrap: wrap !important;
    }
    .payments-filter-pills {
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
    }
    /* Strictly override any liquid button styles for filter pills */
    #view-payments button.filter-pill,
    .payments-filter-pills button.filter-pill {
      border: none !important;
      border-radius: 10px !important;
      padding: 10px 22px !important;
      font-family: 'Plus Jakarta Sans', sans-serif !important;
      font-size: 14px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      background: transparent !important;
      color: #94a3b8 !important;
      box-shadow: none !important;
      outline: none !important;
      min-height: auto !important;
    }
    #view-payments button.filter-pill:hover,
    .payments-filter-pills button.filter-pill:hover {
      color: #ffffff !important;
      background: rgba(255, 255, 255, 0.06) !important;
    }
    #view-payments button.filter-pill.active,
    .payments-filter-pills button.filter-pill.active {
      background: #ff5722 !important;
      color: #ffffff !important;
      font-weight: 700 !important;
      box-shadow: 0 4px 14px rgba(255, 87, 34, 0.4) !important;
    }
    /* Strictly override liquid button styles for Record Payment button */
    #view-payments .btn-record-payment,
    .btn-record-payment {
      display: inline-flex !important;
      align-items: center !important;
      gap: 8px !important;
      padding: 11px 24px !important;
      border-radius: 12px !important;
      border: none !important;
      background: #ff5722 !important;
      color: #ffffff !important;
      font-family: 'Outfit', sans-serif !important;
      font-size: 14px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      box-shadow: 0 4px 14px rgba(255, 87, 34, 0.4) !important;
      outline: none !important;
      min-height: auto !important;
    }
    #view-payments .btn-record-payment:hover,
    .btn-record-payment:hover {
      background: #f4511e !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 6px 20px rgba(255, 87, 34, 0.5) !important;
    }

    /* Table Card & Table (Image 2) */
    .payments-table-card {
      background: #141824 !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      border-radius: 18px !important;
      overflow-x: auto !important;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25) !important;
    }
    .payments-table {
      width: 100% !important;
      border-collapse: collapse !important;
      text-align: left !important;
    }
    .payments-table th {
      padding: 18px 24px !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      letter-spacing: 1.2px !important;
      color: #64748b !important;
      text-transform: uppercase !important;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
      background: rgba(255, 255, 255, 0.015) !important;
    }
    .payments-table td {
      padding: 18px 24px !important;
      font-size: 14px !important;
      border-bottom: 1px solid rgba(255, 255, 255, 0.04) !important;
      vertical-align: middle !important;
    }
    .payments-table tr:hover td {
      background: rgba(255, 255, 255, 0.02) !important;
    }
    .invoice-link {
      color: #ff5722 !important;
      font-family: 'Outfit', sans-serif !important;
      font-weight: 700 !important;
      font-size: 14.5px !important;
      text-decoration: none !important;
      letter-spacing: 0.3px !important;
    }
    .invoice-link:hover {
      text-decoration: underline !important;
    }
    .cust-name-cell {
      font-weight: 600 !important;
      color: #ffffff !important;
      font-size: 14px !important;
    }
    .desc-cell {
      color: #94a3b8 !important;
      font-size: 13.5px !important;
    }
    .date-cell {
      color: #94a3b8 !important;
      font-size: 13.5px !important;
    }
    .amount-cell {
      font-family: 'Outfit', sans-serif !important;
      font-weight: 800 !important;
      font-size: 15px !important;
      color: #ffffff !important;
    }
    .status-badge {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      padding: 5px 14px !important;
      border-radius: 999px !important;
      font-size: 12px !important;
      font-weight: 700 !important;
      text-transform: capitalize !important;
    }
    .status-badge.paid {
      background: rgba(16, 185, 129, 0.16) !important;
      color: #34d399 !important;
      border: 1px solid rgba(16, 185, 129, 0.3) !important;
    }
    .status-badge.pending {
      background: rgba(245, 158, 11, 0.16) !important;
      color: #fbbf24 !important;
      border: 1px solid rgba(245, 158, 11, 0.3) !important;
    }
    .status-badge.refunded {
      background: rgba(100, 116, 139, 0.20) !important;
      color: #94a3b8 !important;
      border: 1px solid rgba(100, 116, 139, 0.3) !important;
    }
    .actions-group {
      display: inline-flex !important;
      align-items: center !important;
      gap: 8px !important;
    }
    #view-payments .icon-action-btn,
    .icon-action-btn {
      width: 32px !important;
      height: 32px !important;
      border-radius: 8px !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      background: rgba(255, 255, 255, 0.05) !important;
      color: #94a3b8 !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      cursor: pointer !important;
      font-size: 12.5px !important;
      transition: all 0.2s !important;
      box-shadow: none !important;
      padding: 0 !important;
      min-height: auto !important;
    }
    #view-payments .icon-action-btn:hover,
    .icon-action-btn:hover {
      color: #ffffff !important;
      border-color: rgba(255, 255, 255, 0.2) !important;
      background: rgba(255, 255, 255, 0.1) !important;
    }
    #view-payments .icon-action-btn.delete:hover,
    .icon-action-btn.delete:hover {
      color: #ef4444 !important;
      border-color: rgba(239, 68, 68, 0.3) !important;
      background: rgba(239, 68, 68, 0.1) !important;
    }
    .modal-overlay {
      z-index: 99999 !important;
    }
    .modal-overlay.active {
      display: flex !important;
      opacity: 1 !important;
      pointer-events: auto !important;
      visibility: visible !important;
    }
  </style>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
</head>
<body>

  <div id="app">
    <!-- Sidebar Navigation -->
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-header">
        <div class="brand">
          <div class="brand-icon"><i class="fas fa-car"></i></div>
          <span class="brand-text">Chamikara Rent A Car</span>
        </div>
        <button class="sidebar-toggle-btn" id="sidebarToggleBtn" title="Toggle Sidebar">
          <i class="fas fa-bars"></i>
        </button>
      </div>

      <nav class="sidebar-nav">
        <div class="nav-section-title">MAIN MANAGEMENT</div>
        <div class="nav-item active" data-tab="dashboard" onclick="app.switchTab('dashboard')">
          <i class="fas fa-chart-line"></i>
          <span>Dashboard</span>
        </div>

        <div class="nav-item" data-tab="fleet" onclick="app.switchTab('fleet')">
          <i class="fas fa-car-alt"></i>
          <span>Fleet Inventory</span>
          <span class="nav-badge" id="fleetBadge">12</span>
        </div>

        <div class="nav-item" data-tab="bookings" onclick="app.switchTab('bookings')">
          <i class="far fa-calendar-alt"></i>
          <span>Reservations</span>
          <span class="nav-badge" id="reservationsBadge">3</span>
        </div>

        <div class="nav-item" data-tab="carts" onclick="app.switchTab('carts')">
          <i class="fas fa-shopping-cart"></i>
          <span>Customer Carts</span>
          <span class="nav-badge" id="cartBadge">3</span>
        </div>

        <div class="nav-item" data-tab="chat" onclick="app.switchTab('chat')">
          <i class="fas fa-comments"></i>
          <span>Live Chat</span>
          <span class="nav-badge" id="chatBadge" style="background:#f59e0b;">0</span>
        </div>
        <div class="nav-item" data-tab="customers" onclick="app.switchTab('customers')">
          <i class="fas fa-users"></i>
          <span>Customers</span>
        </div>

        <div class="nav-item" data-tab="drivers" onclick="app.switchTab('drivers')">
          <i class="fas fa-user-tie"></i>
          <span>Chauffeur Roster</span>
          <span class="nav-badge" id="chauffeurBadge" style="background:#06b6d4;">0</span>
        </div>

        <div class="nav-section-title">TELEMETRY & OPERATIONS</div>
        <div class="nav-item" data-tab="gps" onclick="app.switchTab('gps')">
          <i class="fas fa-satellite-dish"></i>
          <span>Live GPS Tracker</span>
        </div>

        <div class="nav-item" data-tab="maintenance" onclick="app.switchTab('maintenance')">
          <i class="fas fa-tools"></i>
          <span>Maintenance Logs</span>
          <span class="nav-badge" id="maintenanceBadge" style="background:#f59e0b;">2</span>
        </div>

        <div class="nav-item" data-tab="financials" onclick="app.switchTab('financials')">
          <i class="fas fa-coins"></i>
          <span>Financials & Rates</span>
        </div>

        <div class="nav-item" data-tab="payments" onclick="app.switchTab('payments')">
          <i class="fas fa-credit-card"></i>
          <span>Payments</span>
          <span class="nav-badge" id="paymentsBadge" style="background:#ff5722;"><?= count($paymentsList) ?></span>
        </div>

        <div class="nav-section-title">CONFIGURATION</div>
        <div class="nav-item" data-tab="settings" onclick="app.switchTab('settings')">
          <i class="fas fa-cog"></i>
          <span>System Settings</span>
        </div>
      </nav>

      <!-- Sidebar Footer Profile (matching Image 1) -->
      <div class="sidebar-footer admin-profile-footer">
        <button type="button" class="admin-avatar-picker" id="adminAvatarPicker" title="Upload profile photo" aria-label="Upload profile photo">
          <img src="<?= htmlspecialchars($_SESSION['admin_avatar'] ?? '') ?: 'assets/default-admin-avatar.svg' ?>" alt="Admin profile photo" class="admin-avatar" id="adminAvatarPreview" onerror="this.onerror=null;this.src='assets/default-admin-avatar.svg';">
          <span class="avatar-edit-badge"><i class="fas fa-camera"></i></span>
        </button>
        <input type="file" id="adminAvatarFile" accept="image/jpeg,image/png,image/webp" hidden>
        <div class="admin-info">
          <span class="admin-name"><?= htmlspecialchars($_SESSION['admin_fullname'] ?? 'Admin') ?></span>
          <span class="admin-role"><?= htmlspecialchars($_SESSION['admin_role'] ?? 'Super Admin') ?></span>
        </div>
        <a href="logout.php" title="Sign Out" style="margin-left:auto; color:var(--text-dim); padding:6px; font-size:16px;"><i class="fas fa-sign-out-alt"></i></a>
      </div>
    </aside>

    <!-- Main Content Area -->
    <div class="main-wrapper">
      <!-- Top Navigation Bar -->
      <header class="top-header">
        <div class="header-search">
          <i class="fas fa-search"></i>
          <input type="text" id="globalSearchInput" placeholder="Global search vehicles, customers, booking ref..." oninput="app.handleGlobalSearch(this.value)">
        </div>

        <div class="header-actions">
          <button class="action-btn" id="themeToggleBtn" title="Toggle Light/Dark Theme">
            <i class="fas fa-moon"></i>
          </button>

          <button class="action-btn" onclick="app.showToast('System Notifications: All systems online', 'info')" title="Notifications">
            <i class="fas fa-bell"></i>
            <span class="notification-dot"></span>
          </button>

          <button class="primary-btn" onclick="app.switchTab('payments')">
            <i class="fas fa-credit-card"></i> Payments
          </button>
        </div>
      </header>

      <!-- Page Views Scroll Container -->
      <main class="page-container">
        <!-- View: Payments & Invoices (Image 3) -->
        <div class="page-view active" id="view-payments">
          <!-- Payments Top Header Bar (Image 3) -->
          <div class="payments-header-bar">
            <div class="payments-title-wrap">
              <button class="mobile-toggle-btn" onclick="document.getElementById('sidebar').classList.toggle('collapsed')">
                <i class="fas fa-bars"></i>
              </button>
              <h1 class="payments-title">Payments &amp; Invoices</h1>
              <div class="payments-date-badge">
                <i class="far fa-calendar"></i>
                <span><?= $currentDateFormatted ?></span>
              </div>
            </div>

            <div class="payments-top-search">
              <i class="fas fa-search"></i>
              <input type="text" id="paymentsSearchInput" placeholder="Search cars, customers, pages..." oninput="app.searchPayments(this.value)">
              <span class="search-kbd-hint">/</span>
            </div>
          </div>

          <!-- Stat Cards Row (Image 3) -->
          <div class="payments-stats-grid">
            <!-- Collected Card -->
            <div class="pay-stat-card">
              <div class="pay-stat-icon-box green">
                <i class="fas fa-money-bill-wave"></i>
              </div>
              <div class="pay-stat-body">
                <div class="pay-stat-amount" id="statCollectedAmount"><?= $summary['collectedFormatted'] ?></div>
                <div class="pay-stat-label">Collected</div>
              </div>
            </div>

            <!-- Pending Card -->
            <div class="pay-stat-card">
              <div class="pay-stat-icon-box amber">
                <i class="fas fa-hourglass-half"></i>
              </div>
              <div class="pay-stat-body">
                <div class="pay-stat-amount" id="statPendingAmount"><?= $summary['pendingFormatted'] ?></div>
                <div class="pay-stat-label">Pending</div>
              </div>
            </div>

            <!-- Refunded Card -->
            <div class="pay-stat-card">
              <div class="pay-stat-icon-box cyan">
                <i class="fas fa-sync-alt"></i>
              </div>
              <div class="pay-stat-body">
                <div class="pay-stat-amount" id="statRefundedAmount"><?= $summary['refundedFormatted'] ?></div>
                <div class="pay-stat-label">Refunded</div>
              </div>
            </div>
          </div>

          <!-- Filter Pills & Record Payment Button Row -->
          <div class="payments-toolbar">
            <div class="payments-filter-pills">
              <button type="button" class="filter-pill active" onclick="app.filterPayments('All')">All</button>
              <button type="button" class="filter-pill" onclick="app.filterPayments('Paid')">Paid</button>
              <button type="button" class="filter-pill" onclick="app.filterPayments('Pending')">Pending</button>
              <button type="button" class="filter-pill" onclick="app.filterPayments('Refunded')">Refunded</button>
            </div>

            <button type="button" class="btn-record-payment" onclick="app.openRecordPaymentModal()">
              <i class="fas fa-plus"></i> Record payment
            </button>
          </div>

          <!-- Invoices & Payments Table (Image 3) -->
          <div class="payments-table-card">
            <table class="payments-table">
              <thead>
                <tr>
                  <th>INVOICE</th>
                  <th>CUSTOMER</th>
                  <th>DESCRIPTION</th>
                  <th>DATE</th>
                  <th>AMOUNT</th>
                  <th>STATUS</th>
                  <th style="text-align: right;">ACTIONS</th>
                </tr>
              </thead>
              <tbody id="paymentsTableBody">
                <?php if (!empty($paymentsList)): ?>
                  <?php foreach ($paymentsList as $item): ?>
                    <tr class="payment-row" data-status="<?= htmlspecialchars($item['status']) ?>" data-search="<?= htmlspecialchars(strtolower($item['invoice_no'] . ' ' . $item['customer_name'] . ' ' . $item['description'])) ?>">
                      <td>
                        <a href="javascript:void(0)" class="invoice-link" data-invoice="<?= htmlspecialchars($item['invoice_no']) ?>" onclick="app.viewInvoice('<?= htmlspecialchars($item['invoice_no']) ?>')">
                          <?= htmlspecialchars($item['invoice_no']) ?>
                        </a>
                      </td>
                      <td>
                        <div class="cust-name-cell">
                          <span><?= htmlspecialchars($item['customer_name']) ?></span>
                        </div>
                      </td>
                      <td>
                        <span class="desc-cell"><?= htmlspecialchars($item['description']) ?></span>
                      </td>
                      <td>
                        <span class="date-cell"><?= htmlspecialchars($item['formattedDate'] ?: $item['invoice_date']) ?></span>
                      </td>
                      <td>
                        <span class="amount-cell"><?= htmlspecialchars($item['amountFormatted'] ?: ('$' . number_format($item['amount'], 0))) ?></span>
                      </td>
                      <td>
                        <span class="status-badge <?= strtolower($item['status']) ?>"><?= htmlspecialchars($item['status']) ?></span>
                      </td>
                      <td style="text-align: right;">
                        <div class="actions-group">
                          <button type="button" class="icon-action-btn" title="View & Print Invoice Receipt" data-invoice="<?= htmlspecialchars($item['invoice_no']) ?>" onclick="app.viewInvoice('<?= htmlspecialchars($item['invoice_no']) ?>')">
                            <i class="fas fa-receipt"></i>
                          </button>
                          <button type="button" class="icon-action-btn" title="Cycle Status" data-invoice="<?= htmlspecialchars($item['invoice_no']) ?>" data-status="<?= htmlspecialchars($item['status']) ?>" onclick="app.cycleInvoiceStatus('<?= htmlspecialchars($item['invoice_no']) ?>', '<?= htmlspecialchars($item['status']) ?>')">
                            <i class="fas fa-sync-alt"></i>
                          </button>
                          <button type="button" class="icon-action-btn delete" title="Delete Invoice" data-invoice="<?= htmlspecialchars($item['invoice_no']) ?>" onclick="app.deleteInvoicePrompt('<?= htmlspecialchars($item['invoice_no']) ?>')">
                            <i class="fas fa-trash-alt"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="7" style="text-align: center; padding: 48px 20px; color: var(--text-dim);">
                      <i class="fas fa-file-invoice" style="font-size: 36px; margin-bottom: 12px; opacity: 0.4;"></i>
                      <p>No payment records found.</p>
                    </td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- View 1: Dashboard / Reports -->
        <div class="page-view" id="view-dashboard"></div>

        <!-- View 2: Fleet Management -->
        <div class="page-view" id="view-fleet"></div>

        <!-- View 3: Bookings Management -->
        <div class="page-view" id="view-bookings"></div>

        <!-- View 4: Customer Directory -->
        <div class="page-view" id="view-customers"></div>
          <div class="page-view" id="view-chat"><div style="display:grid;grid-template-columns:300px 1fr;gap:18px;height:calc(100vh - 150px);min-height:520px;"><div id="adminChatUsers" style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:18px;overflow:auto;padding:10px;"><h3 style="padding:12px;">Customer Chats</h3></div><div style="display:flex;flex-direction:column;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:18px;overflow:hidden;"><div id="adminChatTitle" style="padding:16px;border-bottom:1px solid rgba(255,255,255,.1);font-weight:700;">Select a customer</div><div id="adminChatMsgs" style="flex:1;overflow:auto;padding:18px;"></div><form id="adminChatForm" style="display:flex;gap:10px;padding:12px;border-top:1px solid rgba(255,255,255,.1);"><input id="adminChatInput" style="flex:1;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:inherit;" placeholder="Reply to customer..."><button class="primary-btn" id="adminChatSend" type="submit" style="color:#111!important;-webkit-text-fill-color:#111!important;font-weight:800;opacity:1;visibility:visible;">Send</button></form></div></div></div>
        

        <div class="page-view" id="view-carts"></div>

        <!-- View 5: Chauffeurs & Drivers -->
        <div class="page-view" id="view-drivers"></div>

        <!-- View 6: Live GPS Tracker -->
        <div class="page-view" id="view-gps"></div>

        <!-- View 7: Maintenance Logs -->
        <div class="page-view" id="view-maintenance"></div>

        <!-- View 8: Financials & Rates -->
        <div class="page-view" id="view-financials">
          <div class="financial-report-wrap">
            <div class="financial-report-heading"><div><span class="report-eyebrow">FINANCE CENTER</span><h2>Financials &amp; Rates</h2><p>Choose one date or a date range and download the complete financial report as a CSV worksheet.</p></div><div class="report-icon"><i class="fas fa-file-csv"></i></div></div>
            <div class="financial-report-card">
              <div class="report-card-title"><i class="fas fa-calendar-alt"></i><div><h3>Export Financial Report</h3><p>Includes booking, customer, vehicle, payment and invoice details.</p></div></div>
              <form id="financialReportForm" class="financial-report-form" action="financial-report.php" method="get" target="_blank">
                <div class="report-date-field"><label for="reportStartDate">From date</label><input type="date" id="reportStartDate" name="start_date" required></div>
                <div class="report-date-field"><label for="reportEndDate">To date</label><input type="date" id="reportEndDate" name="end_date" required></div>
                <button class="report-download-btn" type="submit"><i class="fas fa-download"></i> Download CSV Worksheet</button>
              </form>
              <div class="report-quick-actions"><button type="button" data-report-period="day">Today</button><button type="button" data-report-period="month">This month</button><button type="button" data-report-period="all">All dates</button></div>
              <div class="report-includes"><strong>Report includes</strong><span>Booking reference and status</span><span>Customer contact details</span><span>Vehicle and rental dates</span><span>Rental days and total price</span><span>Payment method and payment status</span><span>Invoice details and dates</span></div>
              <p class="report-note"><i class="fas fa-info-circle"></i> The report is generated from records stored in the database. The selected dates filter bookings by booking creation date and invoices by invoice date.</p>
            </div>
          </div>
        </div>

        <!-- View 9: Admin Settings -->
        <div class="page-view" id="view-settings"></div>
      </main>
    </div>
  </div>

  <!-- ==========================================================================
       MODALS
       ========================================================================== -->

  <!-- Modal 1: Add New Vehicle -->
  <div class="modal-overlay" id="modal-add-vehicle">
    <div class="modal-box">
      <div class="modal-header">
        <h2><i class="fas fa-car" style="color:var(--accent-primary);"></i> Add Vehicle to Fleet</h2>
        <button class="modal-close-btn" onclick="app.closeModal('modal-add-vehicle')">&times;</button>
      </div>
      <form onsubmit="app.handleAddVehicle(event)">
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Vehicle Name / Model</label>
              <input type="text" class="form-control" id="vehName" placeholder="e.g. BMW M3 Competition" required>
            </div>
            <div class="form-group">
              <label>Brand / Manufacturer</label>
              <input type="text" class="form-control" id="vehBrand" placeholder="e.g. BMW" required>
            </div>
            <div class="form-group">
              <label>Category</label>
              <select class="form-control" id="vehCategory">
                <option value="Electric">Electric (EV)</option>
                <option value="Sports">Sports</option>
                <option value="Luxury SUV">Luxury SUV</option>
                <option value="SUV">SUV</option>
                <option value="Sedan">Sedan</option>
              </select>
            </div>
            <div class="form-group">
              <label>Location</label>
              <select class="form-control" id="vehLocation" required>
                <option value="Galle">Galle</option>
                <option value="Matara" selected>Matara</option>
                <option value="Hambantota">Hambantota</option>
              </select>
            </div>
            <div class="form-group">
              <label>Service Type</label>
              <select class="form-control" id="vehServiceType" required>
                <option value="Vehicle Only">Vehicle Only</option>
                <option value="Both" selected>Both</option>
                <option value="With Driver">With Driver</option>
              </select>
            </div>
            <div class="form-group">
              <label>License Plate Number</label>
              <input type="text" class="form-control" id="vehPlate" placeholder="e.g. WP CAR-9988" required>
            </div>
            <div class="form-group">
              <label>Daily Rental Rate ($)</label>
              <input type="number" class="form-control" id="vehRate" placeholder="180" required>
            </div>
            <div class="form-group">
              <label>Fuel Type / EV</label>
              <select class="form-control" id="vehFuel">
                <option value="Petrol">Petrol</option>
                <option value="EV (100%)">EV / Electric</option>
                <option value="Diesel">Diesel</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>
            <div class="form-group">
              <label>Seating Capacity</label>
              <input type="number" class="form-control" id="vehSeats" value="5" required>
            </div>
            <div class="form-group">
              <label>Transmission</label>
              <select class="form-control" id="vehTransmission">
                <option value="Automatic">Automatic</option>
                <option value="Manual">Manual</option>
              </select>
            </div>
            <div class="form-group full-width">
              <label>Image URL (Unsplash or Direct Link)</label>
              <input type="url" class="form-control" id="vehImage" placeholder="https://images.unsplash.com/photo-...">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="secondary-btn" onclick="app.closeModal('modal-add-vehicle')">Cancel</button>
          <button type="submit" class="primary-btn"><i class="fas fa-plus-circle"></i> Add Vehicle</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal 2: Add Booking Reservation -->
  <div class="modal-overlay" id="modal-add-booking">
    <div class="modal-box">
      <div class="modal-header">
        <h2><i class="fas fa-calendar-plus" style="color:var(--accent-cyan);"></i> New Vehicle Reservation</h2>
        <button class="modal-close-btn" onclick="app.closeModal('modal-add-booking')">&times;</button>
      </div>
      <form onsubmit="app.handleAddBooking(event)">
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Customer Full Name</label>
              <input type="text" class="form-control" id="bookCustomerName" placeholder="e.g. Kasun Fernando" required>
            </div>
            <div class="form-group">
              <label>Customer Phone Number</label>
              <input type="text" class="form-control" id="bookCustomerPhone" placeholder="+94 77 000 1122" required>
            </div>
            <div class="form-group full-width">
              <label>Select Vehicle</label>
              <select class="form-control" id="bookVehicleSelect">
                <option value="V001">Tesla Model S Plaid ($180 / day)</option>
                <option value="V004">Audi RS e-tron GT ($210 / day)</option>
                <option value="V006">Range Rover Autobiography ($290 / day)</option>
                <option value="V008">Hyundai Ioniq 5 ($130 / day)</option>
              </select>
            </div>
            <div class="form-group">
              <label>Pickup Date</label>
              <input type="date" class="form-control" id="bookPickupDate" required>
            </div>
            <div class="form-group">
              <label>Return Date</label>
              <input type="date" class="form-control" id="bookReturnDate" required>
            </div>
            <div class="form-group">
              <label>Pickup Location</label>
              <input type="text" class="form-control" id="bookPickupLoc" value="Colombo 03 Main Hub">
            </div>
            <div class="form-group">
              <label>Return Location</label>
              <input type="text" class="form-control" id="bookReturnLoc" value="Colombo 03 Main Hub">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="secondary-btn" onclick="app.closeModal('modal-add-booking')">Cancel</button>
          <button type="submit" class="primary-btn"><i class="fas fa-check"></i> Generate Booking</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal 3: Add Maintenance Ticket -->
  <div class="modal-overlay" id="modal-add-maintenance">
    <div class="modal-box">
      <div class="modal-header">
        <h2><i class="fas fa-tools" style="color:var(--accent-amber);"></i> New Service & Maintenance Ticket</h2>
        <button class="modal-close-btn" onclick="app.closeModal('modal-add-maintenance')">&times;</button>
      </div>
      <form onsubmit="app.handleAddMaintenance(event)">
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group full-width">
              <label>Select Vehicle</label>
              <select class="form-control" id="mntVehicleSelect" required>
                <option value="">Loading vehicles...</option>
              </select>
            </div>
            <div class="form-group full-width">
              <label>Service / Issue Description</label>
              <input type="text" class="form-control" id="mntIssue" placeholder="e.g. Engine Oil Service & Brake Pad Renewal" required>
            </div>
            <div class="form-group">
              <label>Estimated Cost ($)</label>
              <input type="number" class="form-control" id="mntCost" placeholder="450" required>
            </div>
            <div class="form-group">
              <label>Service Center / Workshop</label>
              <input type="text" class="form-control" id="mntCenter" placeholder="e.g. AutoBavaria Workshop" required>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="secondary-btn" onclick="app.closeModal('modal-add-maintenance')">Cancel</button>
          <button type="submit" class="primary-btn"><i class="fas fa-wrench"></i> Submit Ticket</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal 4: Chauffeur Profile -->
  <div class="modal-overlay" id="modal-add-chauffeur">
    <div class="modal-box" style="max-width:980px;">
      <div class="modal-header">
        <h2><i class="fas fa-user-tie" style="color:var(--accent-cyan);"></i> Add Chauffeur Profile</h2>
        <button class="modal-close-btn" onclick="app.closeModal('modal-add-chauffeur')">&times;</button>
      </div>
      <form id="chauffeurForm" onsubmit="app.handleSaveChauffeur(event)">
        <input type="hidden" id="chauffeurDbId">
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group"><label>Driver Code</label><input class="form-control" id="chauffeurCode" placeholder="Auto e.g. CH-0001"></div>
            <div class="form-group"><label>Full Name *</label><input class="form-control" id="chauffeurName" placeholder="e.g. Kasun Fernando" required></div>
            <div class="form-group"><label>Phone Number</label><input class="form-control" id="chauffeurPhone" placeholder="+94 77 123 4567"></div>
            <div class="form-group"><label>Email</label><input type="email" class="form-control" id="chauffeurEmail" placeholder="driver@example.com"></div>
            <div class="form-group"><label>NIC / ID Number</label><input class="form-control" id="chauffeurNic" placeholder="NIC / Passport"></div>
            <div class="form-group"><label>Driving License No.</label><input class="form-control" id="chauffeurLicense" placeholder="B1234567"></div>
            <div class="form-group"><label>License Expiry</label><input type="date" class="form-control" id="chauffeurLicenseExpiry"></div>
            <div class="form-group"><label>Emergency Contact</label><input class="form-control" id="chauffeurEmergency" placeholder="Name / phone"></div>
            <div class="form-group full-width"><label>Address</label><input class="form-control" id="chauffeurAddress" placeholder="Home address"></div>
            <div class="form-group"><label>Status</label><select class="form-control" id="chauffeurStatus"><option>Available</option><option>On Shift</option><option>On Leave</option><option>Off Duty</option><option>Suspended</option></select></div>
            <div class="form-group"><label>Assigned Vehicle</label><select class="form-control" id="chauffeurVehicleSelect"><option value="">Unassigned</option></select></div>
            <div class="form-group"><label>Shift Start</label><input type="time" class="form-control" id="chauffeurShiftStart" value="08:00"></div>
            <div class="form-group"><label>Shift End</label><input type="time" class="form-control" id="chauffeurShiftEnd" value="18:00"></div>
            <div class="form-group"><label>Work Days</label><input class="form-control" id="chauffeurWorkDays" value="Mon,Tue,Wed,Thu,Fri,Sat" placeholder="Mon,Tue,Wed..."></div>
            <div class="form-group"><label>Next Shift Date</label><input type="date" class="form-control" id="chauffeurNextShift"></div>
            <div class="form-group"><label>Daily Chauffeur Rate ($)</label><input type="number" min="0" step="0.01" class="form-control" id="chauffeurRate" value="0"></div>
            <div class="form-group"><label>Completed Trips</label><input type="number" min="0" class="form-control" id="chauffeurTrips" value="0"></div>
            <div class="form-group"><label>Rating (0 - 5)</label><input type="number" min="0" max="5" step="0.1" class="form-control" id="chauffeurRating" value="0"></div>
            <div class="form-group" style="display:flex;align-items:center;gap:10px;padding-top:26px;"><input type="checkbox" id="chauffeurActive" checked style="width:18px;height:18px;"><label for="chauffeurActive" style="margin:0;">Active Profile</label></div>
            <div class="form-group full-width"><label>Admin Notes</label><textarea class="form-control" id="chauffeurNotes" rows="3" placeholder="Availability notes, special skills, route preferences..."></textarea></div>
          </div>
        </div>
        <div class="modal-footer"><button type="button" class="secondary-btn" onclick="app.resetChauffeurModal();app.closeModal('modal-add-chauffeur')">Cancel</button><button type="submit" class="primary-btn"><i class="fas fa-user-plus"></i> Add Chauffeur</button></div>
      </form>
    </div>
  </div>

  <!-- Modal 4: Invoice Preview -->
  <div class="modal-overlay" id="modal-view-invoice">
    <div class="modal-box" style="max-width:720px;">
      <div class="modal-header">
        <h2>Reservation Invoice</h2>
        <button class="modal-close-btn" onclick="app.closeModal('modal-view-invoice')">&times;</button>
      </div>
      <div class="modal-body" id="invoiceModalBody"></div>
    </div>
  </div>

  <!-- Modal 5: Record Payment (Image 3) -->
  <div class="modal-overlay" id="modal-record-payment">
    <div class="modal-box" style="max-width:640px;">
      <div class="modal-header">
        <h2><i class="fas fa-credit-card" style="color:#ff5722;"></i> Record New Payment</h2>
        <button class="modal-close-btn" onclick="app.closeModal('modal-record-payment')">&times;</button>
      </div>
      <form onsubmit="app.handleRecordPayment(event)">
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Invoice Number</label>
              <input type="text" class="form-control" id="payInvoiceNo" placeholder="e.g. INV-2410" required>
            </div>
            <div class="form-group">
              <label>Customer Name</label>
              <input type="text" class="form-control" id="payCustomerName" placeholder="e.g. Customer Name" required>
            </div>
            <div class="form-group full-width">
              <label>Description / Rental Details</label>
              <input type="text" class="form-control" id="payDescription" placeholder="e.g. Toyota C-HR · 3 days" required>
            </div>
            <div class="form-group">
              <label>Invoice Date</label>
              <input type="date" class="form-control" id="payDate" required>
            </div>
            <div class="form-group">
              <label>Amount ($)</label>
              <input type="number" step="0.01" class="form-control" id="payAmount" placeholder="990" required>
            </div>
            <div class="form-group">
              <label>Payment Status</label>
              <select class="form-control" id="payStatus">
                <option value="Paid" selected>Paid</option>
                <option value="Pending">Pending</option>
                <option value="Refunded">Refunded</option>
              </select>
            </div>
            <div class="form-group">
              <label>Payment Method</label>
              <select class="form-control" id="payMethod">
                <option value="Credit Card" selected>Credit Card</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Cash">Cash</option>
                <option value="Online Card">Online Card</option>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="secondary-btn" onclick="app.closeModal('modal-record-payment')">Cancel</button>
          <button type="submit" class="primary-btn" style="background:#ff5722;border-color:#ff5722;"><i class="fas fa-check"></i> Save Payment</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Toast Notification Container -->
  <div id="toast-container"></div>

  <!-- Initial Data & Core Script Modules -->
  <script>
    window.paymentsInitialData = <?= json_encode($paymentsList, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
  </script>
  <script src="js/store.js?v=<?= time() ?>"></script>
  <script src="js/charts.js?v=<?= time() ?>"></script>
  <script src="js/components.js?v=<?= time() ?>"></script>
  <script src="js/app.js?v=<?= time() ?>"></script>
  <script src="liquid-click.js?v=<?= time() ?>"></script>

<style>
.admin-profile-footer{gap:10px!important}
.admin-avatar-picker{position:relative;display:block;flex:0 0 42px;width:42px;height:42px;padding:0;border:0;border-radius:50%;background:#e2e8f0;cursor:pointer;overflow:visible}
.admin-avatar-picker .admin-avatar{display:block;width:42px;height:42px;object-fit:cover;border-radius:50%;border:2px solid rgba(20,184,166,.7)}
.avatar-edit-badge{position:absolute;right:-3px;bottom:-3px;width:18px;height:18px;border:2px solid var(--sidebar-bg,#111827);border-radius:50%;display:grid;place-items:center;background:#0d9488;color:#fff;font-size:9px}
.admin-avatar-picker:focus-visible{outline:3px solid #14b8a6;outline-offset:3px}
</style>
<script>
(function(){
 const picker=document.getElementById('adminAvatarPicker');
 const input=document.getElementById('adminAvatarFile');
 const preview=document.getElementById('adminAvatarPreview');
 if(!picker||!input||!preview)return;
 picker.addEventListener('click',()=>input.click());
 input.addEventListener('change',async()=>{
   const file=input.files&&input.files[0]; if(!file)return;
   if(!['image/jpeg','image/png','image/webp'].includes(file.type)){alert('Please choose a JPG, PNG, or WEBP image.');input.value='';return;}
   if(file.size>2*1024*1024){alert('Image must be 2 MB or smaller.');input.value='';return;}
   const data=new FormData();data.append('avatar',file);
   picker.disabled=true;
   try{
     const response=await fetch('profile-photo.php',{method:'POST',body:data,credentials:'same-origin'});
     const result=await response.json();
     if(!response.ok||!result.success)throw new Error(result.message||'Could not update profile photo.');
     preview.src=result.path+'?v='+Date.now();
   }catch(error){alert(error.message||'Could not upload profile photo. Please try again.');}
   finally{picker.disabled=false;input.value='';}
 });
})();
</script>

<style>
.financial-report-wrap{max-width:1100px;margin:0 auto;padding:8px 4px 30px;color:var(--text-primary,#172033)}
.financial-report-heading{display:flex;justify-content:space-between;align-items:center;margin:10px 0 24px;gap:20px}.report-eyebrow{font-size:11px;letter-spacing:2px;font-weight:800;color:#0d9488}.financial-report-heading h2{font-size:28px;margin:6px 0}.financial-report-heading p,.report-card-title p{margin:0;color:#718096;font-size:14px}.report-icon{width:58px;height:58px;border-radius:18px;background:#d1fae5;color:#047857;display:grid;place-items:center;font-size:25px}
.financial-report-card{background:#fff;border:1px solid #e2e8f0;border-radius:20px;padding:28px;box-shadow:0 12px 35px rgba(15,23,42,.06)}.report-card-title{display:flex;align-items:center;gap:14px;margin-bottom:26px}.report-card-title>i{width:46px;height:46px;border-radius:14px;background:#ecfdf5;color:#059669;display:grid;place-items:center;font-size:20px}.report-card-title h3{margin:0 0 5px;font-size:19px}.financial-report-form{display:grid;grid-template-columns:1fr 1fr auto;align-items:end;gap:16px}.report-date-field label{display:block;font-weight:700;font-size:13px;margin-bottom:9px;color:#334155}.report-date-field input{box-sizing:border-box;width:100%;min-height:48px;border:1px solid #cbd5e1;border-radius:10px;padding:0 12px;font:inherit;color:#0f172a;background:#fff}.report-date-field input:focus{outline:2px solid #a7f3d0;border-color:#059669}.report-download-btn{border:0;border-radius:10px;background:#059669;color:#fff;font-weight:800;min-height:48px;padding:0 20px;cursor:pointer;white-space:nowrap}.report-download-btn:hover{background:#047857}.report-quick-actions{display:flex;gap:9px;margin:17px 0 26px;flex-wrap:wrap}.report-quick-actions button{border:1px solid #cbd5e1;background:#fff;color:#334155;border-radius:8px;padding:8px 13px;cursor:pointer}.report-quick-actions button:hover{border-color:#059669;color:#047857}.report-includes{display:flex;flex-wrap:wrap;gap:10px;padding:18px;background:#f8fafc;border-radius:12px}.report-includes strong{width:100%;margin-bottom:2px}.report-includes span{background:#fff;border:1px solid #e2e8f0;border-radius:7px;padding:7px 10px;font-size:12px;color:#475569}.report-note{font-size:12px;line-height:1.6;color:#64748b;margin:18px 0 0}.report-note i{color:#059669;margin-right:5px}@media(max-width:850px){.financial-report-form{grid-template-columns:1fr}.report-download-btn{width:100%}.financial-report-card{padding:18px}.financial-report-heading h2{font-size:23px}}
</style>
<script>
(function(){
 const start=document.getElementById('reportStartDate'),end=document.getElementById('reportEndDate');if(!start||!end)return;
 const today=new Date();const fmt=d=>{const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`};
 start.value=fmt(today);end.value=fmt(today);start.max=fmt(today);end.max=fmt(today);
 start.addEventListener('change',()=>{end.min=start.value;if(end.value<start.value)end.value=start.value;});
 end.addEventListener('change',()=>{if(start.value&&end.value<start.value){alert('To date must be on or after From date.');end.value=start.value;}});
 document.querySelectorAll('[data-report-period]').forEach(btn=>btn.addEventListener('click',()=>{const now=new Date();let a=new Date(now),b=new Date(now);const period=btn.dataset.reportPeriod;if(period==='month')a=new Date(now.getFullYear(),now.getMonth(),1);if(period==='all')a=new Date(2000,0,1);start.value=fmt(a);end.value=fmt(b);start.dispatchEvent(new Event('change'));}));
 document.getElementById('financialReportForm').addEventListener('submit',e=>{if(!start.value||!end.value||end.value<start.value){e.preventDefault();alert('Please select a valid date range.');}});
})();
</script>

</body>
</html>
