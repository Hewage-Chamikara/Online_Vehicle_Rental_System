<?php
session_start();
if (empty($_SESSION['admin_id'])) { http_response_code(401); exit('Unauthorized. Please sign in again.'); }
require_once __DIR__ . '/db.php';

$start = trim((string)($_GET['start_date'] ?? ''));
$end = trim((string)($_GET['end_date'] ?? ''));
$isDate = static function($value) { $d = DateTime::createFromFormat('!Y-m-d', (string)$value); return $d && $d->format('Y-m-d') === $value; };
if (!$isDate($start) || !$isDate($end) || $end < $start) { http_response_code(400); exit('Please select a valid date range.'); }

// Discover the installed schema rather than assuming every project database has the same columns.
$getColumns = static function(mysqli $db, string $table): array {
    $safe = str_replace('`', '``', $table);
    $result = $db->query("SHOW COLUMNS FROM `{$safe}`");
    $cols = [];
    while ($row = $result->fetch_assoc()) $cols[strtolower($row['Field'])] = $row['Field'];
    return $cols;
};
$pick = static function(array $row, array $names, $default = '') {
    foreach ($names as $name) if (array_key_exists($name, $row) && $row[$name] !== null) return $row[$name];
    return $default;
};
$rows = [];
$headers = ['Record Type','Booking ID','Booking Reference','Invoice Number','Record Date','Customer ID','Customer Name','Customer Email','Customer Phone','Vehicle ID','Vehicle Name','Vehicle Plate Number','Pickup Date','Drop-off Date','Pickup Location','Drop-off Location','Rental Days','Daily Rate','Total Amount','Currency','Booking Status','Payment Method','Payment Status','Invoice Description','Created At','Updated At'];
try {
    $bookingCols = $getColumns($conn, 'bookings');
    $dateCol = isset($bookingCols['created_at']) ? $bookingCols['created_at'] : (isset($bookingCols['pickup_date']) ? $bookingCols['pickup_date'] : null);
    if ($dateCol) {
        $sql = 'SELECT * FROM `bookings` WHERE DATE(`' . str_replace('`','``',$dateCol) . '`) BETWEEN ? AND ? ORDER BY `' . str_replace('`','``',$dateCol) . '`';
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $start, $end); $stmt->execute();
        $result = $stmt->get_result();
        $vehicleCols = [];
        try { $vehicleCols = $getColumns($conn, 'vehicles'); } catch (Throwable $e) {}
        $vehicleMap = [];
        if ($vehicleCols && isset($vehicleCols['id'])) {
            $vr = $conn->query('SELECT * FROM vehicles');
            while ($v = $vr->fetch_assoc()) {
                foreach (['id','vehicle_code'] as $key) if (isset($v[$key])) $vehicleMap[(string)$v[$key]] = $v;
            }
        }
        while ($b = $result->fetch_assoc()) {
            $vehicleId = (string)$pick($b, ['vehicle_id']);
            $v = $vehicleMap[$vehicleId] ?? [];
            $days = (int)$pick($b, ['rental_days','days'], 0);
            $total = (float)$pick($b, ['total_amount','total_price','price_usd','amount','total'], 0);
            if ($days <= 0) {
                $p = strtotime((string)$pick($b,['pickup_date'])); $d = strtotime((string)$pick($b,['dropoff_date','return_date']));
                if ($p && $d && $d >= $p) $days = max(1, (int)ceil(($d-$p)/86400));
            }
            $daily = (float)$pick($b, ['daily_rate','price_per_day','daily_price'], $days > 0 ? $total/$days : 0);
            $status = (string)$pick($b, ['status','booking_status']);
            $method = (string)$pick($b, ['payment_method','payment_type']);
            $payStatus = (string)$pick($b, ['payment_status','paid_status']);
            if ($payStatus === '') $payStatus = in_array(strtolower($status), ['cancelled','canceled'], true) ? 'Cancelled' : (in_array(strtolower($method), ['','unpaid','pending'], true) ? 'Pending / Unpaid' : 'Not specified');
            $rows[] = ['Booking',$pick($b,['id','booking_id']),$pick($b,['booking_ref','booking_reference','reference','ref_no']),'',$pick($b,[$dateCol]),$pick($b,['customer_id','user_id']),$pick($b,['customer_name','name','full_name']),$pick($b,['customer_email','email']),$pick($b,['customer_phone','phone','mobile']),$vehicleId,$pick($b,['vehicle_name','car_name','name'], $pick($v,['name','model'])), $pick($b,['vehicle_plate','plate_number'], $pick($v,['plate','plate_number','registration_number'])),$pick($b,['pickup_date','start_date','rental_start']),$pick($b,['dropoff_date','return_date','end_date','rental_end']),$pick($b,['pickup_location','pickup_address','start_location']),$pick($b,['dropoff_location','return_location','dropoff_address','end_location']),$days,number_format($daily,2,'.',''),number_format($total,2,'.',''),$pick($b,['currency','paid_currency'],'USD'),$status,$method,$payStatus,$pick($b,['description','addons','notes']),$pick($b,['created_at']),$pick($b,['updated_at'])];
        }
        $stmt->close();
    }
} catch (Throwable $e) { error_log('Financial CSV booking export: '.$e->getMessage()); http_response_code(500); exit('Unable to create booking report. Check PHP error log and database schema.'); }

// Add invoice rows only if an invoices table and a usable date column exist.
try {
    $invoiceCols = $getColumns($conn, 'invoices');
    $invoiceDateCol = isset($invoiceCols['invoice_date']) ? $invoiceCols['invoice_date'] : (isset($invoiceCols['created_at']) ? $invoiceCols['created_at'] : null);
    if ($invoiceDateCol) {
        $safeDate = str_replace('`','``',$invoiceDateCol);
        $stmt = $conn->prepare('SELECT * FROM `invoices` WHERE DATE(`'.$safeDate.'`) BETWEEN ? AND ? ORDER BY `'.$safeDate.'`');
        $stmt->bind_param('ss',$start,$end); $stmt->execute(); $result=$stmt->get_result();
        while ($r=$result->fetch_assoc()) {
            $rows[] = ['Invoice',$pick($r,['booking_id','reservation_id']),$pick($r,['booking_ref','booking_reference'] ),$pick($r,['invoice_no','invoice_number','number']),$pick($r,['invoice_date','created_at']),$pick($r,['customer_id','user_id']),$pick($r,['customer_name','name']),$pick($r,['customer_email','email']),$pick($r,['customer_phone','phone']),$pick($r,['vehicle_id']),$pick($r,['vehicle_name','car_name']),$pick($r,['vehicle_plate','plate_number']),$pick($r,['pickup_date','start_date']),$pick($r,['dropoff_date','return_date','end_date']),$pick($r,['pickup_location','pickup_address']),$pick($r,['dropoff_location','dropoff_address']),$pick($r,['rental_days','days']),$pick($r,['daily_rate','price_per_day']),$pick($r,['amount','total_amount','total']),$pick($r,['currency','paid_currency'],'USD'),$pick($r,['booking_status','status']),$pick($r,['payment_method']),$pick($r,['payment_status','status']),$pick($r,['description','details','notes']),$pick($r,['created_at']),$pick($r,['updated_at'])];
        }
        $stmt->close();
    }
} catch (Throwable $e) { error_log('Financial CSV invoice export (optional): '.$e->getMessage()); }

// Build the complete output before sending download headers, so PHP/database errors do not corrupt the CSV response.
while (ob_get_level() > 0) { ob_end_clean(); }
$filename = 'financial-report_'.$start.'_to_'.$end.'.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
$out=fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF"); fputcsv($out,$headers);
foreach ($rows as $row) fputcsv($out,$row);
fclose($out); exit;
