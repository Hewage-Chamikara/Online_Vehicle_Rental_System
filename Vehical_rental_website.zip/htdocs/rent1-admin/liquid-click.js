(function(){
  document.addEventListener('click', function(e){
    const el=e.target.closest('button, a, [role="button"], input[type="button"], input[type="submit"]');
    if(!el || el.disabled || el.getAttribute('aria-disabled')==='true') return;
    el.classList.remove('liquid-clicked');
    void el.offsetWidth;
    el.classList.add('liquid-clicked');
    setTimeout(()=>el.classList.remove('liquid-clicked'),650);
  }, true);
})();
