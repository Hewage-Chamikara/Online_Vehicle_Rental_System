<?php
session_start();
require_once __DIR__.'/db.php';

if (isset($_SESSION['admin_id'])) {
    header('Location: app.php');
    exit;
}

$error = '';
$success = '';
$activeMode = 'signin'; // 'signin' or 'signup'

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';

    if ($action === 'register') {
        $activeMode = 'signup';
        $fullname = trim($_POST['fullname'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (empty($fullname) || empty($email) || empty($password)) {
            $error = 'Please fill in all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($password !== $confirmPassword) {
            $error = 'Passwords do not match.';
        } else {
            // Check if user already exists
            $checkStmt = $conn->prepare("SELECT id FROM admin_users WHERE email = ? OR username = ? LIMIT 1");
            $username = explode('@', $email)[0];
            $checkStmt->bind_param('ss', $email, $username);
            $checkStmt->execute();
            if ($checkStmt->get_result()->num_rows > 0) {
                $error = 'An account with this email or username already exists.';
                $checkStmt->close();
            } else {
                $checkStmt->close();
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $role = 'Fleet Manager';
                $insertStmt = $conn->prepare("INSERT INTO admin_users (username, email, full_name, role, password_hash) VALUES (?, ?, ?, ?, ?)");
                $insertStmt->bind_param('sssss', $username, $email, $fullname, $role, $hash);
                if ($insertStmt->execute()) {
                    $newId = $insertStmt->insert_id;
                    $insertStmt->close();
                    session_regenerate_id(true);
                    $_SESSION['admin_id'] = $newId;
                    $_SESSION['admin_username'] = $username;
                    $_SESSION['admin_fullname'] = $fullname;
                    $_SESSION['admin_email'] = $email;
                    $_SESSION['admin_role'] = $role;
                    $_SESSION['admin_avatar'] = '';
                    header('Location: app.php');
                    exit;
                } else {
                    $error = 'Failed to register account. Please try again.';
                    $insertStmt->close();
                }
            }
        }
    } else {
        // Sign in / Login
        $activeMode = 'signin';
        $loginInput = trim($_POST['email_or_username'] ?? $_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($loginInput) || empty($password)) {
            $error = 'Please enter your username/email and password.';
        } else {
            $stmt = $conn->prepare("SELECT id, username, email, full_name, role, avatar_path, password_hash FROM admin_users WHERE username = ? OR email = ? LIMIT 1");
            $stmt->bind_param('ss', $loginInput, $loginInput);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($user && password_verify($password, $user['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['admin_fullname'] = !empty($user['full_name']) ? $user['full_name'] : 'Dominic Reyes';
                $_SESSION['admin_email'] = !empty($user['email']) ? $user['email'] : 'manager@veloce.rent';
                $_SESSION['admin_role'] = !empty($user['role']) ? $user['role'] : 'Fleet Manager';
                $_SESSION['admin_avatar'] = !empty($user['avatar_path']) ? $user['avatar_path'] : '';
                header('Location: app.php');
                exit;
            } else {
                $error = 'Invalid email/username or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chamikara Rant A-Car • Fleet Portal Login</title>
  
  <!-- Google Fonts: Outfit & Plus Jakarta Sans -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- FontAwesome 6 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <style>
    :root {
      --bg-page: #0a0d14;
      --card-bg: #121620;
      --card-border: rgba(255, 255, 255, 0.08);
      --card-shadow: 0 35px 80px -15px rgba(0, 0, 0, 0.85);
      --accent-orange: #ff5722;
      --accent-orange-hover: #f4511e;
      --accent-orange-gradient: linear-gradient(145deg, #ff6a3d 0%, #ff5722 45%, #e64a19 100%);
      --text-white: #ffffff;
      --text-muted: #94a3b8;
      --text-dim: #64748b;
      --input-bg: #181d2a;
      --input-border: rgba(255, 255, 255, 0.09);
      --input-focus: #ff5722;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-page);
      background-image: 
        radial-gradient(circle at 50% 0%, rgba(255, 87, 34, 0.08) 0%, transparent 60%),
        linear-gradient(rgba(10, 13, 20, 0.88), rgba(10, 13, 20, 0.94)),
        url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1920&q=80');
      background-position: center center;
      background-size: cover;
      background-attachment: fixed;
      color: var(--text-white);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 24px 16px;
      position: relative;
    }

    /* Top Left Brand Header */
    .top-brand {
      position: absolute;
      top: 32px;
      left: 36px;
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
      z-index: 10;
    }

    .brand-icon-box {
      width: 44px;
      height: 44px;
      background: var(--accent-orange-gradient);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 20px;
      box-shadow: 0 8px 24px rgba(255, 87, 34, 0.35);
    }

    .brand-text-wrap {
      display: flex;
      flex-direction: column;
    }

    .brand-title {
      font-family: 'Outfit', sans-serif;
      font-size: 19px;
      font-weight: 800;
      letter-spacing: 2px;
      color: #ffffff;
      line-height: 1.1;
    }

    .brand-subtitle {
      font-size: 9.5px;
      font-weight: 600;
      letter-spacing: 2.5px;
      color: #94a3b8;
      text-transform: uppercase;
      margin-top: 2px;
    }

    /* Auth Main Modal Card */
    .auth-wrapper {
      width: 100%;
      max-width: 980px;
      min-height: 610px;
      background: var(--card-bg);
      border-radius: 28px;
      border: 1px solid var(--card-border);
      box-shadow: var(--card-shadow);
      display: flex;
      overflow: hidden;
      position: relative;
      backdrop-filter: blur(20px);
      transition: all 0.4s ease;
    }

    /* Two main views: Sign In and Join Crew (Sign Up) */
    .view-container {
      width: 100%;
      height: 100%;
      display: flex;
      flex: 1;
      transition: opacity 0.35s ease, transform 0.35s ease;
    }

    .view-container.hidden {
      display: none;
    }

    /* Left or Right Content Columns */
    .panel-side {
      flex: 1;
      padding: 44px 48px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: relative;
    }

    /* Vibrant Orange Hero Panel (used on Left in Join, Right in Sign In) */
    .panel-orange {
      background: var(--accent-orange-gradient);
      color: #ffffff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 50px 48px;
      position: relative;
      overflow: hidden;
    }

    /* Curved background art inside orange panel */
    .panel-orange::before {
      content: '';
      position: absolute;
      width: 380px;
      height: 380px;
      border-radius: 50%;
      border: 1px solid rgba(255, 255, 255, 0.16);
      bottom: -130px;
      left: -100px;
      pointer-events: none;
    }

    .panel-orange::after {
      content: '';
      position: absolute;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(255,255,255,0.12) 0%, transparent 70%);
      top: -60px;
      right: -60px;
      pointer-events: none;
    }

    /* Top indicators & badge inside orange panel */
    .panel-orange-top {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      gap: 16px;
      position: relative;
      z-index: 2;
    }

    .pill-dashes {
      display: flex;
      gap: 6px;
      align-items: center;
    }

    .pill-dash {
      width: 22px;
      height: 4px;
      border-radius: 3px;
      background: rgba(255, 255, 255, 0.4);
    }

    .pill-dash.active {
      background: #ffffff;
    }

    .orange-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 7px 16px;
      border-radius: 20px;
      background: rgba(0, 0, 0, 0.18);
      backdrop-filter: blur(10px);
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    /* Center Content inside Orange Panel */
    .panel-orange-center {
      text-align: center;
      margin: 32px 0;
      position: relative;
      z-index: 2;
    }

    .panel-orange-center h2 {
      font-family: 'Outfit', sans-serif;
      font-size: 34px;
      font-weight: 800;
      line-height: 1.15;
      margin-bottom: 14px;
      letter-spacing: -0.5px;
    }

    .panel-orange-center p {
      font-size: 14px;
      line-height: 1.6;
      color: rgba(255, 255, 255, 0.9);
      max-width: 320px;
      margin: 0 auto 28px;
    }

    .btn-outline-white {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 38px;
      border-radius: 30px;
      border: 1.5px solid rgba(255, 255, 255, 0.85);
      background: transparent;
      color: #ffffff;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.25s ease;
    }

    .btn-outline-white:hover {
      background: #ffffff;
      color: #e64a19;
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    }

    /* Bottom Quote */
    .panel-orange-quote {
      text-align: center;
      font-size: 12.5px;
      font-style: italic;
      color: rgba(255, 255, 255, 0.8);
      position: relative;
      z-index: 2;
    }

    /* Dark Form Panel */
    .panel-dark {
      background: var(--card-bg);
      color: var(--text-white);
    }

    .panel-dark-header {
      margin-bottom: 24px;
    }

    .panel-dark-header h1 {
      font-family: 'Outfit', sans-serif;
      font-size: 30px;
      font-weight: 800;
      letter-spacing: -0.5px;
      color: #ffffff;
      margin-bottom: 6px;
    }

    .panel-dark-header p {
      font-size: 13.5px;
      color: var(--text-muted);
    }

    /* Social SSO Buttons */
    .sso-row {
      display: flex;
      gap: 12px;
      margin-bottom: 20px;
    }

    .sso-btn {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      padding: 11px 16px;
      border-radius: 12px;
      border: 1px solid var(--input-border);
      background: var(--input-bg);
      color: #ffffff;
      font-size: 13.5px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .sso-btn:hover {
      border-color: rgba(255, 255, 255, 0.2);
      background: #202737;
      transform: translateY(-1px);
    }

    .sso-divider {
      display: flex;
      align-items: center;
      text-align: center;
      margin: 16px 0 20px;
      color: var(--text-dim);
      font-size: 12px;
    }

    .sso-divider::before,
    .sso-divider::after {
      content: '';
      flex: 1;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .sso-divider span {
      padding: 0 12px;
    }

    /* Form Styles */
    .form-group {
      margin-bottom: 16px;
      position: relative;
    }

    .form-label {
      display: block;
      font-size: 12px;
      font-weight: 600;
      color: #cbd5e1;
      margin-bottom: 6px;
      text-transform: capitalize;
    }

    .input-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }

    .input-icon-left {
      position: absolute;
      left: 14px;
      color: var(--text-dim);
      font-size: 14px;
      pointer-events: none;
    }

    .input-icon-right {
      position: absolute;
      right: 14px;
      color: var(--text-dim);
      font-size: 14px;
      cursor: pointer;
      transition: color 0.2s ease;
    }

    .input-icon-right:hover {
      color: #ffffff;
    }

    .auth-input {
      width: 100%;
      padding: 12px 14px 12px 42px;
      background: var(--input-bg);
      border: 1px solid var(--input-border);
      border-radius: 12px;
      color: #ffffff;
      font-size: 13.5px;
      font-family: inherit;
      outline: none;
      transition: all 0.2s ease;
    }

    .auth-input:focus {
      border-color: var(--accent-orange);
      background: #1c2232;
      box-shadow: 0 0 0 3px rgba(255, 87, 34, 0.15);
    }

    .auth-input::placeholder {
      color: #64748b;
      font-size: 13px;
    }

    /* Options Row: Remember Me & Forgot Password */
    .auth-options {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 18px 0 24px;
      font-size: 13px;
    }

    .remember-label {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #cbd5e1;
      cursor: pointer;
      user-select: none;
    }

    .remember-checkbox {
      appearance: none;
      -webkit-appearance: none;
      width: 18px;
      height: 18px;
      border-radius: 5px;
      border: 1px solid rgba(255, 255, 255, 0.2);
      background: var(--input-bg);
      cursor: pointer;
      position: relative;
      display: grid;
      place-content: center;
      transition: all 0.2s;
    }

    .remember-checkbox:checked {
      background: var(--accent-orange);
      border-color: var(--accent-orange);
    }

    .remember-checkbox:checked::after {
      content: '\f00c';
      font-family: 'Font Awesome 6 Free';
      font-weight: 900;
      font-size: 11px;
      color: white;
    }

    .forgot-link {
      color: #cbd5e1;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .forgot-link:hover {
      color: var(--accent-orange);
      text-decoration: underline;
    }

    /* Main Orange Button */
    .btn-primary-orange {
      width: 100%;
      padding: 13px 20px;
      border-radius: 12px;
      border: none;
      background: var(--accent-orange-gradient);
      color: #ffffff;
      font-family: 'Outfit', sans-serif;
      font-size: 15px;
      font-weight: 700;
      letter-spacing: 0.3px;
      cursor: pointer;
      box-shadow: 0 8px 24px rgba(255, 87, 34, 0.38);
      transition: all 0.25s ease;
    }

    .btn-primary-orange:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 28px rgba(255, 87, 34, 0.5);
      background: linear-gradient(145deg, #ff784d 0%, #ff5722 45%, #d84315 100%);
    }

    .btn-primary-orange:active {
      transform: translateY(0);
    }

    /* Switch View Links */
    .auth-switch {
      text-align: center;
      margin-top: 22px;
      font-size: 13px;
      color: var(--text-muted);
    }

    .auth-switch a {
      color: var(--accent-orange);
      font-weight: 600;
      text-decoration: none;
      cursor: pointer;
      margin-left: 4px;
    }

    .auth-switch a:hover {
      text-decoration: underline;
    }

    .demo-hint {
      text-align: center;
      margin-top: 14px;
      font-size: 11.5px;
      color: var(--text-dim);
    }

    /* Alert Banner */
    .alert-banner {
      padding: 11px 16px;
      border-radius: 10px;
      font-size: 13px;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .alert-danger {
      background: rgba(239, 68, 68, 0.12);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #fca5a5;
    }

    .alert-success {
      background: rgba(16, 185, 129, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.3);
      color: #6ee7b7;
    }

    /* Responsive adjustments */
    @media (max-width: 860px) {
      .top-brand {
        position: static;
        margin-bottom: 24px;
      }
      .auth-wrapper {
        flex-direction: column;
        max-width: 480px;
      }
      .panel-side {
        padding: 36px 28px;
      }
      .panel-orange {
        order: -1;
        padding: 36px 28px;
      }
    }

    /* Refreshed fleet login visual design */
    body { background-color:#080d16; background-image:radial-gradient(circle at 12% 18%,rgba(20,184,166,.16),transparent 32%),radial-gradient(circle at 90% 80%,rgba(255,87,34,.15),transparent 35%),linear-gradient(rgba(8,13,22,.88),rgba(8,13,22,.94)),url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1920&q=80'); }
    .auth-wrapper { border-radius:24px; border-color:rgba(148,163,184,.18); box-shadow:0 32px 90px rgba(0,0,0,.5); }
    .panel-dark { background:linear-gradient(155deg,#151d2b,#0f1520); }
    .panel-orange { background:linear-gradient(145deg,#0f766e 0%,#0d9488 52%,#115e59 100%); }
    .brand-icon-box { background:linear-gradient(145deg,#14b8a6,#0f766e); box-shadow:0 8px 24px rgba(20,184,166,.28); }
    .auth-input:focus { border-color:#14b8a6 !important; box-shadow:0 0 0 3px rgba(20,184,166,.13); }
    .auth-submit, .btn-primary { background:linear-gradient(135deg,#14b8a6,#0f766e) !important; }
    .auth-submit:hover, .btn-primary:hover { filter:brightness(1.08); }
    .panel-orange-quote { font-style:normal; }
    @media (max-width:600px) { .top-brand { top:14px; left:16px; } body { padding-top:82px; } }


    /* NEW LOGIN STRUCTURE: focused single-card layout, not just a color change */
    body {
      min-height: 100vh;
      padding: 34px 18px;
      justify-content: center;
      align-items: center;
      gap: 22px;
    }
    .top-brand {
      position: static;
      align-self: center;
      margin: 0 auto;
      gap: 13px;
    }
    .brand-icon-box { width: 48px; height: 48px; border-radius: 15px; }
    .brand-title { font-size: 21px; letter-spacing: .6px; }
    .brand-subtitle { letter-spacing: 2px; }

    /* The sign-in page is now one centered form card. The old side-by-side promo panel is removed. */
    #authWrapper {
      width: 100%;
      max-width: 470px;
      min-height: 0;
      height: auto;
      display: block;
      border-radius: 24px;
      overflow: hidden;
      background: #fff;
      border: 1px solid rgba(255,255,255,.22);
      box-shadow: 0 28px 85px rgba(0,0,0,.42);
      backdrop-filter: none;
    }
    #viewSignIn.view-container {
      display: block;
      width: 100%;
      height: auto;
    }
    #viewSignIn.view-container.hidden { display: none; }
    #viewSignIn .panel-dark {
      width: 100%;
      min-height: 0;
      padding: 42px 42px 34px;
      background: #fff;
      color: #172033;
      display: block;
    }
    #viewSignIn .panel-orange { display: none; }
    #viewSignIn .panel-dark-header { text-align: center; margin-bottom: 30px; }
    #viewSignIn .panel-dark-header::before {
      content: '\f2bd';
      font-family: 'Font Awesome 6 Free';
      font-weight: 900;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 68px;
      height: 68px;
      margin: 0 auto 18px;
      border-radius: 22px;
      color: #0f766e;
      background: #e6f7f4;
      font-size: 34px;
    }
    #viewSignIn .panel-dark-header h1 { color: #172033; font-size: 31px; margin-bottom: 8px; }
    #viewSignIn .panel-dark-header p { color: #697586; line-height: 1.65; }
    #viewSignIn .sso-row, #viewSignIn .sso-divider { display: none; }
    #viewSignIn .form-group { margin-bottom: 20px; }
    #viewSignIn .form-label { display: block; margin-bottom: 8px; color: #273449; font-weight: 700; }
    #viewSignIn .input-wrapper { position: relative; }
    #viewSignIn .auth-input {
      width: 100%; min-height: 52px; border-radius: 12px;
      background: #f5f7fa; border: 1px solid #dce3eb;
      color: #172033; padding: 14px 42px 14px 43px;
      outline: none; transition: .2s ease;
    }
    #viewSignIn .input-icon-left { color: #718096; left: 15px; }
    #viewSignIn .input-icon-right { color: #718096; right: 15px; cursor: pointer; }
    #viewSignIn .auth-options { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 25px; }
    #viewSignIn .remember-label { color: #536174; font-size: 12px; }
    #viewSignIn .forgot-link { color: #0f766e; font-size: 12px; font-weight: 700; }
    #viewSignIn .btn-primary-orange {
      width: 100%; min-height: 52px; border: 0; border-radius: 12px;
      color: #fff; font-size: 15px; font-weight: 800; cursor: pointer;
      background: linear-gradient(135deg,#0f766e,#14b8a6);
      box-shadow: 0 9px 20px rgba(15,118,110,.22);
    }
    #viewSignIn .auth-switch { text-align: center; margin-top: 23px; color: #687589; font-size: 12px; }
    #viewSignIn .auth-switch a { color: #0f766e; font-weight: 800; }
    #viewSignIn .demo-hint { margin-top: 18px; padding: 11px 12px; border-radius: 10px; background: #f0f8f7; color: #52716e; text-align: center; font-size: 11px; }
    #viewSignIn .alert-banner { margin-bottom: 18px; }

    /* Keep account creation functional and readable with its own centered card. */
    #viewSignUp.view-container { display: flex; width: 100%; min-height: 720px; }
    #viewSignUp.view-container.hidden { display: none; }
    /* Give the registration form a larger, more comfortable layout. */
    #authWrapper:has(#viewSignUp:not(.hidden)) { max-width: 960px; min-height: 720px; }
    #viewSignUp .panel-side { padding: 48px 44px; }
    #viewSignUp .panel-dark { flex: 1.15; }
    #viewSignUp .panel-orange { flex: .85; }
    #viewSignUp .panel-dark-header { margin-bottom: 28px; }
    #viewSignUp .panel-dark-header h1 { font-size: 34px; }
    #viewSignUp .panel-dark-header p { line-height: 1.65; }
    #viewSignUp .form-group { margin-bottom: 22px; }
    #viewSignUp .auth-input { min-height: 54px; }
    #viewSignUp .btn-primary-orange {
      background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%);
      box-shadow: 0 9px 22px rgba(15,118,110,.28);
    }
    #viewSignUp .btn-primary-orange:hover {
      background: linear-gradient(135deg, #115e59 0%, #0d9488 100%);
      box-shadow: 0 12px 26px rgba(15,118,110,.36);
    }
    @media (max-width: 900px) {
      #authWrapper:has(#viewSignUp:not(.hidden)) { max-width: 620px; }
      #viewSignUp.view-container { flex-direction: column; min-height: 0; }
      #viewSignUp .panel-orange { min-height: 260px; }
    }
    @media (max-width: 560px) {
      body { padding: 22px 14px; gap: 16px; }
      .top-brand { position: static; margin: 0 auto; }
      #authWrapper { max-width: 440px; }
      #authWrapper:has(#viewSignUp:not(.hidden)) { max-width: 440px; min-height: 0; }
      #viewSignIn .panel-dark { padding: 34px 24px 28px; }
      #viewSignUp.view-container { flex-direction: column; min-height: 0; }
      #viewSignUp .panel-side { padding: 30px 24px; }
      #viewSignUp .panel-orange { order: 0; min-height: 250px; }
    }

  </style>
</head>
<body>

  <!-- Top Left Brand Badge (Matches Image 1 & 2) -->
  <a href="index.php" class="top-brand">
    <div class="brand-icon-box">
      <i class="fas fa-tachometer-alt"></i>
    </div>
    <div class="brand-text-wrap">
      <span class="brand-title">Chamikara Rant A-Car</span>
      <span class="brand-subtitle">CAR RENTAL</span>
    </div>
  </a>

  <!-- Auth Main Container -->
  <div class="auth-wrapper" id="authWrapper">

    <!-- ======================================================================
         VIEW A: SIGN IN (WELCOME BACK) — EXACTLY MATCHES IMAGE 2
         ====================================================================== -->
    <div class="view-container <?= $activeMode === 'signin' ? '' : 'hidden' ?>" id="viewSignIn">
      <!-- Left Column: Dark Sign In Form -->
      <div class="panel-side panel-dark">
        <div class="panel-dark-header">
          <h1>Welcome back</h1>
          <p>Sign in to the fleet console to manage rentals and vehicles</p>
        </div>

        <?php if ($error && $activeMode === 'signin'): ?>
          <div class="alert-banner alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <span><?= htmlspecialchars($error) ?></span>
          </div>
        <?php endif; ?>

        <!-- Social Logins -->
        <div class="sso-row">
          <button type="button" class="sso-btn" onclick="quickFillDemo('Google')">
            <i class="fab fa-google" style="color:#ea4335;"></i> Google
          </button>
          <button type="button" class="sso-btn" onclick="quickFillDemo('GitHub')">
            <i class="fab fa-github"></i> GitHub
          </button>
        </div>

        <div class="sso-divider">
          <span>or continue with email</span>
        </div>

        <form method="POST" action="index.php">
          <input type="hidden" name="action" value="login">
          
          <div class="form-group">
            <label class="form-label">Email</label>
            <div class="input-wrapper">
              <i class="far fa-envelope input-icon-left"></i>
              <input type="text" name="email_or_username" class="auth-input" placeholder="manager@veloce.rent" value="<?= htmlspecialchars($_POST['email_or_username'] ?? 'manager@veloce.rent') ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrapper">
              <i class="fas fa-lock input-icon-left"></i>
              <input type="password" name="password" id="signinPassword" class="auth-input" placeholder="Enter your password" value="admin123" required>
              <i class="far fa-eye input-icon-right" onclick="togglePasswordVisibility('signinPassword', this)"></i>
            </div>
          </div>

          <div class="auth-options">
            <label class="remember-label">
              <input type="checkbox" name="remember" class="remember-checkbox" checked>
              <span>Remember me</span>
            </label>
            <a href="javascript:void(0)" class="forgot-link" onclick="alert('Please contact your system administrator to reset credentials.')">Forgot password?</a>
          </div>

          <button type="submit" class="btn-primary-orange">Sign in</button>

          <div class="auth-switch">
            New team member? <a href="javascript:void(0)" onclick="switchAuthMode('signup')">Create an account</a>
          </div>

        </form>
      </div>

      <!-- Right Column: Orange Hero Panel -->
      <div class="panel-side panel-orange">
        <div class="panel-orange-top">
          <div class="pill-dashes">
            <div class="pill-dash active"></div>
            <div class="pill-dash"></div>
            <div class="pill-dash"></div>
            <div class="pill-dash"></div>
            <div class="pill-dash"></div>
          </div>
          <div class="orange-badge">
            <i class="fas fa-car-side"></i> Chamikara Rant A-Car
          </div>
        </div>

        <div class="panel-orange-center">
          <h2>New to the crew?</h2>
          <p>Create your operator account and put the fleet to work in minutes.</p>
          <button type="button" class="btn-outline-white" onclick="switchAuthMode('signup')">Create account</button>
        </div>

        <div class="panel-orange-quote">
          &ldquo;Life is too short to drive boring cars.&rdquo;
        </div>
      </div>
    </div>


    <!-- ======================================================================
         VIEW B: REGISTER (JOIN THE CREW) — EXACTLY MATCHES IMAGE 1
         ====================================================================== -->
    <div class="view-container <?= $activeMode === 'signup' ? '' : 'hidden' ?>" id="viewSignUp">
      <!-- Left Column: Orange Hero Panel -->
      <div class="panel-side panel-orange">
        <div class="panel-orange-top">
          <div class="pill-dashes">
            <div class="pill-dash active"></div>
            <div class="pill-dash"></div>
            <div class="pill-dash"></div>
            <div class="pill-dash"></div>
            <div class="pill-dash"></div>
          </div>
          <div class="orange-badge">
            <i class="fas fa-car-side"></i> WELCOME BACK
          </div>
        </div>

        <div class="panel-orange-center">
          <h2>Back in the driver's seat</h2>
          <p>Sign in to keep the fleet moving &mdash; rentals, returns and maintenance await.</p>
          <button type="button" class="btn-outline-white" onclick="switchAuthMode('signin')">Sign in</button>
        </div>

        <div class="panel-orange-quote">
          &ldquo;The journey, not the destination, matters.&rdquo;
        </div>
      </div>

      <!-- Right Column: Dark Register Form -->
      <div class="panel-side panel-dark">
        <div class="panel-dark-header">
          <h1>Join the crew</h1>
          <p>Register an operator account for your rental desk</p>
        </div>

        <?php if ($error && $activeMode === 'signup'): ?>
          <div class="alert-banner alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <span><?= htmlspecialchars($error) ?></span>
          </div>
        <?php endif; ?>

        <form method="POST" action="index.php">
          <input type="hidden" name="action" value="register">

          <div class="form-group">
            <label class="form-label">Full name</label>
            <div class="input-wrapper">
              <i class="far fa-user input-icon-left"></i>
              <input type="text" name="fullname" class="auth-input" placeholder="Dominic Reyes" value="<?= htmlspecialchars($_POST['fullname'] ?? '') ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Email</label>
            <div class="input-wrapper">
              <i class="far fa-envelope input-icon-left"></i>
              <input type="email" name="email" class="auth-input" placeholder="you@veloce.rent" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrapper">
              <i class="fas fa-lock input-icon-left"></i>
              <input type="password" name="password" id="regPassword" class="auth-input" placeholder="6+ characters" required>
              <i class="far fa-eye input-icon-right" onclick="togglePasswordVisibility('regPassword', this)"></i>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Confirm password</label>
            <div class="input-wrapper">
              <i class="fas fa-shield-alt input-icon-left"></i>
              <input type="password" name="confirm_password" id="regConfirmPassword" class="auth-input" placeholder="Repeat your password" required>
              <i class="far fa-eye input-icon-right" onclick="togglePasswordVisibility('regConfirmPassword', this)"></i>
            </div>
          </div>

          <button type="submit" class="btn-primary-orange" style="margin-top:8px;">Create account</button>

          <div class="auth-switch">
            Already registered? <a href="javascript:void(0)" onclick="switchAuthMode('signin')">Sign in</a>
          </div>
        </form>
      </div>
    </div>

  </div>

  <script>
    function switchAuthMode(mode) {
      const signInView = document.getElementById('viewSignIn');
      const signUpView = document.getElementById('viewSignUp');
      
      if (mode === 'signup') {
        signInView.classList.add('hidden');
        signUpView.classList.remove('hidden');
      } else {
        signUpView.classList.add('hidden');
        signInView.classList.remove('hidden');
      }
    }

    function togglePasswordVisibility(inputId, iconEl) {
      const input = document.getElementById(inputId);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        iconEl.classList.remove('fa-eye');
        iconEl.classList.add('fa-eye-slash');
      } else {
        input.type = 'password';
        iconEl.classList.remove('fa-eye-slash');
        iconEl.classList.add('fa-eye');
      }
    }

    function quickFillDemo(provider) {
      const emailInput = document.querySelector('input[name="email_or_username"]');
      const pwdInput = document.getElementById('signinPassword');
      if (emailInput && pwdInput) {
        emailInput.value = 'manager@veloce.rent';
        pwdInput.value = 'admin123';
      }
    }
  </script>
</body>
</html>