/* ==========================================================================
   DriveIQ Admin Portal - Application Controller & Event Handler
   ========================================================================== */

class AppController {
  constructor() {
    this.currentTab = 'dashboard';
    this.fleetViewMode = 'grid'; // grid or table
    this.gpsAnimFrame = null;
    this.mapVehicles = [];
    this.editingVehicleId = null;
    this.editingChauffeurId = null;
    this.paymentsFilter = 'All';
    this.paymentsSearch = '';
  }

  async init() {
    this.bindEvents();
    const urlParams = new URLSearchParams(window.location.search);
    const initialTab = urlParams.get('tab') || sessionStorage.getItem('activeTab') || 'dashboard';
    this.switchTab(initialTab);

    try {
      await store.ready;
      this.updateLiveBadges();
      if (this.currentTab === 'payments') {
        components.renderPayments(this.paymentsFilter, this.paymentsSearch);
      }
    } catch (e) {
      console.error("Store init warning:", e);
    }
    this.setupTheme();
  }

  bindEvents() {
    // Sidebar toggle
    const toggleBtn = document.getElementById('sidebarToggleBtn');
    const sidebar = document.getElementById('sidebar');
    if (toggleBtn && sidebar) {
      toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
      });
    }

    // Delegated click handling for filters, modals and actions
    document.addEventListener('click', (e) => {
      // 1. Filter pill click
      const pill = e.target.closest('.filter-pill');
      if (pill) {
        const text = pill.textContent.trim();
        this.filterPayments(text);
        return;
      }

      // 2. Record payment button
      const recordBtn = e.target.closest('.btn-record-payment');
      if (recordBtn) {
        this.openRecordPaymentModal();
        return;
      }

      // 3. Receipt / view action
      const viewBtn = e.target.closest('.icon-action-btn[title*="Receipt"], .invoice-link');
      if (viewBtn) {
        const row = viewBtn.closest('tr.payment-row');
        const invNo = viewBtn.getAttribute('data-invoice') || 
                      viewBtn.textContent.trim().match(/INV-[A-Za-z0-9]+/)?.[0] || 
                      row?.querySelector('.invoice-link')?.textContent.trim();
        if (invNo) {
          this.viewInvoice(invNo);
          return;
        }
      }

      // 4. Cycle status action
      const syncBtn = e.target.closest('.icon-action-btn[title*="Cycle"]');
      if (syncBtn) {
        const row = syncBtn.closest('tr.payment-row');
        const invNo = syncBtn.getAttribute('data-invoice') || 
                      row?.querySelector('.invoice-link')?.textContent.trim();
        const currentStatus = syncBtn.getAttribute('data-status') || 
                              row?.getAttribute('data-status') || 'Paid';
        if (invNo) {
          this.cycleInvoiceStatus(invNo, currentStatus);
          return;
        }
      }

      // 5. Delete invoice action
      const delBtn = e.target.closest('.icon-action-btn.delete, .icon-action-btn[title*="Delete"]');
      if (delBtn) {
        const row = delBtn.closest('tr.payment-row');
        const invNo = delBtn.getAttribute('data-invoice') || 
                      row?.querySelector('.invoice-link')?.textContent.trim();
        if (invNo) {
          this.deleteInvoicePrompt(invNo);
          return;
        }
      }

      // 6. Close modal on backdrop click
      if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
      }

      // 7. Close modal on .modal-close-btn click
      const closeBtn = e.target.closest('.modal-close-btn');
      if (closeBtn) {
        const modal = closeBtn.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
      }
    });
  }

  updateLiveBadges() {
    const m = store.getMetrics();
    const ps = store.getPaymentsSummary();
    const fleet = document.getElementById('fleetBadge');
    const reservations = document.getElementById('reservationsBadge');
    const cart = document.getElementById('cartBadge');
    const payments = document.getElementById('paymentsBadge');
    const maintenance = document.getElementById('maintenanceBadge');
    const chauffeurs = document.getElementById('chauffeurBadge');

    if (fleet) fleet.textContent = m.totalVehicles ?? store.getVehicles().length;
    if (reservations) reservations.textContent = m.totalBookings ?? store.getBookings().length;
    if (cart) cart.textContent = m.cartItems ?? 0;
    if (payments) {
      const invList = store.getInvoices();
      const count = (invList && invList.length > 0)
        ? invList.length
        : (ps.countAll ?? (document.querySelectorAll('#paymentsTableBody tr.payment-row').length || 3));
      payments.textContent = count;
    }
    if (maintenance) maintenance.textContent = m.maintenanceAlerts ?? 2;
    if (chauffeurs) chauffeurs.textContent = store.getDrivers().filter(d => d.active !== false).length;
  }

  // --- Tab Navigation & Routing ---
  switchTab(tabId) {
    this.currentTab = tabId;
    try { sessionStorage.setItem('activeTab', tabId); } catch(e){}

    // Update active state in sidebar
    document.querySelectorAll('.nav-item').forEach(item => {
      if (item.getAttribute('data-tab') === tabId) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Toggle view containers
    document.querySelectorAll('.page-view').forEach(view => {
      view.classList.remove('active');
    });

    const targetView = document.getElementById(`view-${tabId}`);
    if (targetView) {
      targetView.classList.add('active');
    }

    // Render corresponding view
    switch (tabId) {
      case 'dashboard':
        components.renderDashboard();
        break;
      case 'fleet':
        components.renderFleet();
        break;
      case 'bookings':
        components.renderBookings();
        break;
      case 'customers':
        components.renderCustomers();
        break;
      case 'chat':
        this.renderChat();
        break;
      case 'carts':
        components.renderCarts();
        break;
      case 'drivers':
        components.renderDrivers();
        break;
      case 'gps':
        components.renderGPS();
        break;
      case 'maintenance':
        components.renderMaintenance();
        break;
      case 'payments':
        components.renderPayments(this.paymentsFilter, this.paymentsSearch);
        break;
      case 'financials':
        components.renderFinancials();
        break;
      case 'settings':
        components.renderSettings();
        break;
      default:
        components.renderDashboard();
    }
  }

  // --- Fleet Filtering & View Modes ---
  filterFleet() {
    const searchVal = document.getElementById('fleetSearchInput')?.value || '';
    const catVal = document.getElementById('fleetCategorySelect')?.value || 'All';
    components.renderFleet(catVal, searchVal);
  }

  toggleFleetViewMode(mode) {
    this.fleetViewMode = mode;
    this.showToast(`Switched fleet view to ${mode.toUpperCase()}`);
    this.filterFleet();
  }

  // --- Modals Controller ---
  openModal(modalId) {
    if (modalId === 'modal-add-maintenance') {
      this.populateMaintenanceVehicles();
    }
    if (modalId === 'modal-add-chauffeur') {
      if (!this.editingChauffeurId) this.resetChauffeurModal();
      this.populateChauffeurVehicles();
    }
    if (modalId === 'modal-add-vehicle' && !this.editingVehicleId) {
      const modal0 = document.getElementById(modalId);
      const title0 = modal0?.querySelector('.modal-header h2'); const submit0 = modal0?.querySelector('button[type="submit"]');
      if(title0) title0.innerHTML='<i class="fas fa-car" style="color:var(--accent-primary);"></i> Add Vehicle to Fleet';
      if(submit0) submit0.innerHTML='<i class="fas fa-plus-circle"></i> Add Vehicle';
    }
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
    }
  }

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
    }
  }

  populateMaintenanceVehicles() {
    const select = document.getElementById('mntVehicleSelect');
    if (!select) return;
    const vehicles = store.getVehicles().filter(v => v.active !== false);
    if (!vehicles.length && store.ready) {
      select.innerHTML = '<option value="">Loading vehicles...</option>';
      store.ready.then(() => this.populateMaintenanceVehicles()).catch(() => {});
      return;
    }
    const maintenanceStates = ['maintenance','service','repair','under maintenance','under service','in service','servicing','under repair'];
    if (!vehicles.length) {
      select.innerHTML = '<option value="">No vehicles found</option>';
      return;
    }
    select.innerHTML = vehicles.map(v => {
      const st = String(v.status || 'Available').trim();
      const isMaintenance = maintenanceStates.includes(st.toLowerCase());
      const label = `${v.name || 'Vehicle'}${v.id ? ` (${v.id})` : ''} — ${st}`;
      return `<option value="${String(v.id || '').replace(/"/g, '&quot;')}" ${isMaintenance ? 'disabled' : ''}>${label}</option>`;
    }).join('');
    const firstAvailable = [...select.options].find(o => !o.disabled);
    if (firstAvailable) select.value = firstAvailable.value;
  }

  // --- Vehicle CRUD Callbacks ---
  async handleAddVehicle(e) {
    e.preventDefault();
    const name = document.getElementById('vehName').value.trim();
    const brand = document.getElementById('vehBrand').value.trim();
    const category = document.getElementById('vehCategory').value;
    const plate = document.getElementById('vehPlate').value.trim();
    const location = document.getElementById('vehLocation')?.value || 'Matara';
    const serviceType = document.getElementById('vehServiceType')?.value || 'Both';
    const rate = Number(document.getElementById('vehRate').value);
    const fuel = document.getElementById('vehFuel').value;
    const seats = Number(document.getElementById('vehSeats').value);
    const transmission = document.getElementById('vehTransmission').value;
    const image = document.getElementById('vehImage').value || 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=600';

    const current = this.editingVehicleId
      ? store.getVehicles().find(v => v.id === this.editingVehicleId)
      : null;

    try {
      if (current) {
        await store.updateVehicle(this.editingVehicleId, {
          name, brand, category, plate, location, service_type: serviceType, rate, fuel, seats, transmission, image,
          price_usd: rate, status: current.status || 'Available', active: current.active !== false
        });
        this.showToast(`Vehicle "${name}" updated successfully!`, 'success');
      } else {
        await store.addVehicle({
          name, brand, category, plate, location, service_type: serviceType, rate,
          hourlyRate: Math.round(rate / 8), status: 'Available',
          fuel, seats, transmission, year: new Date().getFullYear(),
          mileage: '0 km', image, location: 'Matara',
          service_type: 'Both', active: true,
          features: ['GPS', 'Airbags', 'Bluetooth']
        });
        this.showToast(`Vehicle "${name}" added successfully!`, 'success');
      }
      this.editingVehicleId = null;
      this.closeModal('modal-add-vehicle');
      this.switchTab('fleet');
    } catch (err) {
      this.showToast(err.message || 'Database operation failed', 'error');
    }
  }

  editVehicleModal(id) {
    const v = store.getVehicles().find(x => x.id === id);
    if (!v) return;
    this.editingVehicleId = id;
    document.getElementById('vehName').value = v.name || '';
    document.getElementById('vehBrand').value = v.brand || '';
    document.getElementById('vehCategory').value = v.category || 'Sedan';
    document.getElementById('vehPlate').value = v.plate || '';
    if (document.getElementById('vehLocation')) document.getElementById('vehLocation').value = v.location || 'Matara';
    if (document.getElementById('vehServiceType')) document.getElementById('vehServiceType').value = v.service_type || v.serviceType || 'Both';
    document.getElementById('vehRate').value = v.rate || 0;
    document.getElementById('vehFuel').value = v.fuel || 'Petrol';
    document.getElementById('vehSeats').value = v.seats || 4;
    document.getElementById('vehTransmission').value = v.transmission || 'Automatic';
    document.getElementById('vehImage').value = v.image || '';
    const modal = document.getElementById('modal-add-vehicle');
    const title = modal?.querySelector('.modal-header h2');
    const submit = modal?.querySelector('button[type="submit"]');
    if (title) title.innerHTML = '<i class="fas fa-car" style="color:var(--accent-primary);"></i> Edit Vehicle';
    if (submit) submit.innerHTML = '<i class="fas fa-save"></i> Save Changes';
    this.openModal('modal-add-vehicle');
  }

  async deleteVehicle(id) {
    if (confirm('Are you sure you want to delete this vehicle from the fleet?')) {
      await store.deleteVehicle(id);
      this.showToast('Vehicle deleted from fleet', 'warning');
      this.filterFleet();
    }
  }

  // --- Chauffeur Roster Operations ---
  populateChauffeurVehicles() {
    const select = document.getElementById('chauffeurVehicleSelect');
    if (!select) return;
    const vehicles = store.getVehicles().filter(v => v.active !== false);
    const maintenanceStates = ['maintenance','service','repair','under maintenance','under service','in service','servicing','under repair'];
    const currentValue = select.value || '';
    select.innerHTML = `<option value="">Unassigned</option>` + vehicles.map(v => {
      const blocked = maintenanceStates.includes(String(v.status || '').toLowerCase());
      return `<option value="${String(v.id || '').replace(/"/g,'&quot;')}" ${blocked?'disabled':''}>${String(v.name || 'Vehicle').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))} (${String(v.id || '')})${blocked?' — Maintenance':''}</option>`;
    }).join('');
    if (currentValue && [...select.options].some(o => o.value === currentValue && !o.disabled)) select.value = currentValue;
  }

  filterChauffeurs() {
    const q = document.getElementById('chauffeurSearchInput')?.value || '';
    const st = document.getElementById('chauffeurStatusSelect')?.value || 'All';
    components.renderDrivers(st, q);
  }

  refreshChauffeurs() {
    store.refresh().then(() => {
      components.renderDrivers(document.getElementById('chauffeurStatusSelect')?.value || 'All', document.getElementById('chauffeurSearchInput')?.value || '');
      this.showToast('Chauffeur roster refreshed.', 'success');
    }).catch(e => this.showToast(e.message || 'Could not refresh roster.', 'error'));
  }

  handleSaveChauffeur(e) {
    e.preventDefault();
    const editingId = document.getElementById('chauffeurDbId')?.value || '';
    const vehicleId = document.getElementById('chauffeurVehicleSelect')?.value || '';
    const vehicle = store.getVehicles().find(v => String(v.id) === String(vehicleId));
    const data = {
      db_id: editingId ? Number(editingId) : undefined,
      driver_code: document.getElementById('chauffeurCode').value.trim(),
      name: document.getElementById('chauffeurName').value.trim(),
      phone: document.getElementById('chauffeurPhone').value.trim(),
      email: document.getElementById('chauffeurEmail').value.trim(),
      nic: document.getElementById('chauffeurNic').value.trim(),
      license_no: document.getElementById('chauffeurLicense').value.trim(),
      license_expiry: document.getElementById('chauffeurLicenseExpiry').value,
      address: document.getElementById('chauffeurAddress').value.trim(),
      emergency_contact: document.getElementById('chauffeurEmergency').value.trim(),
      status: document.getElementById('chauffeurStatus').value,
      shift_start: document.getElementById('chauffeurShiftStart').value,
      shift_end: document.getElementById('chauffeurShiftEnd').value,
      work_days: document.getElementById('chauffeurWorkDays').value.trim(),
      next_shift: document.getElementById('chauffeurNextShift').value,
      assigned_vehicle_id: vehicleId,
      assigned_vehicle_name: vehicle ? vehicle.name : '',
      daily_rate: Number(document.getElementById('chauffeurRate').value || 0),
      trips_completed: Number(document.getElementById('chauffeurTrips').value || 0),
      rating: Number(document.getElementById('chauffeurRating').value || 0),
      notes: document.getElementById('chauffeurNotes').value.trim(),
      active: document.getElementById('chauffeurActive').checked
    };
    if (!data.name) { this.showToast('Chauffeur name is required.', 'error'); return; }
    const op = editingId ? store.updateChauffeur(data) : store.addChauffeur(data);
    op.then(() => {
      this.closeModal('modal-add-chauffeur');
      this.editingChauffeurId = null;
      this.resetChauffeurModal();
      components.renderDrivers();
      this.showToast(editingId ? 'Chauffeur profile updated successfully.' : 'Chauffeur added to roster successfully.', 'success');
    }).catch(err => this.showToast(err.message || 'Could not save chauffeur profile.', 'error'));
  }

  editChauffeurModal(id) {
    const d = store.getDrivers().find(x => x.id === id);
    if (!d) return;
    this.editingChauffeurId = d.db_id || id;
    const set = (id, value) => { const el=document.getElementById(id); if(el) el.value=value ?? ''; };
    set('chauffeurDbId', d.db_id || ''); set('chauffeurCode', d.id || ''); set('chauffeurName', d.name || ''); set('chauffeurPhone', d.phone || '');
    set('chauffeurEmail', d.email || ''); set('chauffeurNic', d.nic || ''); set('chauffeurLicense', d.license_no || ''); set('chauffeurLicenseExpiry', d.license_expiry || '');
    set('chauffeurAddress', d.address || ''); set('chauffeurEmergency', d.emergency_contact || ''); set('chauffeurStatus', d.status || 'Available'); set('chauffeurShiftStart', d.shiftStart || '');
    set('chauffeurShiftEnd', d.shiftEnd || ''); set('chauffeurWorkDays', d.work_days || 'Mon,Tue,Wed,Thu,Fri,Sat'); set('chauffeurNextShift', d.next_shift || '');
    set('chauffeurVehicleSelect', d.assigned_vehicle_id || ''); set('chauffeurRate', d.dailyRate || 0); set('chauffeurTrips', d.tripsCompleted || 0); set('chauffeurRating', d.rating || 0); set('chauffeurNotes', d.notes || '');
    const active=document.getElementById('chauffeurActive'); if(active) active.checked=d.active!==false;
    const title=document.querySelector('#modal-add-chauffeur .modal-header h2'); const submit=document.querySelector('#modal-add-chauffeur button[type="submit"]');
    if(title) title.innerHTML='<i class="fas fa-user-edit" style="color:var(--accent-cyan);"></i> Edit Chauffeur Profile';
    if(submit) submit.innerHTML='<i class="fas fa-save"></i> Save Changes';
    this.openModal('modal-add-chauffeur');
  }

  resetChauffeurModal() {
    this.editingChauffeurId = null;
    const form=document.getElementById('chauffeurForm'); if(form) form.reset();
    const db=document.getElementById('chauffeurDbId'); if(db) db.value='';
    const active=document.getElementById('chauffeurActive'); if(active) active.checked=true;
    const title=document.querySelector('#modal-add-chauffeur .modal-header h2'); const submit=document.querySelector('#modal-add-chauffeur button[type="submit"]');
    if(title) title.innerHTML='<i class="fas fa-user-tie" style="color:var(--accent-cyan);"></i> Add Chauffeur Profile';
    if(submit) submit.innerHTML='<i class="fas fa-user-plus"></i> Add Chauffeur';
  }

  async changeChauffeurStatus(id, status, dbId) {
    try { await store.updateChauffeurStatus(id,status,dbId); components.renderDrivers(); this.showToast(`${id} status changed to ${status}.`,'success'); }
    catch(e) { this.showToast(e.message || 'Could not update chauffeur status.','error'); }
  }

  async deleteChauffeur(id, dbId) {
    if (!confirm(`Deactivate chauffeur ${id}? The profile and history will be kept.`)) return;
    try { await store.deleteChauffeur(id,dbId); components.renderDrivers(); this.showToast(`${id} deactivated.`, 'warning'); }
    catch(e) { this.showToast(e.message || 'Could not deactivate chauffeur.','error'); }
  }

  async restoreChauffeur(id, dbId) {
    try { await store.restoreChauffeur(id,dbId); components.renderDrivers(); this.showToast(`${id} restored to Available.`, 'success'); }
    catch(e) { this.showToast(e.message || 'Could not restore chauffeur.','error'); }
  }

  // --- Booking Operations ---
  handleAddBooking(e) {
    e.preventDefault();
    const customerName = document.getElementById('bookCustomerName').value;
    const customerPhone = document.getElementById('bookCustomerPhone').value;
    const vehicleId = document.getElementById('bookVehicleSelect').value;
    const pickupDate = document.getElementById('bookPickupDate').value;
    const returnDate = document.getElementById('bookReturnDate').value;
    const pickupLocation = document.getElementById('bookPickupLoc').value;
    const returnLocation = document.getElementById('bookReturnLoc').value;

    const vehicle = store.getVehicles().find(v => v.id === vehicleId);
    if (!vehicle) return;

    const start = new Date(pickupDate);
    const end = new Date(returnDate);
    const days = Math.max(1, Math.ceil((end - start) / (1000 * 60 * 60 * 24)));
    const totalAmount = days * vehicle.rate;

    store.addBooking({
      customerName,
      customerEmail: `${customerName.toLowerCase().replace(/\s+/g, '.')}@email.com`,
      customerPhone,
      vehicleId,
      vehicleName: vehicle.name,
      pickupDate,
      returnDate,
      pickupLocation,
      returnLocation,
      driverRequested: false,
      driverName: 'Self Drive',
      dailyRate: vehicle.rate,
      days,
      totalAmount,
      depositPaid: 0,
      paymentStatus: 'Unpaid',
      status: 'Pending'
    });

    // Update vehicle status to Reserved
    store.updateVehicle(vehicleId, { status: 'Reserved' });

    this.closeModal('modal-add-booking');
    this.showToast(`Booking generated for ${customerName}!`, 'success');
    this.switchTab('bookings');
  }

  async processVehicleReturn(bookingRef) {
    const booking = store.getBookings().find(b => String(b.id) === String(bookingRef));
    if (!booking) { this.showToast('Booking not found. Refresh and try again.', 'error'); return; }
    const existing = (store.getReturns && store.getReturns()[bookingRef]) || {};
    const old = document.getElementById('vehicleReturnModal');
    if (old) old.remove();
    const esc = v => this.escapeHtml(v ?? '');
    const modal = document.createElement('div');
    modal.id = 'vehicleReturnModal';
    modal.className = 'modal-overlay active';
    modal.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(0,0,0,.72);overflow:auto;';
    modal.innerHTML = `
      <div style="width:min(720px,100%);max-height:92vh;overflow:auto;background:var(--card-bg,#111827);color:var(--text-primary,#f8fafc);border:1px solid var(--border-color,#374151);border-radius:18px;padding:24px;box-shadow:0 25px 70px rgba(0,0,0,.45)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:18px">
          <div><h2 style="margin:0 0 6px">Vehicle Return Inspection</h2><p style="margin:0;color:var(--text-dim,#9ca3af)">Booking ${esc(booking.id)} · ${esc(booking.vehicleName)} · ${esc(booking.customerName)}</p></div>
          <button type="button" id="closeVehicleReturn" class="secondary-btn">Close</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">
          <label>Vehicle condition<select name="condition_status" form="vehicleReturnForm" class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px"><option ${existing.condition_status==='Good'?'selected':''}>Good</option><option ${existing.condition_status==='Minor Damage'?'selected':''}>Minor Damage</option><option ${existing.condition_status==='Major Damage'?'selected':''}>Major Damage</option><option ${existing.condition_status==='Needs Cleaning'?'selected':''}>Needs Cleaning</option></select></label>
          <label>Fuel level<select name="fuel_level" form="vehicleReturnForm" class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px"><option value="">Select fuel level</option>${['Empty','1/4','1/2','3/4','Full'].map(x=>`<option ${existing.fuel_level===x?'selected':''}>${x}</option>`).join('')}</select></label>
          <label>Odometer (km)<input name="odometer_km" form="vehicleReturnForm" type="number" min="0" value="${esc(existing.odometer_km)}" class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px"></label>
          <label>Extra charges<input name="extra_charges" form="vehicleReturnForm" type="number" min="0" step="0.01" value="${esc(existing.extra_charges ?? '0.00')}" class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px"></label>
          <label>Payment status<select name="payment_status" form="vehicleReturnForm" class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px"><option value="PAID" ${existing.payment_status==='PAID'?'selected':''}>Paid in full</option><option value="PARTIAL" ${existing.payment_status==='PARTIAL'?'selected':''}>Partially paid</option><option value="UNPAID" ${!existing.payment_status||existing.payment_status==='UNPAID'?'selected':''}>Unpaid / balance due</option></select></label>
          <label>Payment notes<input name="payment_notes" form="vehicleReturnForm" value="${esc(existing.payment_notes)}" placeholder="Receipt no., balance due, payment method..." class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px"></label>
          <label style="grid-column:1/-1">Damage / inspection notes<textarea name="damage_notes" form="vehicleReturnForm" rows="4" placeholder="Record scratches, dents, missing items, photos taken, or write No damage found" class="form-control" style="width:100%;margin-top:6px;padding:11px;border-radius:8px;resize:vertical">${esc(existing.damage_notes)}</textarea></label>
        </div>
        <form id="vehicleReturnForm" style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px"><input type="hidden" name="booking_ref" value="${esc(booking.id)}"><button type="button" id="cancelVehicleReturn" class="secondary-btn">Cancel</button><button type="submit" class="primary-btn"><i class="fas fa-clipboard-check"></i> Save Return & Complete Booking</button></form>
        <p style="font-size:12px;color:var(--text-dim,#9ca3af);margin:14px 0 0">Saving this inspection marks the booking as Completed and makes the vehicle Available if it has no other active booking. Confirm payment status from the actual payment record.</p>
      </div>`;
    document.body.appendChild(modal);
    const close = () => modal.remove();
    modal.querySelector('#closeVehicleReturn').onclick = close;
    modal.querySelector('#cancelVehicleReturn').onclick = close;
    modal.addEventListener('click', e => { if (e.target === modal) close(); });
    modal.querySelector('#vehicleReturnForm').addEventListener('submit', async e => {
      e.preventDefault();
      const form = e.currentTarget;
      const data = Object.fromEntries(new FormData(form).entries());
      const submit = form.querySelector('button[type="submit"]');
      submit.disabled = true; submit.textContent = 'Saving...';
      try {
        const response = await fetch('api.php?action=vehicle_return', {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.message || 'Could not save vehicle return.');
        await store.load();
        close();
        this.showToast('Return inspection saved. Booking marked Completed.', 'success');
        components.renderBookings(); components.renderDashboard(); this.updateLiveBadges();
      } catch (err) {
        this.showToast(err.message || 'Could not save return inspection.', 'error');
        submit.disabled = false; submit.innerHTML = '<i class="fas fa-clipboard-check"></i> Save Return & Complete Booking';
      }
    });
  }

  async changeBookingStatus(id, newStatus) {
    await store.updateBookingStatus(id, newStatus);
    this.updateLiveBadges();
    this.showToast(`Booking ${id} status updated to ${newStatus}`, 'success');
    components.renderBookings();
    components.renderDashboard();
  }

  // --- Invoice Modal ---
  viewInvoice(bookingId) {
    const booking = store.getBookings().find(b => b.id === bookingId);
    if (!booking) return;

    const body = document.getElementById('invoiceModalBody');
    body.innerHTML = `
      <div class="invoice-box">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <h2 style="color:var(--accent-primary);">DriveIQ Luxury Rentals</h2>
            <p style="font-size:12px; color:#555;">Colombo 03 Hub, Sri Lanka &bull; +94 11 234 5678</p>
          </div>
          <div style="text-align:right;">
            <h3>INVOICE</h3>
            <p style="font-size:12px; color:#555;">Ref: <strong>${booking.id}</strong></p>
            <p style="font-size:12px; color:#555;">Date: ${new Date().toLocaleDateString()}</p>
          </div>
        </div>

        <hr style="margin:20px 0; border:none; border-top:1px solid #eee;">

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; font-size:14px;">
          <div>
            <strong>Billed To:</strong>
            <div>${booking.customerName}</div>
            <div>${booking.customerPhone}</div>
            <div>${booking.customerEmail}</div>
          </div>
          <div>
            <strong>Rental Details:</strong>
            <div>Vehicle: ${booking.vehicleName}</div>
            <div>Period: ${booking.pickupDate} to ${booking.returnDate}</div>
            <div>Driver: ${booking.driverName}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr style="background:#f4f4f4;">
              <th>Description</th>
              <th>Rate / Day</th>
              <th>Days</th>
              <th>Amount ($)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Vehicle Rental Fee (${booking.vehicleName})</td>
              <td>$${booking.dailyRate}</td>
              <td>${booking.days}</td>
              <td>$${booking.dailyRate * booking.days}</td>
            </tr>
            ${booking.driverRequested ? `
              <tr>
                <td>Chauffeur Service Fee</td>
                <td>$25</td>
                <td>${booking.days}</td>
                <td>$${25 * booking.days}</td>
              </tr>
            ` : ''}
          </tbody>
        </table>

        <div style="text-align:right; margin-top:20px;">
          <h4>Total Amount: <span style="color:var(--accent-emerald); font-size:22px;">$${booking.totalAmount}</span></h4>
          <p style="font-size:12px; color:#666;">Payment Status: <strong>${booking.paymentStatus}</strong></p>
        </div>

        <div style="margin-top:30px; text-align:center;">
          <button class="primary-btn" onclick="window.print()"><i class="fas fa-print"></i> Print Invoice</button>
        </div>
      </div>
    `;

    this.openModal('modal-view-invoice');
  }

  // --- Maintenance Operations ---
  async handleAddMaintenance(e) {
    e.preventDefault();
    const vehicleId = document.getElementById('mntVehicleSelect').value;
    const issue = document.getElementById('mntIssue').value.trim();
    const cost = Number(document.getElementById('mntCost').value || 0);
    const serviceCenter = document.getElementById('mntCenter').value.trim();

    const vehicle = store.getVehicles().find(v => String(v.id) === String(vehicleId));
    if (!vehicle) {
      this.showToast('Please select a vehicle.', 'error');
      return;
    }

    try {
      await store.addMaintenance({
        vehicleId: vehicle.id,
        vehicleName: vehicle.name,
        issue,
        cost,
        serviceCenter,
        startDate: new Date().toISOString().split('T')[0],
        estimatedReturn: 'In 3 Days',
        status: 'In Progress'
      });

      document.getElementById('mntIssue').value = '';
      document.getElementById('mntCost').value = '';
      this.closeModal('modal-add-maintenance');
      this.updateLiveBadges();
      this.showToast(`Maintenance entry created for ${vehicle.name}`, 'warning');
      this.switchTab('maintenance');
      components.renderDashboard();
    } catch (err) {
      this.showToast(err.message || 'Could not create maintenance ticket.', 'error');
    }
  }

  async completeMaintenance(id) {
    try {
      await store.updateMaintenanceStatus(id, 'Completed');
      this.updateLiveBadges();
      this.showToast('Maintenance completed. Vehicle is available again.', 'success');
      this.switchTab('maintenance');
    } catch (err) {
      this.showToast(err.message || 'Could not update maintenance ticket.', 'error');
    }
  }

  async deleteMaintenance(id) {
    if (!confirm('Delete this maintenance ticket? The vehicle will be released if no other active maintenance ticket exists.')) return;
    try {
      await store.deleteMaintenance(id);
      this.updateLiveBadges();
      this.showToast('Maintenance ticket deleted.', 'warning');
      this.switchTab('maintenance');
    } catch (err) {
      this.showToast(err.message || 'Could not delete maintenance ticket.', 'error');
    }
  }

  // --- Live GPS map ---
  async initRealGPSMap() {
    const mapEl = document.getElementById('liveGpsMap');
    if (!mapEl || typeof L === 'undefined') return;

    if (this.gpsMap) {
      this.gpsMap.remove();
      this.gpsMap = null;
    }

    this.gpsMap = L.map(mapEl, { zoomControl: true }).setView([6.9271, 79.8612], 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(this.gpsMap);

    this.gpsMarkers = {};
    await this.refreshRealGPSMap();

    if (this.gpsRefreshTimer) clearInterval(this.gpsRefreshTimer);
    this.gpsRefreshTimer = setInterval(() => this.refreshRealGPSMap(), 10000);
  }

  async refreshRealGPSMap() {
    if (!this.gpsMap) return;
    try {
      const res = await fetch('api.php?action=gps_locations&_=' + Date.now(), {
        credentials: 'same-origin', cache: 'no-store'
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message || 'GPS request failed');

      const locations = data.locations || [];
      const list = document.getElementById('gpsVehicleList');
      const refresh = document.getElementById('gpsLastRefresh');
      if (refresh) refresh.textContent = 'Updated ' + new Date().toLocaleTimeString();

      const seen = {};
      locations.forEach((v) => {
        const key = v.booking_ref;
        seen[key] = true;
        const latlng = [Number(v.latitude), Number(v.longitude)];
        const staleMs = Date.now() - new Date(v.updated_at.replace(' ', 'T')).getTime();
        const stale = !Number.isFinite(staleMs) || staleMs > 90000;

        const popup = `
          <div style="min-width:210px">
            <strong>${this.escapeHtml(v.vehicle_name || 'Vehicle')}</strong><br>
            Booking: ${this.escapeHtml(v.booking_ref)}<br>
            Customer: ${this.escapeHtml(v.customer_name || 'Customer')}<br>
            ${v.speed !== null ? 'Speed: ' + Number(v.speed).toFixed(1) + ' km/h<br>' : ''}
            ${v.accuracy !== null ? 'Accuracy: ±' + Number(v.accuracy).toFixed(0) + ' m<br>' : ''}
            <small>GPS update: ${this.escapeHtml(v.updated_at)}</small>
          </div>`;

        if (!this.gpsMarkers[key]) {
          this.gpsMarkers[key] = L.marker(latlng).addTo(this.gpsMap);
        } else {
          this.gpsMarkers[key].setLatLng(latlng);
        }
        this.gpsMarkers[key].bindPopup(popup);
        this.gpsMarkers[key].setOpacity(stale ? 0.45 : 1);
      });

      Object.keys(this.gpsMarkers).forEach(key => {
        if (!seen[key]) {
          this.gpsMap.removeLayer(this.gpsMarkers[key]);
          delete this.gpsMarkers[key];
        }
      });

      if (list) {
        list.innerHTML = `<h3 style="margin-bottom:14px;font-size:16px;">Picked-up Vehicles <span style="color:var(--accent-cyan);">(${locations.length})</span></h3>` +
          (locations.length ? locations.map(v => {
            const staleMs = Date.now() - new Date(v.updated_at.replace(' ', 'T')).getTime();
            const stale = !Number.isFinite(staleMs) || staleMs > 90000;
            return `
              <div class="tracker-item ${stale ? '' : 'active'}" onclick="app.focusRealGPS('${this.escapeHtml(v.booking_ref)}')">
                <div class="tracker-item-head">
                  <strong>${this.escapeHtml(v.vehicle_name || 'Vehicle')}</strong>
                  <span class="tracker-speed">${stale ? 'Offline' : 'Live'}</span>
                </div>
                <p style="font-size:12px;color:var(--text-dim);">${this.escapeHtml(v.plate || v.vehicle_id || '')} &bull; ${this.escapeHtml(v.customer_name || '')}</p>
                <div style="font-size:11px;color:${stale ? 'var(--text-dim)' : 'var(--accent-emerald)'};margin-top:4px;">
                  <i class="fas ${stale ? 'fa-clock' : 'fa-signal'}"></i>
                  ${stale ? 'Last signal ' + this.escapeHtml(v.updated_at) : 'GPS signal strong'}
                </div>
              </div>`;
          }).join('') : `<div style="padding:30px 10px;text-align:center;color:var(--text-dim);">
              <i class="fas fa-car-side" style="font-size:30px;opacity:.35;"></i>
              <p style="margin-top:10px;">No vehicle is currently sending a live GPS signal.</p>
            </div>`);
      }

      const points = locations.map(v => [Number(v.latitude), Number(v.longitude)]);
      if (points.length && !this.gpsMapUserMoved) {
        this.gpsMap.fitBounds(points, { padding: [30, 30], maxZoom: 14 });
      }
    } catch (e) {
      console.error('GPS map error:', e);
      const refresh = document.getElementById('gpsLastRefresh');
      if (refresh) refresh.textContent = 'GPS connection error';
    }
  }

  focusRealGPS(bookingRef) {
    const marker = this.gpsMarkers && this.gpsMarkers[bookingRef];
    if (marker) {
      this.gpsMap.setView(marker.getLatLng(), 16, { animate: true });
      marker.openPopup();
      this.gpsMapUserMoved = true;
    }
  }

  escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
    }[c]));
  }

  async deleteBooking(id) {
    if (!confirm('Are you sure you want to remove this booking? The vehicle will become available again.')) return;
    try {
      await store.deleteBooking(id);
      this.showToast('Booking removed. Vehicle is available again.', 'success');
      components.renderBookings();
      components.renderDashboard();
    } catch (e) {
      console.error(e);
      this.showToast(e.message || 'Could not remove booking.', 'error');
    }
  }

  // --- Export Financial CSV ---
  exportFinancialReport() {
    const bookings = store.getBookings();
    let csv = "BookingID,Customer,Vehicle,PickupDate,ReturnDate,Amount,Status\n";
    bookings.forEach(b => {
      csv += `"${b.id}","${b.customerName}","${b.vehicleName}","${b.pickupDate}","${b.returnDate}",${b.totalAmount},"${b.status}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('download', `DriveIQ_Financial_Report_${Date.now()}.csv`);
    a.click();
    this.showToast("Financial CSV Report downloaded successfully!", "success");
  }

  // --- Settings Persistence ---
  saveSettings(e) {
    e.preventDefault();
    store.data.settings.companyName = document.getElementById('setCompanyName').value;
    store.data.settings.currency = document.getElementById('setCurrency').value;
    store.data.settings.taxRate = document.getElementById('setTaxRate').value;
    store.data.settings.supportEmail = document.getElementById('setSupportEmail').value;
    store.save();
    this.showToast('System settings updated!', 'success');
  }

  // --- Theme Toggle (Dark / Light) ---
  setupTheme() {
    const themeBtn = document.getElementById('themeToggleBtn');
    if (!themeBtn) return;

    themeBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'dark';
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      this.showToast(`Theme switched to ${next.toUpperCase()} mode`);
    });
  }

  // --- Toast Notification Helper ---
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-check-circle';
    if (type === 'warning') icon = 'fa-exclamation-triangle';
    if (type === 'error') icon = 'fa-times-circle';

    toast.innerHTML = `<i class="fas ${icon}"></i> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  filterPayments(status) {
    this.paymentsFilter = status;

    // Update active filter pill
    document.querySelectorAll('.filter-pill').forEach(btn => {
      const t = btn.textContent.replace(/[^a-zA-Z]/g, '').toLowerCase().trim();
      const target = status.replace(/[^a-zA-Z]/g, '').toLowerCase().trim();
      if (t === target) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    const tbody = document.getElementById('paymentsTableBody') || document.querySelector('.payments-table tbody');
    const rows = tbody ? tbody.querySelectorAll('tr.payment-row') : document.querySelectorAll('tr.payment-row');

    if (rows && rows.length > 0) {
      let visible = 0;
      rows.forEach(row => {
        const rowStatus = (row.getAttribute('data-status') || '').toLowerCase().trim();
        const target = status.toLowerCase().trim();
        const q = (this.paymentsSearch || '').toLowerCase().trim();
        const text = (row.getAttribute('data-search') || row.textContent).toLowerCase();
        const matchesSearch = !q || text.includes(q);
        const matchesStatus = (target === 'all' || rowStatus === target);

        if (matchesStatus && matchesSearch) {
          row.style.display = '';
          visible++;
        } else {
          row.style.display = 'none';
        }
      });

      let noRow = document.getElementById('paymentsEmptyFilterRow');
      if (visible === 0) {
        if (!noRow) {
          noRow = document.createElement('tr');
          noRow.id = 'paymentsEmptyFilterRow';
          noRow.innerHTML = `<td colspan="7" style="text-align:center; padding: 48px 20px; color: #94a3b8;">
            <i class="fas fa-filter" style="font-size: 28px; margin-bottom: 8px; opacity: 0.4;"></i>
            <p style="margin: 0; font-size: 14px;">No ${status} payments found.</p>
          </td>`;
          if (tbody) tbody.appendChild(noRow);
        } else {
          noRow.style.display = '';
          const p = noRow.querySelector('p');
          if (p) p.textContent = `No ${status} payments found.`;
        }
      } else if (noRow) {
        noRow.style.display = 'none';
      }
    } else {
      components.renderPayments(this.paymentsFilter, this.paymentsSearch);
    }
  }

  searchPayments(query) {
    this.paymentsSearch = query;
    const q = (query || '').toLowerCase().trim();
    const tbody = document.getElementById('paymentsTableBody') || document.querySelector('.payments-table tbody');
    const rows = tbody ? tbody.querySelectorAll('tr.payment-row') : document.querySelectorAll('tr.payment-row');

    if (rows && rows.length > 0) {
      rows.forEach(row => {
        const text = (row.getAttribute('data-search') || row.textContent).toLowerCase();
        const rowStatus = (row.getAttribute('data-status') || '').toLowerCase().trim();
        const target = (this.paymentsFilter || 'All').toLowerCase().trim();
        const matchesFilter = (target === 'all' || rowStatus === target);
        const matchesSearch = !q || text.includes(q);

        if (matchesSearch && matchesFilter) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    } else {
      components.renderPayments(this.paymentsFilter, this.paymentsSearch);
    }
  }

  handleGlobalSearch(query) {
    if (this.currentTab === 'payments') {
      this.searchPayments(query);
    } else if (this.currentTab === 'fleet') {
      components.renderFleet('All', query);
    } else if (this.currentTab === 'bookings') {
      components.renderBookings('All', query);
    }
  }

  openRecordPaymentModal() {
    const invInput = document.getElementById('payInvoiceNo');
    const dateInput = document.getElementById('payDate');
    if (invInput) invInput.value = 'INV-' + Math.floor(2409 + Math.random() * 500);
    if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
    this.openModal('modal-record-payment');
  }

  async handleRecordPayment(e) {
    if (e && e.preventDefault) e.preventDefault();
    const invoice_no = document.getElementById('payInvoiceNo')?.value.trim() || ('INV-' + Math.floor(2409 + Math.random() * 500));
    const customer_name = document.getElementById('payCustomerName')?.value.trim() || 'Customer';
    const description = document.getElementById('payDescription')?.value.trim() || 'Vehicle Rental';
    const invoice_date = document.getElementById('payDate')?.value || new Date().toISOString().split('T')[0];
    const amount = parseFloat(document.getElementById('payAmount')?.value || '50');
    const status = document.getElementById('payStatus')?.value || 'Paid';
    const payment_method = document.getElementById('payMethod')?.value || 'Credit Card';

    try {
      await store.addInvoice({
        invoice_no, customer_name, description, invoice_date, amount, status, payment_method
      });
      this.closeModal('modal-record-payment');
      this.updateLiveBadges();
      components.renderPayments(this.paymentsFilter, this.paymentsSearch);
      this.showToast(`Payment ${invoice_no} recorded successfully!`, 'success');
    } catch (err) {
      this.showToast(err.message || 'Failed to record payment', 'error');
    }
  }

  viewInvoice(invoiceNoOrBookingId) {
    let invoices = store.getInvoices();
    if (!invoices || invoices.length === 0) {
      invoices = window.paymentsInitialData || [];
    }
    let inv = invoices.find(x => x.invoice_no === invoiceNoOrBookingId || x.id === invoiceNoOrBookingId || x.booking_ref === invoiceNoOrBookingId);
    if (!inv && window.paymentsInitialData) {
      inv = window.paymentsInitialData.find(x => x.invoice_no === invoiceNoOrBookingId || x.id === invoiceNoOrBookingId || x.booking_ref === invoiceNoOrBookingId);
    }
    if (!inv) {
      const booking = store.getBookings().find(b => b.id === invoiceNoOrBookingId || b.booking_ref === invoiceNoOrBookingId);
      if (booking) {
        inv = {
          invoice_no: 'INV-' + (booking.id || '').slice(-4).toUpperCase(),
          customer_name: booking.customerName || booking.customer_name,
          customer_email: booking.customerEmail || booking.customer_email,
          description: `${booking.vehicleName || booking.vehicle_name} · ${booking.days || booking.rental_days || 1} days`,
          invoice_date: booking.pickupDate || booking.pickup_date || new Date().toISOString().split('T')[0],
          formattedDate: booking.pickupDate || booking.pickup_date || 'Today',
          amountFormatted: '$' + (booking.totalAmount || booking.price_usd || 0),
          amount: Number(booking.totalAmount || booking.price_usd || 0),
          status: booking.paymentStatus || 'Paid',
          payment_method: booking.payment_method || 'Cash on Pickup'
        };
      }
    }
    if (!inv) {
      const q = (invoiceNoOrBookingId || '').toLowerCase();
      const row = document.querySelector(`tr.payment-row[data-search*="${q}"]`) || 
                  Array.from(document.querySelectorAll('tr.payment-row')).find(r => (r.textContent || '').includes(invoiceNoOrBookingId));
      if (row) {
        inv = {
          invoice_no: row.querySelector('.invoice-link')?.textContent.trim() || invoiceNoOrBookingId,
          customer_name: row.querySelector('.cust-name-cell')?.textContent.trim() || 'Customer',
          description: row.querySelector('.desc-cell')?.textContent.trim() || 'Vehicle Rental',
          invoice_date: row.querySelector('.date-cell')?.textContent.trim() || new Date().toISOString().split('T')[0],
          formattedDate: row.querySelector('.date-cell')?.textContent.trim() || 'Today',
          amountFormatted: row.querySelector('.amount-cell')?.textContent.trim() || '$0',
          amount: parseFloat((row.querySelector('.amount-cell')?.textContent.trim() || '0').replace(/[^0-9.]/g, '')),
          status: row.getAttribute('data-status') || 'Paid',
          payment_method: 'Cash on Pickup'
        };
      }
    }
    if (!inv) {
      inv = {
        invoice_no: invoiceNoOrBookingId,
        customer_name: 'Customer',
        description: 'Vehicle Rental',
        invoice_date: new Date().toISOString().split('T')[0],
        formattedDate: 'Today',
        amountFormatted: '$0',
        amount: 0,
        status: 'Paid',
        payment_method: 'Cash on Pickup'
      };
    }
    components.renderInvoiceModal(inv);
    this.openModal('modal-view-invoice');
  }

  async cycleInvoiceStatus(invoiceNo, currentStatus) {
    const nextStatusMap = {
      'Paid': 'Pending',
      'Pending': 'Refunded',
      'Refunded': 'Paid'
    };
    const nextStatus = nextStatusMap[currentStatus] || 'Paid';
    
    // Immediate DOM update
    const q = (invoiceNo || '').toLowerCase();
    const row = document.querySelector(`tr.payment-row[data-search*="${q}"]`) || 
                Array.from(document.querySelectorAll('tr.payment-row')).find(r => (r.textContent || '').includes(invoiceNo));
    if (row) {
      row.setAttribute('data-status', nextStatus);
      const badge = row.querySelector('.status-badge');
      if (badge) {
        badge.className = `status-badge ${nextStatus.toLowerCase()}`;
        badge.textContent = nextStatus;
      }
      const syncBtn = row.querySelector('.icon-action-btn[title*="Cycle"]') || row.querySelectorAll('.icon-action-btn')[1];
      if (syncBtn) {
        syncBtn.setAttribute('onclick', `app.cycleInvoiceStatus('${invoiceNo}', '${nextStatus}')`);
        syncBtn.setAttribute('data-status', nextStatus);
      }
    }

    try {
      await store.updateInvoiceStatus(invoiceNo, nextStatus);
      this.updateLiveBadges();
      components.renderPayments(this.paymentsFilter, this.paymentsSearch);
      this.showToast(`Invoice ${invoiceNo} marked as ${nextStatus}`, 'success');
    } catch (err) {
      console.warn("Status update note:", err);
      this.showToast(`Invoice ${invoiceNo} marked as ${nextStatus}`, 'info');
    }
  }

  async deleteInvoicePrompt(invoiceNo) {
    if (!confirm(`Are you sure you want to delete payment ${invoiceNo}?`)) return;
    
    // Immediate DOM removal
    const q = (invoiceNo || '').toLowerCase();
    const row = document.querySelector(`tr.payment-row[data-search*="${q}"]`) || 
                Array.from(document.querySelectorAll('tr.payment-row')).find(r => (r.textContent || '').includes(invoiceNo));
    if (row) {
      row.remove();
    }
    const badge = document.getElementById('paymentsBadge');
    if (badge) {
      const c = parseInt(badge.textContent, 10) || 1;
      badge.textContent = Math.max(0, c - 1);
    }

    try {
      await store.deleteInvoice(invoiceNo);
      this.updateLiveBadges();
      components.renderPayments(this.paymentsFilter, this.paymentsSearch);
      this.showToast(`Invoice ${invoiceNo} deleted`, 'info');
    } catch (err) {
      console.warn("Delete note:", err);
      this.showToast(`Invoice ${invoiceNo} deleted`, 'info');
    }
  }
  async renderChat(){
    const users=document.getElementById('adminChatUsers'); if(!users)return;
    try{
      const r=await fetch('chat-api.php?action=customers',{cache:'no-store'}); const j=await r.json();
      users.innerHTML='<h3 style="padding:8px 10px;margin:0;font-size:14px;">Customer Chats</h3>';
      if(!(j.customers||[]).length){users.innerHTML+='<p style="padding:12px;opacity:.7;font-size:12px;">No customer messages yet. Messages will appear here when a customer starts a chat.</p>';return;}(j.customers||[]).forEach(c=>{const b=document.createElement('button');b.style='display:block;width:100%;text-align:left;padding:8px 9px;margin:4px 0;border:0;border-radius:10px;background:rgba(255,255,255,.06);color:inherit;cursor:pointer;font-size:12px;line-height:1.25';b.innerHTML='<strong style="font-size:12px;">'+this.escapeChat(c.name)+'</strong><br><small style="font-size:10px;opacity:.72;">'+this.escapeChat(c.email)+'</small>';b.onclick=()=>this.openChatCustomer(c);users.appendChild(b)});
    }catch(e){users.innerHTML='<p style="padding:12px;">Unable to load chats.</p>';}
  }
  async openChatCustomer(c){this.chatCustomerId=c.id;document.getElementById('adminChatTitle').textContent=c.name+' · '+c.email;await this.loadAdminChat();clearInterval(this.chatTimer);this.chatTimer=setInterval(()=>this.loadAdminChat(),2500)}
  async loadAdminChat(){if(!this.chatCustomerId)return;const r=await fetch('chat-api.php?action=list&customer_id='+encodeURIComponent(this.chatCustomerId),{cache:'no-store'});const j=await r.json();const box=document.getElementById('adminChatMsgs');if(!box)return;box.innerHTML='';(j.messages||[]).forEach(m=>{const d=document.createElement('div');d.style='display:table;max-width:70%;margin:8px 0;padding:10px 13px;border-radius:14px;background:'+(m.sender==='admin'?'#f59e0b':'rgba(255,255,255,.1)')+';color:'+(m.sender==='admin'?'#111':'inherit')+';text-align:left;';if(m.sender==='admin'){d.style.marginLeft='auto';d.style.marginRight='0';}else{d.style.marginLeft='0';d.style.marginRight='auto';}d.innerHTML=this.escapeChat(m.message)+'<div style="font-size:10px;opacity:.65;margin-top:3px">'+this.escapeChat(m.time||'')+'</div>';box.appendChild(d)});box.scrollTop=box.scrollHeight}
  escapeChat(x){return String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}

}

const app = new AppController();

if (typeof window !== 'undefined') {
  window.app = app;
  window.filterPayments = (s) => app.filterPayments(s);
  window.openRecordPaymentModal = () => app.openRecordPaymentModal();
  window.viewInvoice = (id) => app.viewInvoice(id);
  window.cycleInvoiceStatus = (id, st) => app.cycleInvoiceStatus(id, st);
  window.deleteInvoicePrompt = (id) => app.deleteInvoicePrompt(id);
  window.searchPayments = (q) => app.searchPayments(q);
  window.openModal = (id) => app.openModal(id);
  window.closeModal = (id) => app.closeModal(id);
}

document.addEventListener('DOMContentLoaded', () => {
  app.init();
});


document.addEventListener('submit',async e=>{if(e.target.id!=='adminChatForm')return;e.preventDefault();if(!app.chatCustomerId)return;const i=document.getElementById('adminChatInput');const msg=i.value.trim();if(!msg)return;const fd=new FormData();fd.append('action','send');fd.append('customer_id',app.chatCustomerId);fd.append('message',msg);await fetch('chat-api.php',{method:'POST',body:fd});i.value='';app.loadAdminChat();});
