/* ==========================================================================
   DriveIQ Admin Portal - Charts Engine (Chart.js Integration)
   Image 2 - Exactly matches Revenue & Rental Volume + Fleet Availability
   ========================================================================== */

let revenueChartInstance = null;
let fleetChartInstance = null;

function initCharts() {
  initRevenueChart();
  initFleetStatusChart();
}

function initRevenueChart() {
  const ctx = document.getElementById('revenueChart');
  if (!ctx) return;

  if (revenueChartInstance) {
    revenueChartInstance.destroy();
  }

  const isLight = document.documentElement.getAttribute('data-theme') === 'light';
  const gridColor = isLight ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)';
  const textColor = isLight ? '#6b7280' : '#9ca3af';

  const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 300);
  gradient.addColorStop(0, 'rgba(99, 102, 241, 0.35)');
  gradient.addColorStop(1, 'rgba(99, 102, 241, 0.02)');

  // Get data from store
  const chartData = store.getChartData();
  const metrics = store.getMetrics();
  const bookings = store.getBookings();

  let labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  let revenueValues = [1800, 2400, 1950, 3200, 4100, 5600, 4800];
  let bookingCounts = [4, 6, 5, 8, 12, 16, 14];

  // If real bookings exist, compute real curves or blend real totals
  if (chartData && Array.isArray(chartData.labels)) {
    labels = chartData.labels;
    if (Array.isArray(chartData.revenue) && chartData.revenue.some(x => x > 0)) {
      revenueValues = chartData.revenue;
      bookingCounts = chartData.bookings;
    }
  }

  revenueChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Revenue ($)',
          data: revenueValues,
          borderColor: '#6366f1',
          borderWidth: 3,
          backgroundColor: gradient,
          fill: true,
          tension: 0.45,
          pointBackgroundColor: '#6366f1',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointRadius: 4.5,
          pointHoverRadius: 7.5,
          yAxisID: 'y'
        },
        {
          label: 'Bookings Count',
          data: bookingCounts,
          borderColor: '#06b6d4',
          borderWidth: 2.2,
          borderDash: [5, 5],
          tension: 0.45,
          fill: false,
          pointRadius: 0,
          pointHoverRadius: 6,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'top',
          align: 'center',
          labels: {
            color: textColor,
            font: { family: 'Plus Jakarta Sans', size: 12, weight: '500' },
            boxWidth: 28,
            boxHeight: 12,
            usePointStyle: false,
            padding: 16
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          backgroundColor: isLight ? '#ffffff' : '#1f2937',
          titleColor: isLight ? '#111827' : '#ffffff',
          bodyColor: isLight ? '#4b5563' : '#9ca3af',
          borderColor: isLight ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)',
          borderWidth: 1,
          padding: 10,
          boxPadding: 4,
          callbacks: {
            label: function(context) {
              let label = context.dataset.label || '';
              if (label) label += ': ';
              if (context.datasetIndex === 0) {
                label += '$' + Number(context.parsed.y).toLocaleString();
              } else {
                label += context.parsed.y + ' reservations';
              }
              return label;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { color: gridColor, drawBorder: false },
          ticks: { color: textColor, font: { family: 'Plus Jakarta Sans', size: 12 } }
        },
        y: {
          type: 'linear',
          position: 'left',
          grid: { color: gridColor, drawBorder: false },
          ticks: {
            color: textColor,
            font: { family: 'Plus Jakarta Sans', size: 12 },
            callback: (val) => '$' + Number(val).toLocaleString()
          }
        },
        y1: {
          type: 'linear',
          position: 'right',
          grid: { drawOnChartArea: false, drawBorder: false },
          ticks: {
            color: '#06b6d4',
            font: { family: 'Plus Jakarta Sans', size: 12, weight: '600' },
            stepSize: 2
          }
        }
      }
    }
  });
}

function initFleetStatusChart() {
  const ctx = document.getElementById('fleetChart');
  if (!ctx) return;

  if (fleetChartInstance) {
    fleetChartInstance.destroy();
  }

  const metrics = store.getMetrics();
  const vehicles = store.getVehicles();

  const maintenanceList = vehicles.filter(v => {
    const st = (v.status || '').toLowerCase().trim();
    return st === 'maintenance' || st === 'service' || st === 'repair';
  });

  const available = metrics.availableVehicles ?? vehicles.filter(v => (v.status || '').toLowerCase() === 'available').length;
  const rented = metrics.activeRentals ?? vehicles.filter(v => (v.status || '').toLowerCase() === 'rented').length;
  const maintenance = metrics.maintenanceAlerts ?? maintenanceList.length;

  // Update dynamic numbers in HTML legend
  const legAvail = document.getElementById('legendCountAvail');
  const legRented = document.getElementById('legendCountRented');
  const legMaint = document.getElementById('legendCountMaint');
  if (legAvail) legAvail.textContent = available;
  if (legRented) legRented.textContent = rented;
  if (legMaint) legMaint.textContent = maintenance;

  const chartData = [available, rented, maintenance];
  // Avoid empty donut
  const finalData = chartData.every(x => x === 0) ? [10, 2, 0] : chartData;

  fleetChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Available', 'Active Rented', 'Service / Maintenance'],
      datasets: [
        {
          data: finalData,
          backgroundColor: ['#10b981', '#6366f1', '#f59e0b'],
          borderWidth: 0,
          hoverOffset: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '72%',
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: document.documentElement.getAttribute('data-theme') === 'light' ? '#ffffff' : '#1f2937',
          titleColor: document.documentElement.getAttribute('data-theme') === 'light' ? '#111827' : '#ffffff',
          bodyColor: document.documentElement.getAttribute('data-theme') === 'light' ? '#4b5563' : '#9ca3af',
          borderColor: 'rgba(255,255,255,0.1)',
          borderWidth: 1,
          callbacks: {
            label: function(ctx) {
              return ` ${ctx.label}: ${ctx.raw} vehicles`;
            }
          }
        }
      }
    }
  });
}
