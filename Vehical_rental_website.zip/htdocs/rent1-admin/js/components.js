/* ==========================================================================
   DriveIQ Admin Portal - Dynamic UI Components & Views Renderer
   ========================================================================== */

const components = {

  // --- 1. Dashboard View Renderer ---
  renderDashboard() {
    const metrics = store.getMetrics();
    const container = document.getElementById('view-dashboard');
    if (!container) return;

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Dashboard Overview</h1>
          <p>Real-time telemetry, rental statistics, and revenue insights</p>
        </div>
        <button class="primary-btn" onclick="app.openModal('modal-add-booking')">
          <i class="fas fa-plus"></i> New Reservation
        </button>
      </div>

      <!-- Metric Cards Grid -->
      <div class="metrics-grid">
        <div class="metric-card card-blue">
          <div class="metric-info">
            <h3>Total Revenue</h3>
            <div class="metric-value">$${Number(metrics.totalRevenue || 0).toLocaleString()}</div>
            <div class="metric-trend"><i class="fas fa-chart-line"></i> ${metrics.totalBookings || 0} total bookings</div>
          </div>
          <div class="metric-icon"><i class="fas fa-wallet"></i></div>
        </div>

        <div class="metric-card card-green">
          <div class="metric-info">
            <h3>Active Rentals</h3>
            <div class="metric-value">${metrics.activeRentals || 0} Vehicles</div>
            <div class="metric-trend"><i class="fas fa-chart-pie"></i> ${Number(metrics.fleetUtilization || 0).toFixed(1)}% Fleet Utilization</div>
          </div>
          <div class="metric-icon"><i class="fas fa-car-side"></i></div>
        </div>

        <div class="metric-card card-cyan">
          <div class="metric-info">
            <h3>Available Fleet</h3>
            <div class="metric-value">${metrics.availableVehicles || 0} Ready</div>
            <div class="metric-trend"><i class="fas fa-check-circle"></i> ${metrics.cleanServiced || 0} Clean & Serviced</div>
          </div>
          <div class="metric-icon"><i class="fas fa-key"></i></div>
        </div>

        <div class="metric-card card-amber">
          <div class="metric-info">
            <h3>Service / Repairs</h3>
            <div class="metric-value">${metrics.maintenanceAlerts || 0} Units</div>
            <div class="metric-trend ${(metrics.maintenanceAlerts || 0) > 0 ? "down" : "up"}"><i class="fas fa-${(metrics.maintenanceAlerts || 0) > 0 ? "exclamation-triangle" : "check-circle"}"></i> ${(metrics.maintenanceAlerts || 0) > 0 ? "Action required" : "All clear"}</div>
          </div>
          <div class="metric-icon"><i class="fas fa-tools"></i></div>
        </div>
      </div>

      <!-- Charts Section -->
      <div class="charts-grid">
        <div class="chart-card">
          <div class="card-header">
            <h2>Revenue & Rental Volume</h2>
            <select class="card-actions-select" onchange="app.showToast('Updated chart timeline view')">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
              <option>This Month</option>
            </select>
          </div>
          <div class="chart-wrapper">
            <canvas id="revenueChart"></canvas>
          </div>
        </div>

        <div class="chart-card">
          <div class="card-header">
            <h2>Fleet Availability</h2>
            <span class="badge badge-available">Live Update</span>
          </div>
          <div class="chart-wrapper" style="height:200px;">
            <canvas id="fleetChart"></canvas>
          </div>
          <div class="legend-list">
            <div class="legend-item"><span><span class="legend-dot" style="background:#10b981"></span> Available</span><strong>${metrics.availableVehicles}</strong></div>
            <div class="legend-item"><span><span class="legend-dot" style="background:#6366f1"></span> Active Rented</span><strong>${metrics.activeRentals}</strong></div>
            <div class="legend-item"><span><span class="legend-dot" style="background:#f59e0b"></span> Service / Maintenance</span><strong>${metrics.maintenanceAlerts}</strong></div>
          </div>
        </div>
      </div>

      <!-- Recent Bookings Quick Table -->
      <div class="table-card">
        <div class="card-header">
          <h2>Recent Reservations</h2>
          <button class="secondary-btn" onclick="app.switchTab('bookings')">View All Bookings</button>
        </div>
        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>Booking ID</th>
                <th>Customer</th>
                <th>Vehicle</th>
                <th>Dates</th>
                <th>Total ($)</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${store.getBookings().slice(0, 5).map(b => `
                <tr>
                  <td><strong>${b.id}</strong></td>
                  <td>
                    <div><strong>${b.customerName}</strong></div>
                    <small style="color:var(--text-dim);">${b.customerPhone}</small>
                  </td>
                  <td>${b.vehicleName}</td>
                  <td>${b.pickupDate} &rarr; ${b.returnDate}</td>
                  <td><strong>$${b.totalAmount}</strong></td>
                  <td><span class="badge badge-${b.status.toLowerCase()}">${b.status}</span></td>
                  <td>
                    <div class="table-actions">
                      <button class="btn-icon-sm" title="View Invoice" onclick="app.viewInvoice('${b.id}')"><i class="fas fa-file-invoice-dollar"></i></button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    // Re-initialize Chart.js after DOM rendering
    setTimeout(() => {
      initCharts();
    }, 50);
  },

  // --- 2. Fleet View Renderer ---
  renderFleet(filterCategory = 'All', searchKeyword = '') {
    const container = document.getElementById('view-fleet');
    if (!container) return;

    let vehicles = store.getVehicles();

    if (filterCategory !== 'All') {
      vehicles = vehicles.filter(v => v.category === filterCategory);
    }

    if (searchKeyword.trim() !== '') {
      const q = searchKeyword.toLowerCase();
      vehicles = vehicles.filter(v => 
        v.name.toLowerCase().includes(q) || 
        v.brand.toLowerCase().includes(q) || 
        v.plate.toLowerCase().includes(q)
      );
    }

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Fleet Inventory Management</h1>
          <p>Manage, add, and monitor all vehicles in your rental fleet</p>
        </div>
        <button class="primary-btn" onclick="app.openModal('modal-add-vehicle')">
          <i class="fas fa-plus"></i> Add New Vehicle
        </button>
      </div>

      <!-- Filter Bar -->
      <div class="filter-bar">
        <div class="filter-group">
          <input type="text" class="filter-input" id="fleetSearchInput" placeholder="Search by model, brand or plate..." value="${searchKeyword}" oninput="app.filterFleet()">
          
          <select class="filter-select" id="fleetCategorySelect" onchange="app.filterFleet()">
            <option value="All" ${filterCategory === 'All' ? 'selected' : ''}>All Categories</option>
            <option value="Electric" ${filterCategory === 'Electric' ? 'selected' : ''}>Electric (EV)</option>
            <option value="Sports" ${filterCategory === 'Sports' ? 'selected' : ''}>Sports</option>
            <option value="Luxury SUV" ${filterCategory === 'Luxury SUV' ? 'selected' : ''}>Luxury SUV</option>
            <option value="SUV" ${filterCategory === 'SUV' ? 'selected' : ''}>SUV</option>
          </select>
        </div>

        <div class="filter-group">
          <button class="secondary-btn" onclick="app.toggleFleetViewMode('grid')"><i class="fas fa-th-large"></i> Grid</button>
          <button class="secondary-btn" onclick="app.toggleFleetViewMode('table')"><i class="fas fa-list"></i> Table</button>
        </div>
      </div>

      <!-- Fleet Grid -->
      <div class="fleet-grid" id="fleetGridContainer">
        ${vehicles.map(v => `
          <div class="vehicle-card">
            <div class="vehicle-card-img-wrap">
              <img src="${v.image}" alt="${v.name}" class="vehicle-card-img" onerror="this.src='https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=600'">
              <span class="vehicle-card-badge badge badge-${v.status.toLowerCase()}">${v.status}</span>
            </div>
            <div class="vehicle-card-body">
              <h3 class="vehicle-title">${v.name}</h3>
              <p class="vehicle-sub">${v.plate} &bull; ${v.category}</p>

              <div class="vehicle-specs">
                <div class="spec-item"><i class="fas fa-gas-pump"></i> ${v.fuel}</div>
                <div class="spec-item"><i class="fas fa-cog"></i> ${v.transmission}</div>
                <div class="spec-item"><i class="fas fa-user-friends"></i> ${v.seats} Seats</div>
              </div>

              <div class="vehicle-footer">
                <div class="price-tag">$${v.rate} <span>/ day</span></div>
                <div class="table-actions">
                  <button class="btn-icon-sm" title="Edit Vehicle" onclick="app.editVehicleModal('${v.id}')"><i class="fas fa-edit"></i></button>
                  <button class="btn-icon-sm delete" title="Delete Vehicle" onclick="app.deleteVehicle('${v.id}')"><i class="fas fa-trash-alt"></i></button>
                </div>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  // --- 3. Bookings View Renderer ---
  renderBookings() {
    const container = document.getElementById('view-bookings');
    if (!container) return;

    const bookings = store.getBookings();

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Reservations & Bookings</h1>
          <p>Track rental agreements, pickup schedules, driver dispatch & payments</p>
        </div>
        <button class="primary-btn" onclick="app.openModal('modal-add-booking')">
          <i class="fas fa-plus"></i> New Reservation
        </button>
      </div>

      <div class="table-card">
        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Vehicle</th>
                <th>Locations</th>
                <th>Rental Period</th>
                <th>Total</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${bookings.map(b => `
                <tr>
                  <td><strong>${b.id}</strong></td>
                  <td>
                    <div><strong>${b.customerName}</strong></div>
                    <small style="color:var(--text-dim);">${b.customerPhone}</small>
                  </td>
                  <td>
                    <div><strong>${b.vehicleName}</strong></div>
                    <small style="color:var(--accent-cyan);"><i class="fas fa-user-tie"></i> ${b.driverName}</small>
                  </td>
                  <td>
                    <div style="font-size:13px;"><i class="fas fa-map-marker-alt" style="color:var(--accent-emerald);"></i> ${b.pickupLocation}</div>
                    <div style="font-size:12px; color:var(--text-dim);"><i class="fas fa-flag-checkered"></i> ${b.returnLocation}</div>
                  </td>
                  <td>${b.pickupDate} to ${b.returnDate} (${b.days} Days)</td>
                  <td>
                    <strong>$${b.totalAmount}</strong>
                    <div><small class="badge ${b.paymentStatus === 'Paid' ? 'badge-available' : 'badge-pending'}">${b.paymentStatus}</small></div>
                  </td>
                  <td>
                    <select class="filter-select" onchange="app.changeBookingStatus('${b.id}', this.value)" style="padding:4px 8px; font-size:12px;">
                      <option value="Pending" ${b.status === 'Pending' ? 'selected' : ''}>Pending</option>
                      <option value="Confirmed" ${b.status === 'Confirmed' ? 'selected' : ''}>Confirmed</option>
                      <option value="Completed" ${b.status === 'Completed' ? 'selected' : ''}>Completed</option>
                      <option value="Cancelled" ${b.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                    </select>
                  </td>
                  <td>
                    <div class="table-actions">
                      <button class="btn-icon-sm" title="Print Invoice" onclick="app.viewInvoice('${b.id}')"><i class="fas fa-file-invoice"></i></button>
                      ${b.status === 'Completed' ? `<button class="btn-icon-sm" title="View return inspection" onclick="app.processVehicleReturn('${b.id}')"><i class="fas fa-clipboard-check"></i></button>` : `<button class="btn-icon-sm" title="Process vehicle return" onclick="app.processVehicleReturn('${b.id}')"><i class="fas fa-car-side"></i></button>`}
                      <button class="btn-icon-sm delete" title="Delete Booking" onclick="app.deleteBooking('${b.id}')"><i class="fas fa-trash-alt"></i></button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // --- 4. Customers View Renderer ---
  renderCustomers() {
    const container = document.getElementById('view-customers');
    if (!container) return;

    const customers = store.getCustomers();

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Customer Management</h1>
          <p>Verified renters, identity verification, and total rental history</p>
        </div>
      </div>

      <div class="metrics-grid customer-metrics" style="margin-bottom:20px;">
        <div class="metric-card card-blue">
          <div class="metric-info"><h3>Total Customers</h3><div class="metric-value">${customers.length}</div><div class="metric-trend"><i class="fas fa-users"></i> Registered customers</div></div>
          <div class="metric-icon"><i class="fas fa-users"></i></div>
        </div>
        <div class="metric-card card-green">
          <div class="metric-info"><h3>Active Renters</h3><div class="metric-value">${customers.filter(c => Number(c.totalRentals || 0) > 0).length}</div><div class="metric-trend"><i class="fas fa-user-check"></i> Customers with rentals</div></div>
          <div class="metric-icon"><i class="fas fa-user-check"></i></div>
        </div>
        <div class="metric-card card-cyan">
          <div class="metric-info"><h3>Total Rentals</h3><div class="metric-value">${customers.reduce((sum, c) => sum + Number(c.totalRentals || 0), 0)}</div><div class="metric-trend"><i class="fas fa-car"></i> Live from bookings</div></div>
          <div class="metric-icon"><i class="fas fa-car"></i></div>
        </div>
        <div class="metric-card card-amber">
          <div class="metric-info"><h3>Total Spent</h3><div class="metric-value">$${customers.reduce((sum, c) => sum + Number(c.spentTotal || 0), 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</div><div class="metric-trend"><i class="fas fa-wallet"></i> Non-cancelled bookings</div></div>
          <div class="metric-icon"><i class="fas fa-wallet"></i></div>
        </div>
      </div>

      <div class="table-card">
        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>Customer Name</th>
                <th>Contact Info</th>
                <th>NIC / License No.</th>
                <th>Status</th>
                <th>Total Rentals</th>
                <th>Total Spent</th>
                <th>Rating</th>
              </tr>
            </thead>
            <tbody>
              ${customers.map(c => `
                <tr>
                  <td><strong>${c.name}</strong></td>
                  <td>
                    <div>${c.email}</div>
                    <small style="color:var(--text-dim);">${c.phone}</small>
                  </td>
                  <td><code style="white-space:nowrap;">${c.nicLicense}</code></td>
                  <td>
                    <span class="badge ${c.verified ? 'badge-available' : 'badge-pending'}">
                      ${c.verified ? 'Verified ID' : 'Pending Verification'}
                    </span>
                  </td>
                  <td><strong>${c.totalRentals} Rentals</strong></td>
                  <td><strong>$${Number(c.spentTotal || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</strong></td>
                  <td><i class="fas fa-star" style="color:var(--accent-amber);"></i> ${c.rating} / 5.0</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // --- 5. Chauffeur Roster Renderer ---
  renderDrivers(statusFilter = 'All', searchKeyword = '') {
    const container = document.getElementById('view-drivers');
    if (!container) return;

    const allDrivers = store.getDrivers();
    let drivers = allDrivers.filter(d => statusFilter === 'All' || (d.status || '') === statusFilter);
    const q = searchKeyword.trim().toLowerCase();
    if (q) {
      drivers = drivers.filter(d => [d.name,d.id,d.phone,d.email,d.license_no,d.assignedVehicle].some(v => String(v || '').toLowerCase().includes(q)));
    }

    const active = allDrivers.filter(d => d.active !== false);
    const available = active.filter(d => d.status === 'Available').length;
    const onShift = active.filter(d => d.status === 'On Shift').length;
    const assigned = active.filter(d => d.assigned_vehicle_id || d.assignedVehicle && d.assignedVehicle !== 'Unassigned').length;
    const inactive = allDrivers.filter(d => d.active === false).length;
    const statusClass = st => st === 'Available' ? 'badge-available' : st === 'On Shift' ? 'badge-rented' : st === 'Suspended' ? 'badge-maintenance' : 'badge-pending';
    const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Chauffeur Roster</h1>
          <p>Manage chauffeur profiles, shifts, availability, vehicle assignments and performance</p>
        </div>
        <button class="primary-btn" onclick="app.openModal('modal-add-chauffeur')"><i class="fas fa-user-plus"></i> Add Chauffeur</button>
      </div>

      <div class="metrics-grid" style="margin-bottom:20px;">
        <div class="metric-card card-blue"><div class="metric-info"><h3>Total Chauffeurs</h3><div class="metric-value">${active.length}</div><div class="metric-trend"><i class="fas fa-id-badge"></i> ${inactive} inactive</div></div><div class="metric-icon"><i class="fas fa-users-cog"></i></div></div>
        <div class="metric-card card-green"><div class="metric-info"><h3>Available</h3><div class="metric-value">${available}</div><div class="metric-trend"><i class="fas fa-check-circle"></i> Ready for dispatch</div></div><div class="metric-icon"><i class="fas fa-user-check"></i></div></div>
        <div class="metric-card card-cyan"><div class="metric-info"><h3>On Shift</h3><div class="metric-value">${onShift}</div><div class="metric-trend"><i class="fas fa-route"></i> Currently working</div></div><div class="metric-icon"><i class="fas fa-steering-wheel"></i></div></div>
        <div class="metric-card card-amber"><div class="metric-info"><h3>Vehicle Assigned</h3><div class="metric-value">${assigned}</div><div class="metric-trend"><i class="fas fa-car"></i> Active assignments</div></div><div class="metric-icon"><i class="fas fa-car-side"></i></div></div>
      </div>

      <div class="filter-bar">
        <div class="filter-group" style="flex:1;min-width:300px;">
          <input class="filter-input" id="chauffeurSearchInput" value="${esc(searchKeyword)}" placeholder="Search name, code, phone, license or vehicle..." oninput="app.filterChauffeurs()">
          <select class="filter-select" id="chauffeurStatusSelect" onchange="app.filterChauffeurs()">
            ${['All','Available','On Shift','On Leave','Off Duty','Suspended'].map(x => `<option value="${x}" ${statusFilter===x?'selected':''}>${x}</option>`).join('')}
          </select>
        </div>
        <div class="filter-group">
          <button class="secondary-btn" onclick="app.refreshChauffeurs()"><i class="fas fa-sync-alt"></i> Refresh</button>
          <button class="secondary-btn" onclick="app.openModal('modal-add-chauffeur')"><i class="fas fa-user-plus"></i> New Profile</button>
        </div>
      </div>

      <div class="table-card">
        <div class="table-responsive">
          <table class="custom-table">
            <thead><tr><th>Chauffeur</th><th>Contact / License</th><th>Shift</th><th>Assigned Vehicle</th><th>Rate</th><th>Performance</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              ${drivers.length ? drivers.map(d => `
                <tr style="${d.active===false?'opacity:.55;':''}">
                  <td><div style="display:flex;align-items:center;gap:10px;"><div style="width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:rgba(99,102,241,.16);color:var(--accent-cyan);"><i class="fas fa-user-tie"></i></div><div><strong>${esc(d.name)}</strong><div><code>${esc(d.id)}</code>${d.active===false?' <span class="badge badge-pending">Inactive</span>':''}</div></div></div></td>
                  <td><div>${esc(d.phone || 'No phone')}</div><small style="color:var(--text-dim);">${esc(d.email || '')}</small><div style="margin-top:3px;color:var(--accent-cyan);font-size:12px;"><i class="fas fa-id-card"></i> ${esc(d.license_no || 'No license')}</div></td>
                  <td><strong>${esc(d.shiftStart || '--')} - ${esc(d.shiftEnd || '--')}</strong><div style="font-size:11px;color:var(--text-dim);margin-top:3px;">${esc(d.work_days || 'Schedule not set')}</div><small style="color:var(--accent-amber);">Next: ${esc(d.next_shift || 'Not set')}</small></td>
                  <td><strong>${esc(d.assignedVehicle || 'Unassigned')}</strong>${d.assigned_vehicle_id?`<div style="font-size:11px;color:var(--text-dim);">${esc(d.assigned_vehicle_id)}</div>`:''}</td>
                  <td><strong>$${Number(d.dailyRate || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</strong><div style="font-size:11px;color:var(--text-dim);">per day</div></td>
                  <td><div><strong>${Number(d.tripsCompleted || 0)}</strong> trips</div><div style="color:var(--accent-amber);"><i class="fas fa-star"></i> ${Number(d.rating || 0).toFixed(1)} / 5</div></td>
                  <td><select class="filter-select" style="padding:5px 8px;font-size:11px;min-width:105px;" onchange="app.changeChauffeurStatus('${esc(d.id)}',this.value,${Number(d.db_id||0)})" ${d.active===false?'disabled':''}>${['Available','On Shift','On Leave','Off Duty','Suspended'].map(st=>`<option value="${st}" ${d.status===st?'selected':''}>${st}</option>`).join('')}</select></td>
                  <td><div class="table-actions"><button class="btn-icon-sm" title="Edit Chauffeur" onclick="app.editChauffeurModal('${esc(d.id)}')"><i class="fas fa-edit"></i></button>${d.active===false?`<button class="btn-icon-sm" title="Restore Chauffeur" onclick="app.restoreChauffeur('${esc(d.id)}',${Number(d.db_id||0)})"><i class="fas fa-user-check"></i></button>`:`<button class="btn-icon-sm delete" title="Deactivate Chauffeur" onclick="app.deleteChauffeur('${esc(d.id)}',${Number(d.db_id||0)})"><i class="fas fa-user-slash"></i></button>`}</div></td>
                </tr>
              `).join('') : `<tr><td colspan="8" style="text-align:center;padding:50px;color:var(--text-dim);"><i class="fas fa-user-tie" style="font-size:34px;opacity:.35;margin-bottom:10px;"></i><p>No chauffeur profiles match your filter.</p><button class="primary-btn" onclick="app.openModal('modal-add-chauffeur')"><i class="fas fa-user-plus"></i> Add First Chauffeur</button></td></tr>`}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // --- 6. Live GPS Tracker Renderer ---
  renderGPS() {
    const container = document.getElementById('view-gps');
    if (!container) return;

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Live GPS Fleet Tracker</h1>
          <p>See the real-time location of vehicles that customers have picked up.</p>
        </div>
        <span class="badge badge-available"><div class="live-pulse"></div> LIVE GPS</span>
      </div>

      <div class="gps-container" style="grid-template-columns:minmax(0,1fr) 330px;">
        <div class="map-view-box" style="min-height:560px; position:relative; overflow:hidden; border-radius:16px;">
          <div id="liveGpsMap" style="width:100%;height:560px;background:#0d1322;"></div>
          <div class="map-overlay-controls" style="z-index:1000;">
            <span style="font-size:13px;font-weight:700;"><i class="fas fa-location-arrow" style="color:var(--accent-cyan);"></i> Live vehicle positions</span>
            <small id="gpsLastRefresh" style="color:var(--text-dim);">Connecting...</small>
          </div>
        </div>
        <div class="gps-sidebar-list" id="gpsVehicleList">
          <h3 style="margin-bottom:14px;font-size:16px;">Picked-up Vehicles</h3>
          <div style="padding:25px;color:var(--text-dim);text-align:center;">Loading GPS data...</div>
        </div>
      </div>
      <div style="margin-top:12px;padding:12px 15px;border:1px solid var(--card-border);border-radius:12px;color:var(--text-dim);font-size:12px;">
        <i class="fas fa-info-circle"></i>
        Location is received from the customer's phone only after the customer allows browser location access.
        A vehicle without a recent signal is not shown as live.
      </div>
    `;

    if (typeof app !== 'undefined' && app.initRealGPSMap) {
      app.initRealGPSMap();
    }
  },

  // --- 7. Maintenance View Renderer ---
  renderMaintenance() {
    const container = document.getElementById('view-maintenance');
    if (!container) return;

    const maintenanceLogs = store.getMaintenance();

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>Maintenance & Service Tracker</h1>
          <p>Manage vehicle servicing, oil changes, repairs & technical logs</p>
        </div>
        <button class="primary-btn" onclick="app.openModal('modal-add-maintenance')">
          <i class="fas fa-plus"></i> New Service Ticket
        </button>
      </div>

      <div class="table-card">
        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>Ticket ID</th>
                <th>Vehicle</th>
                <th>Issue Description</th>
                <th>Service Center</th>
                <th>Est. Repair Cost</th>
                <th>Dates</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${maintenanceLogs.length ? maintenanceLogs.map(m => `
                <tr>
                  <td><strong>${m.id}</strong></td>
                  <td><strong>${m.vehicleName}</strong></td>
                  <td>${m.issue}</td>
                  <td>${m.serviceCenter}</td>
                  <td><strong>$${Number(m.cost || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</strong></td>
                  <td>${m.startDate} to ${m.estimatedReturn}</td>
                  <td>
                    <span class="badge ${m.status === 'In Progress' ? 'badge-maintenance' : 'badge-available'}">${m.status}</span>
                    <div style="display:flex;gap:6px;margin-top:8px;">
                      ${m.status === 'In Progress' ? `<button class="secondary-btn" style="padding:5px 9px;font-size:11px;" onclick="app.completeMaintenance('${m.id}')"><i class="fas fa-check"></i> Complete</button>` : ''}
                      <button class="secondary-btn" style="padding:5px 9px;font-size:11px;" onclick="app.deleteMaintenance('${m.id}')"><i class="fas fa-trash"></i></button>
                    </div>
                  </td>
                </tr>
              `).join('') : `<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-dim);">No service / repair records. All clear.</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // --- 8. Financials View Renderer ---
  renderFinancials() {
    const container = document.getElementById('view-financials');
    if (!container) return;
    const metrics = store.getMetrics();
    const currency = store.data.settings?.currency?.includes('LKR') ? 'Rs' : '$';
    const today = new Date();
    const todayText = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
    const monthStart = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-01`;
    container.innerHTML = `
      <div class="page-title-bar"><div><h1>Financial Management &amp; Rates</h1><p>Revenue statements, rate rules and downloadable detailed reports</p></div></div>
      <div class="metrics-grid">
        <div class="metric-card card-green"><div class="metric-info"><h3>Gross Revenue (MTD)</h3><div class="metric-value">${Number(metrics.totalRevenue || 0).toLocaleString()}</div><div class="metric-trend up"><i class="fas fa-arrow-up"></i> Live from database bookings</div></div><div class="metric-icon"><i class="fas fa-dollar-sign"></i></div></div>
        <div class="metric-card card-amber"><div class="metric-info"><h3>Maintenance Expenses</h3><div class="metric-value">${currency}${Number(metrics.maintenanceExpenses || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</div><div class="metric-trend down"><i class="fas fa-wrench"></i> ${Number(metrics.maintenanceAlerts || 0)} vehicle(s) currently in service</div></div><div class="metric-icon"><i class="fas fa-wrench"></i></div></div>
        <div class="metric-card card-cyan"><div class="metric-info"><h3>Net Operating Margin</h3><div class="metric-value">${metrics.fleetUtilization || 0}%</div><div class="metric-trend up"><i class="fas fa-chart-line"></i> Fleet utilization</div></div><div class="metric-icon"><i class="fas fa-percent"></i></div></div>
      </div>
      <section class="financial-report-wrap" style="max-width:1100px;margin:26px auto;padding:0 4px 30px;">
        <div class="panel" style="padding:26px;border-radius:18px;">
          <div style="display:flex;gap:14px;align-items:center;margin-bottom:22px"><div style="width:48px;height:48px;display:grid;place-items:center;border-radius:14px;background:rgba(16,185,129,.14);color:#10b981;font-size:22px"><i class="fas fa-calendar-alt"></i></div><div><h2 style="margin:0 0 5px">Export Detailed Financial Report</h2><p style="margin:0;color:var(--text-dim)">Select one day or a date range, then download every available booking and invoice detail as a CSV worksheet.</p></div></div>
          <form id="financialReportForm" action="financial-report.php" method="get" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr)) auto;gap:16px;align-items:end">
            <div><label for="reportStartDate" style="display:block;margin-bottom:8px;font-weight:700">From date</label><input type="date" id="reportStartDate" name="start_date" value="${monthStart}" required style="width:100%;box-sizing:border-box;padding:13px;border-radius:10px;border:1px solid var(--border-color,#475569);background:var(--bg-secondary,#111827);color:var(--text-primary,#fff);min-height:48px"></div>
            <div><label for="reportEndDate" style="display:block;margin-bottom:8px;font-weight:700">To date</label><input type="date" id="reportEndDate" name="end_date" value="${todayText}" required style="width:100%;box-sizing:border-box;padding:13px;border-radius:10px;border:1px solid var(--border-color,#475569);background:var(--bg-secondary,#111827);color:var(--text-primary,#fff);min-height:48px"></div>
            <button type="submit" class="primary-btn" style="min-height:48px;background:#059669!important;color:#fff!important;border:0;padding:0 20px;white-space:nowrap"><i class="fas fa-file-csv"></i> Download CSV</button>
          </form>
          <div style="display:flex;flex-wrap:wrap;gap:9px;margin:16px 0 22px">
            <button type="button" class="secondary-btn" data-report-period="day">Today only</button><button type="button" class="secondary-btn" data-report-period="month">This month</button><button type="button" class="secondary-btn" data-report-period="all">All dates</button>
          </div>
          <p style="margin:16px 0 0;color:var(--text-dim);font-size:12px;line-height:1.6">Choose the same start and end date for a single-day report. The CSV opens in Microsoft Excel. Booking records are filtered by booking creation date; invoice records are filtered by invoice date.</p>
        </div>
      </section>`;
    const form = document.getElementById('financialReportForm');
    const startInput = document.getElementById('reportStartDate');
    const endInput = document.getElementById('reportEndDate');
    form?.addEventListener('submit', e => { if (!startInput.value || !endInput.value || endInput.value < startInput.value) { e.preventDefault(); this.showToast?.('Please choose a valid date range.', 'error'); } });
    container.querySelectorAll('[data-report-period]').forEach(btn => btn.addEventListener('click', () => {
      const period = btn.getAttribute('data-report-period');
      if (period === 'day') { startInput.value = todayText; endInput.value = todayText; }
      else if (period === 'month') { startInput.value = monthStart; endInput.value = todayText; }
      else { startInput.value = '2000-01-01'; endInput.value = todayText; }
    }));
  },

  // --- Customer Carts View Renderer ---
  renderCarts() {
    const container = document.getElementById('view-carts');
    if (!container) return;
    const cart = store.data.cart || [];
    container.innerHTML = `
      <div class="page-title-bar"><div><h1>Customer Carts</h1><p>Live cart items from the shared customer database</p></div></div>
      <div class="fleet-grid">
        ${cart.length ? cart.map(x=>`<div class="vehicle-card"><div class="vehicle-card-body">
          <h3 class="vehicle-title">${x.name||x.vehicle_name||'Vehicle'}</h3>
          <p class="vehicle-sub"><i class="fas fa-user"></i> ${x.customer_name||'Customer'} ${x.customer_email?`&bull; ${x.customer_email}`:''}</p>
          <div class="vehicle-specs"><div class="spec-item"><i class="fas fa-calendar"></i> ${x.pickup_date||'-'} → ${x.dropoff_date||'-'}</div><div class="spec-item"><i class="fas fa-clock"></i> ${x.days||0} Days</div></div>
          <div class="vehicle-footer"><div class="price-tag">${x.currency||'USD'} ${x.total_price||x.total||0}</div></div>
        </div></div>`).join('') : '<div class="panel"><h3>No customer cart items</h3><p>Cart items added from the customer website will appear here automatically.</p></div>'}
      </div>`;
  },

  // --- 9. Settings View Renderer ---
  renderSettings() {
    const container = document.getElementById('view-settings');
    if (!container) return;

    const s = store.data.settings;

    container.innerHTML = `
      <div class="page-title-bar">
        <div>
          <h1>System Settings & Preferences</h1>
          <p>Configure company profile, currency rules, and theme options</p>
        </div>
      </div>

      <div class="table-card" style="max-width:700px;">
        <form onsubmit="app.saveSettings(event)" class="form-grid">
          <div class="form-group full-width">
            <label>Company Name</label>
            <input type="text" class="form-control" id="setCompanyName" value="${s.companyName}">
          </div>

          <div class="form-group">
            <label>System Currency</label>
            <select class="form-control" id="setCurrency">
              <option value="USD ($)" ${s.currency.includes('USD') ? 'selected' : ''}>USD ($)</option>
              <option value="LKR (Rs)" ${s.currency.includes('LKR') ? 'selected' : ''}>LKR (Rs)</option>
              <option value="EUR (€)" ${s.currency.includes('EUR') ? 'selected' : ''}>EUR (€)</option>
            </select>
          </div>

          <div class="form-group">
            <label>Tax / VAT Rate (%)</label>
            <input type="number" class="form-control" id="setTaxRate" value="${s.taxRate}">
          </div>

          <div class="form-group full-width">
            <label>Support Email</label>
            <input type="email" class="form-control" id="setSupportEmail" value="${s.supportEmail}">
          </div>

          <div class="form-group full-width" style="margin-top:16px;">
            <button type="submit" class="primary-btn"><i class="fas fa-save"></i> Save Settings</button>
          </div>
        </form>
      </div>
    `;
  },

  // --- 10. Payments & Invoices View (Image 3) ---
  renderPayments(filter = 'All', search = '') {
    const container = document.getElementById('view-payments');
    if (!container) return;

    let invoices = store.getInvoices();
    if (!invoices || invoices.length === 0) {
      invoices = window.paymentsInitialData || [];
    }
    const summary = store.getPaymentsSummary();

    // Filter list by status
    let list = [...invoices];
    if (filter && filter !== 'All') {
      list = list.filter(x => (x.status || '').toLowerCase() === filter.toLowerCase());
    }

    // Filter list by search query
    if (search && search.trim() !== '') {
      const q = search.trim().toLowerCase();
      list = list.filter(x => 
        (x.invoice_no || '').toLowerCase().includes(q) ||
        (x.customer_name || '').toLowerCase().includes(q) ||
        (x.description || '').toLowerCase().includes(q) ||
        (x.payment_method || '').toLowerCase().includes(q)
      );
    }

    // Formatted date (e.g., "Thu, Jul 30" or dynamic)
    const now = new Date();
    const dateFormatted = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });

    container.innerHTML = `
      <!-- Payments Top Header Bar (Image 3) -->
      <div class="payments-header-bar">
        <div class="payments-title-wrap">
          <button type="button" class="mobile-toggle-btn" onclick="document.getElementById('sidebar').classList.toggle('collapsed')">
            <i class="fas fa-bars"></i>
          </button>
          <h1 class="payments-title">Payments &amp; Invoices</h1>
          <div class="payments-date-badge">
            <i class="far fa-calendar"></i>
            <span>${dateFormatted}</span>
          </div>
        </div>

        <div class="payments-top-search">
          <i class="fas fa-search"></i>
          <input type="text" id="paymentsSearchInput" placeholder="Search cars, customers, pages..." value="${search}" oninput="app.searchPayments(this.value)">
          <span class="search-kbd-hint">/</span>
        </div>
      </div>

      <!-- Stat Cards Row (Image 3) -->
      <div class="payments-stats-grid">
        <!-- Collected Card -->
        <div class="pay-stat-card">
          <div class="pay-stat-icon-box green">
            <i class="fas fa-money-bill-wave"></i>
          </div>
          <div class="pay-stat-body">
            <div class="pay-stat-amount">${summary.collectedFormatted || '$4,641'}</div>
            <div class="pay-stat-label">Collected</div>
          </div>
        </div>

        <!-- Pending Card -->
        <div class="pay-stat-card">
          <div class="pay-stat-icon-box amber">
            <i class="fas fa-hourglass-half"></i>
          </div>
          <div class="pay-stat-body">
            <div class="pay-stat-amount">${summary.pendingFormatted || '$1,260'}</div>
            <div class="pay-stat-label">Pending</div>
          </div>
        </div>

        <!-- Refunded Card -->
        <div class="pay-stat-card">
          <div class="pay-stat-icon-box cyan">
            <i class="fas fa-sync-alt"></i>
          </div>
          <div class="pay-stat-body">
            <div class="pay-stat-amount">${summary.refundedFormatted || '$120'}</div>
            <div class="pay-stat-label">Refunded</div>
          </div>
        </div>
      </div>

      <!-- Filter Pills & Record Payment Button Row -->
      <div class="payments-toolbar">
        <div class="payments-filter-pills">
          <button type="button" class="filter-pill ${filter === 'All' ? 'active' : ''}" onclick="app.filterPayments('All')">All</button>
          <button type="button" class="filter-pill ${filter === 'Paid' ? 'active' : ''}" onclick="app.filterPayments('Paid')">Paid</button>
          <button type="button" class="filter-pill ${filter === 'Pending' ? 'active' : ''}" onclick="app.filterPayments('Pending')">Pending</button>
          <button type="button" class="filter-pill ${filter === 'Refunded' ? 'active' : ''}" onclick="app.filterPayments('Refunded')">Refunded</button>
        </div>

        <button type="button" class="btn-record-payment" onclick="app.openRecordPaymentModal()">
          <i class="fas fa-plus"></i> Record payment
        </button>
      </div>

      <!-- Invoices & Payments Table (Image 3) -->
      <div class="payments-table-card">
        <table class="payments-table">
          <thead>
            <tr>
              <th>INVOICE</th>
              <th>CUSTOMER</th>
              <th>DESCRIPTION</th>
              <th>DATE</th>
              <th>AMOUNT</th>
              <th>STATUS</th>
              <th style="text-align: right;">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="paymentsTableBody">
            ${list.length ? list.map(item => `
              <tr class="payment-row" data-status="${item.status || 'Pending'}" data-search="${((item.invoice_no || '') + ' ' + (item.customer_name || '') + ' ' + (item.description || '')).toLowerCase()}">
                <td>
                  <a href="javascript:void(0)" class="invoice-link" onclick="app.viewInvoice('${item.invoice_no}')">
                    ${item.invoice_no}
                  </a>
                </td>
                <td>
                  <div class="cust-name-cell">
                    <span>${item.customer_name}</span>
                  </div>
                </td>
                <td>
                  <span class="desc-cell">${item.description}</span>
                </td>
                <td>
                  <span class="date-cell">${item.formattedDate || item.invoice_date}</span>
                </td>
                <td>
                  <span class="amount-cell">${item.amountFormatted || '$' + Number(item.amount).toLocaleString()}</span>
                </td>
                <td>
                  <span class="status-badge ${item.status.toLowerCase()}">${item.status}</span>
                </td>
                <td style="text-align: right;">
                  <div class="actions-group">
                    <button type="button" class="icon-action-btn" title="View & Print Invoice Receipt" onclick="app.viewInvoice('${item.invoice_no}')">
                      <i class="fas fa-receipt"></i>
                    </button>
                    <button type="button" class="icon-action-btn" title="Cycle Status" onclick="app.cycleInvoiceStatus('${item.invoice_no}', '${item.status}')">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                    <button type="button" class="icon-action-btn delete" title="Delete Invoice" onclick="app.deleteInvoicePrompt('${item.invoice_no}')">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  </div>
                </td>
              </tr>
            `).join('') : `
              <tr>
                <td colspan="7" style="text-align: center; padding: 48px 20px; color: var(--text-dim);">
                  <i class="fas fa-file-invoice" style="font-size: 36px; margin-bottom: 12px; opacity: 0.4;"></i>
                  <p>No payment records found.</p>
                </td>
              </tr>
            `}
          </tbody>
        </table>
      </div>
    `;
  },

  // Modal Invoice Preview Details
  renderInvoiceModal(inv) {
    const body = document.getElementById('invoiceModalBody');
    if (!body) return;

    body.innerHTML = `
      <div class="invoice-box" style="background:#181d2a; color:#fff; padding:28px; border-radius:18px; border:1px solid rgba(255,255,255,0.08);">
        <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:18px; margin-bottom:20px;">
          <div>
            <h2 style="font-family:'Outfit',sans-serif; color:#ff5722; font-size:24px; margin:0;">VELOCE CAR RENTAL</h2>
            <p style="color:#94a3b8; font-size:12px; margin-top:4px;">Billing &amp; Payment Receipt</p>
          </div>
          <div style="text-align:right;">
            <span style="font-family:'Outfit',sans-serif; font-size:20px; font-weight:800; color:#fff;">${inv.invoice_no}</span>
            <div style="margin-top:6px;">
              <span class="status-badge ${inv.status.toLowerCase()}">${inv.status}</span>
            </div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:24px; font-size:13.5px;">
          <div>
            <div style="color:#94a3b8; font-size:11px; text-transform:uppercase; font-weight:700; margin-bottom:6px;">Billed To</div>
            <strong style="color:#fff; font-size:15px;">${inv.customer_name}</strong>
            <div style="color:#94a3b8; margin-top:2px;">${inv.customer_email || 'No email provided'}</div>
          </div>
          <div style="text-align:right;">
            <div style="color:#94a3b8; font-size:11px; text-transform:uppercase; font-weight:700; margin-bottom:6px;">Payment Details</div>
            <div>Date: <strong style="color:#fff;">${inv.formattedDate || inv.invoice_date}</strong></div>
            <div>Method: <strong style="color:#fff;">${inv.payment_method || 'Credit Card'}</strong></div>
          </div>
        </div>

        <table style="width:100%; border-collapse:collapse; margin-bottom:24px; font-size:13.5px;">
          <thead>
            <tr style="border-bottom:1px solid rgba(255,255,255,0.1); color:#94a3b8; text-align:left;">
              <th style="padding:10px 0;">Item Description</th>
              <th style="padding:10px 0; text-align:right;">Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom:1px solid rgba(255,255,255,0.06);">
              <td style="padding:14px 0; color:#fff;">${inv.description}</td>
              <td style="padding:14px 0; text-align:right; font-weight:700; color:#fff;">${inv.amountFormatted || '$' + Number(inv.amount).toLocaleString()}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td style="padding:16px 0; font-weight:800; font-size:16px; color:#fff;">Total Amount</td>
              <td style="padding:16px 0; text-align:right; font-weight:800; font-size:18px; color:#ff5722;">${inv.amountFormatted || '$' + Number(inv.amount).toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>

        <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:10px;">
          <button class="secondary-btn" onclick="window.print()"><i class="fas fa-print"></i> Print Receipt</button>
          <button class="primary-btn" style="background:#ff5722; border-color:#ff5722;" onclick="app.closeModal('modal-view-invoice')">Close</button>
        </div>
      </div>
    `;
  }
};

if (typeof window !== 'undefined') {
  window.components = components;
}
