const INITIAL_DATA = {
  vehicles: [],
  bookings: [],
  customers: [],
  cart: [],
  invoices: (typeof window !== 'undefined' && window.paymentsInitialData) ? window.paymentsInitialData : [],
  paymentsSummary: {},
  drivers: [],
  maintenance: [],
  settings: { companyName: 'Veloce Car Rental', currency: 'USD ($)', taxRate: 8 },
  metrics: {},
  chartData: null
};

class Store {
  constructor() {
    this.data = INITIAL_DATA;
    this.ready = this.load();
  }

  async load() {
    try {
      const r = await fetch('api.php?action=all', { credentials: 'same-origin' });
      const x = await r.json();
      if (!x.success) throw Error(x.message);
      this.data = {
        vehicles: x.vehicles || [],
        bookings: x.bookings || [],
      returns: x.returns || {},
        customers: x.customers || [],
        cart: x.cart || [],
        invoices: (x.invoices && x.invoices.length > 0) ? x.invoices : (window.paymentsInitialData || []),
        paymentsSummary: x.paymentsSummary || {},
        drivers: x.drivers || [],
        maintenance: x.maintenance || [],
        chartData: x.chartData || null,
        settings: x.settings || INITIAL_DATA.settings,
        metrics: x.metrics || {}
      };
    } catch(e) {
      console.warn("Store load warning:", e);
      if (typeof window !== 'undefined' && window.paymentsInitialData) {
        this.data.invoices = window.paymentsInitialData;
      }
    }
  }

  save() {}

  getVehicles() { return this.data.vehicles || []; }
  getBookings() { return this.data.bookings || []; }
  getReturns() { return this.data.returns || {}; }
  getCustomers() { return this.data.customers || []; }
  getDrivers() { return this.data.drivers || []; }
  getMaintenance() { return this.data.maintenance || []; }
  getChartData() { return this.data.chartData || null; }
  getInvoices() {
    if (this.data.invoices && this.data.invoices.length > 0) return this.data.invoices;
    if (typeof window !== 'undefined' && window.paymentsInitialData && window.paymentsInitialData.length > 0) {
      return window.paymentsInitialData;
    }
    return [];
  }
  getPaymentsSummary() { return this.data.paymentsSummary || {}; }
  getMetrics() { return this.data.metrics || {}; }

  async refresh() {
    await this.load();
    return this.data;
  }

  addVehicle(v) {
    return fetch('api.php?action=vehicle_add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...v, price_usd: v.rate })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
      return v;
    });
  }

  updateVehicle(id, d) {
    const v = this.data.vehicles.find(x => x.id === id || x.vehicle_code === id);
    return fetch('api.php?action=vehicle_update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...v, ...d, db_id: v?.db_id, vehicle_code: v?.vehicle_code || id, price_usd: d.price_usd ?? d.rate ?? v?.rate })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
    });
  }

  deleteVehicle(id) {
    const v = this.data.vehicles.find(x => x.id === id || x.vehicle_code === id);
    return fetch('api.php?action=vehicle_delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, db_id: v?.db_id })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
    });
  }

  addBooking(b) { return Promise.resolve(b); }

  updateBookingStatus(id, s) {
    return fetch('api.php?action=booking_status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status: s })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
    });
  }

  deleteBooking(id) {
    return fetch('api.php?action=booking_delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
    });
  }

  addMaintenance(data) {
    return fetch('api.php?action=maintenance_add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).then(r => r.json()).then(async res => {
      if (!res.success) throw Error(res.message);
      await this.refresh();
      return res;
    });
  }

  updateMaintenanceStatus(id, status) {
    return fetch('api.php?action=maintenance_status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticket_id: id, status })
    }).then(r => r.json()).then(async res => {
      if (!res.success) throw Error(res.message);
      await this.refresh();
      return res;
    });
  }

  addChauffeur(data) { return fetch('api.php?action=chauffeur_add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(r=>r.json()).then(async x=>{if(!x.success)throw Error(x.message);await this.refresh();return x;}); }
  updateChauffeur(data) { return fetch('api.php?action=chauffeur_update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(r=>r.json()).then(async x=>{if(!x.success)throw Error(x.message);await this.refresh();return x;}); }
  updateChauffeurStatus(id,status,dbId) { return fetch('api.php?action=chauffeur_status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,driver_code:id,db_id:dbId,status})}).then(r=>r.json()).then(async x=>{if(!x.success)throw Error(x.message);await this.refresh();return x;}); }
  deleteChauffeur(id,dbId) { return fetch('api.php?action=chauffeur_delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,driver_code:id,db_id:dbId})}).then(r=>r.json()).then(async x=>{if(!x.success)throw Error(x.message);await this.refresh();return x;}); }
  restoreChauffeur(id,dbId) { return fetch('api.php?action=chauffeur_restore',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,driver_code:id,db_id:dbId})}).then(r=>r.json()).then(async x=>{if(!x.success)throw Error(x.message);await this.refresh();return x;}); }

  deleteMaintenance(id) {
    return fetch('api.php?action=maintenance_delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticket_id: id })
    }).then(r => r.json()).then(async res => {
      if (!res.success) throw Error(res.message);
      await this.refresh();
      return res;
    });
  }

  addInvoice(inv) {
    return fetch('api.php?action=invoice_add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(inv)
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
      return x;
    });
  }

  updateInvoiceStatus(id, status) {
    if (this.data.invoices) {
      const it = this.data.invoices.find(x => x.invoice_no === id || x.id === id);
      if (it) it.status = status;
    }
    return fetch('api.php?action=invoice_status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoice_no: id, status })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
      return x;
    });
  }

  deleteInvoice(id) {
    if (this.data.invoices) {
      this.data.invoices = this.data.invoices.filter(x => x.invoice_no !== id && x.id !== id);
    }
    return fetch('api.php?action=invoice_delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoice_no: id })
    }).then(r => r.json()).then(async x => {
      if (!x.success) throw Error(x.message);
      await this.refresh();
      return x;
    });
  }
}

const store = new Store();
if (typeof window !== 'undefined') {
  window.store = store;
}